-- MySQL dump 10.13  Distrib 5.5.28, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: dhis2
-- ------------------------------------------------------
-- Server version	5.5.28-0ubuntu0.12.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `_categoryoptioncomboname`
--

DROP TABLE IF EXISTS `_categoryoptioncomboname`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_categoryoptioncomboname` (
  `categoryoptioncomboid` int(11) NOT NULL,
  `categoryoptioncomboname` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_categoryoptioncomboname`
--

LOCK TABLES `_categoryoptioncomboname` WRITE;
/*!40000 ALTER TABLE `_categoryoptioncomboname` DISABLE KEYS */;
/*!40000 ALTER TABLE `_categoryoptioncomboname` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_categorystructure`
--

DROP TABLE IF EXISTS `_categorystructure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_categorystructure` (
  `categoryoptioncomboid` int(11) NOT NULL,
  `categoryoptioncomboname` varchar(250) DEFAULT NULL,
  `_default` varchar(250) DEFAULT NULL,
  `cat_1` int(11) DEFAULT NULL,
  PRIMARY KEY (`categoryoptioncomboid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_categorystructure`
--

LOCK TABLES `_categorystructure` WRITE;
/*!40000 ALTER TABLE `_categorystructure` DISABLE KEYS */;
/*!40000 ALTER TABLE `_categorystructure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_dataelementgroupsetstructure`
--

DROP TABLE IF EXISTS `_dataelementgroupsetstructure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_dataelementgroupsetstructure` (
  `dataelementid` int(11) NOT NULL,
  `dataelementname` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`dataelementid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_dataelementgroupsetstructure`
--

LOCK TABLES `_dataelementgroupsetstructure` WRITE;
/*!40000 ALTER TABLE `_dataelementgroupsetstructure` DISABLE KEYS */;
/*!40000 ALTER TABLE `_dataelementgroupsetstructure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_dataelementstructure`
--

DROP TABLE IF EXISTS `_dataelementstructure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_dataelementstructure` (
  `dataelementid` int(11) NOT NULL,
  `dataelementname` varchar(250) DEFAULT NULL,
  `periodtypeid` int(11) DEFAULT NULL,
  `periodtypename` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_dataelementstructure`
--

LOCK TABLES `_dataelementstructure` WRITE;
/*!40000 ALTER TABLE `_dataelementstructure` DISABLE KEYS */;
/*!40000 ALTER TABLE `_dataelementstructure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_indicatorgroupsetstructure`
--

DROP TABLE IF EXISTS `_indicatorgroupsetstructure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_indicatorgroupsetstructure` (
  `indicatorid` int(11) NOT NULL,
  `indicatorname` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`indicatorid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_indicatorgroupsetstructure`
--

LOCK TABLES `_indicatorgroupsetstructure` WRITE;
/*!40000 ALTER TABLE `_indicatorgroupsetstructure` DISABLE KEYS */;
/*!40000 ALTER TABLE `_indicatorgroupsetstructure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_organisationunitgroupsetstructure`
--

DROP TABLE IF EXISTS `_organisationunitgroupsetstructure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_organisationunitgroupsetstructure` (
  `organisationunitid` int(11) NOT NULL,
  `organisationunitname` varchar(250) DEFAULT NULL,
  `ownership` varchar(250) DEFAULT NULL,
  `ougs_IlAZjU8wWuL` int(11) DEFAULT NULL,
  `type` varchar(250) DEFAULT NULL,
  `ougs_nleTyT3nigc` int(11) DEFAULT NULL,
  PRIMARY KEY (`organisationunitid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_organisationunitgroupsetstructure`
--

LOCK TABLES `_organisationunitgroupsetstructure` WRITE;
/*!40000 ALTER TABLE `_organisationunitgroupsetstructure` DISABLE KEYS */;
/*!40000 ALTER TABLE `_organisationunitgroupsetstructure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_orgunitstructure`
--

DROP TABLE IF EXISTS `_orgunitstructure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_orgunitstructure` (
  `organisationunitid` int(11) NOT NULL,
  `level` int(11) DEFAULT NULL,
  PRIMARY KEY (`organisationunitid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_orgunitstructure`
--

LOCK TABLES `_orgunitstructure` WRITE;
/*!40000 ALTER TABLE `_orgunitstructure` DISABLE KEYS */;
/*!40000 ALTER TABLE `_orgunitstructure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aggregateddatasetcompleteness`
--

DROP TABLE IF EXISTS `aggregateddatasetcompleteness`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aggregateddatasetcompleteness` (
  `datasetid` int(11) DEFAULT NULL,
  `periodid` int(11) DEFAULT NULL,
  `periodname` varchar(30) DEFAULT NULL,
  `organisationunitid` int(11) DEFAULT NULL,
  `sources` int(11) DEFAULT NULL,
  `registrations` int(11) DEFAULT NULL,
  `registrationsOnTime` int(11) DEFAULT NULL,
  `value` decimal(10,0) DEFAULT NULL,
  `valueOnTime` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aggregateddatasetcompleteness`
--

LOCK TABLES `aggregateddatasetcompleteness` WRITE;
/*!40000 ALTER TABLE `aggregateddatasetcompleteness` DISABLE KEYS */;
/*!40000 ALTER TABLE `aggregateddatasetcompleteness` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aggregateddatavalue`
--

DROP TABLE IF EXISTS `aggregateddatavalue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aggregateddatavalue` (
  `dataelementid` int(11) DEFAULT NULL,
  `categoryoptioncomboid` int(11) DEFAULT NULL,
  `periodid` int(11) DEFAULT NULL,
  `organisationunitid` int(11) DEFAULT NULL,
  `periodtypeid` int(11) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `value` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aggregateddatavalue`
--

LOCK TABLES `aggregateddatavalue` WRITE;
/*!40000 ALTER TABLE `aggregateddatavalue` DISABLE KEYS */;
/*!40000 ALTER TABLE `aggregateddatavalue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aggregatedindicatorvalue`
--

DROP TABLE IF EXISTS `aggregatedindicatorvalue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aggregatedindicatorvalue` (
  `indicatorid` int(11) DEFAULT NULL,
  `periodid` int(11) DEFAULT NULL,
  `organisationunitid` int(11) DEFAULT NULL,
  `periodtypeid` int(11) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `annualized` varchar(10) DEFAULT NULL,
  `factor` decimal(10,0) DEFAULT NULL,
  `value` decimal(10,0) DEFAULT NULL,
  `numeratorvalue` decimal(10,0) DEFAULT NULL,
  `denominatorvalue` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aggregatedindicatorvalue`
--

LOCK TABLES `aggregatedindicatorvalue` WRITE;
/*!40000 ALTER TABLE `aggregatedindicatorvalue` DISABLE KEYS */;
/*!40000 ALTER TABLE `aggregatedindicatorvalue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aggregatedorgunitdatasetcompleteness`
--

DROP TABLE IF EXISTS `aggregatedorgunitdatasetcompleteness`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aggregatedorgunitdatasetcompleteness` (
  `datasetid` int(11) DEFAULT NULL,
  `periodid` int(11) DEFAULT NULL,
  `periodname` varchar(30) DEFAULT NULL,
  `organisationunitid` int(11) DEFAULT NULL,
  `organisationunitgroupid` int(11) DEFAULT NULL,
  `sources` int(11) DEFAULT NULL,
  `registrations` int(11) DEFAULT NULL,
  `registrationsOnTime` int(11) DEFAULT NULL,
  `value` decimal(10,0) DEFAULT NULL,
  `valueOnTime` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aggregatedorgunitdatasetcompleteness`
--

LOCK TABLES `aggregatedorgunitdatasetcompleteness` WRITE;
/*!40000 ALTER TABLE `aggregatedorgunitdatasetcompleteness` DISABLE KEYS */;
/*!40000 ALTER TABLE `aggregatedorgunitdatasetcompleteness` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aggregatedorgunitdatavalue`
--

DROP TABLE IF EXISTS `aggregatedorgunitdatavalue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aggregatedorgunitdatavalue` (
  `dataelementid` int(11) DEFAULT NULL,
  `categoryoptioncomboid` int(11) DEFAULT NULL,
  `periodid` int(11) DEFAULT NULL,
  `organisationunitid` int(11) DEFAULT NULL,
  `organisationunitgroupid` int(11) DEFAULT NULL,
  `periodtypeid` int(11) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `value` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aggregatedorgunitdatavalue`
--

LOCK TABLES `aggregatedorgunitdatavalue` WRITE;
/*!40000 ALTER TABLE `aggregatedorgunitdatavalue` DISABLE KEYS */;
/*!40000 ALTER TABLE `aggregatedorgunitdatavalue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aggregatedorgunitindicatorvalue`
--

DROP TABLE IF EXISTS `aggregatedorgunitindicatorvalue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aggregatedorgunitindicatorvalue` (
  `indicatorid` int(11) DEFAULT NULL,
  `periodid` int(11) DEFAULT NULL,
  `organisationunitid` int(11) DEFAULT NULL,
  `organisationunitgroupid` int(11) DEFAULT NULL,
  `periodtypeid` int(11) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `annualized` varchar(10) DEFAULT NULL,
  `factor` decimal(10,0) DEFAULT NULL,
  `value` decimal(10,0) DEFAULT NULL,
  `numeratorvalue` decimal(10,0) DEFAULT NULL,
  `denominatorvalue` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aggregatedorgunitindicatorvalue`
--

LOCK TABLES `aggregatedorgunitindicatorvalue` WRITE;
/*!40000 ALTER TABLE `aggregatedorgunitindicatorvalue` DISABLE KEYS */;
/*!40000 ALTER TABLE `aggregatedorgunitindicatorvalue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attribute`
--

DROP TABLE IF EXISTS `attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attribute` (
  `attributeid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `valueType` varchar(255) NOT NULL,
  `mandatory` tinyint(1) NOT NULL,
  `dataElementAttribute` tinyint(1) NOT NULL,
  `dataElementGroupAttribute` tinyint(1) DEFAULT NULL,
  `indicatorAttribute` tinyint(1) NOT NULL,
  `indicatorGroupAttribute` tinyint(1) DEFAULT NULL,
  `organisationUnitAttribute` tinyint(1) NOT NULL,
  `organisationUnitGroupAttribute` tinyint(1) DEFAULT NULL,
  `userAttribute` tinyint(1) NOT NULL,
  `userGroupAttribute` tinyint(1) DEFAULT NULL,
  `sortOrder` int(11) DEFAULT NULL,
  PRIMARY KEY (`attributeid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attribute`
--

LOCK TABLES `attribute` WRITE;
/*!40000 ALTER TABLE `attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attributevalue`
--

DROP TABLE IF EXISTS `attributevalue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attributevalue` (
  `attributevalueid` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(255) DEFAULT NULL,
  `attributeid` int(11) NOT NULL,
  PRIMARY KEY (`attributevalueid`),
  KEY `fk_attributevalue_attributeid` (`attributeid`),
  CONSTRAINT `fk_attributevalue_attributeid` FOREIGN KEY (`attributeid`) REFERENCES `attribute` (`attributeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attributevalue`
--

LOCK TABLES `attributevalue` WRITE;
/*!40000 ALTER TABLE `attributevalue` DISABLE KEYS */;
/*!40000 ALTER TABLE `attributevalue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `caseaggregationcondition`
--

DROP TABLE IF EXISTS `caseaggregationcondition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `caseaggregationcondition` (
  `caseaggregationconditionid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `operator` varchar(255) NOT NULL,
  `aggregationExpression` varchar(255) NOT NULL,
  `aggregationDataElementid` int(11) DEFAULT NULL,
  `optionComboid` int(11) DEFAULT NULL,
  PRIMARY KEY (`caseaggregationconditionid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`),
  KEY `fk_caseaggregationcondition_categoryoptioncomboid` (`optionComboid`),
  KEY `fk_caseaggregationcondition_dataelement` (`aggregationDataElementid`),
  CONSTRAINT `fk_caseaggregationcondition_categoryoptioncomboid` FOREIGN KEY (`optionComboid`) REFERENCES `categoryoptioncombo` (`categoryoptioncomboid`),
  CONSTRAINT `fk_caseaggregationcondition_dataelement` FOREIGN KEY (`aggregationDataElementid`) REFERENCES `dataelement` (`dataelementid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `caseaggregationcondition`
--

LOCK TABLES `caseaggregationcondition` WRITE;
/*!40000 ALTER TABLE `caseaggregationcondition` DISABLE KEYS */;
/*!40000 ALTER TABLE `caseaggregationcondition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories_categoryoptions`
--

DROP TABLE IF EXISTS `categories_categoryoptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories_categoryoptions` (
  `categoryoptionid` int(11) NOT NULL,
  `categoryid` int(11) NOT NULL DEFAULT '0',
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`categoryid`,`sort_order`),
  KEY `fk_categories_categoryoptions_categoryid` (`categoryid`),
  KEY `fk_category_categoryoptionid` (`categoryoptionid`),
  CONSTRAINT `fk_categories_categoryoptions_categoryid` FOREIGN KEY (`categoryid`) REFERENCES `dataelementcategory` (`categoryid`),
  CONSTRAINT `fk_category_categoryoptionid` FOREIGN KEY (`categoryoptionid`) REFERENCES `dataelementcategoryoption` (`categoryoptionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories_categoryoptions`
--

LOCK TABLES `categories_categoryoptions` WRITE;
/*!40000 ALTER TABLE `categories_categoryoptions` DISABLE KEYS */;
INSERT INTO `categories_categoryoptions` VALUES (2,2,1),(3,3,1),(4,3,2),(5,3,3),(6,3,4),(7,3,5),(8,3,6),(9,4,1),(10,4,2),(11,5,1),(12,5,2),(13,3,7),(14,3,8),(15,6,1),(16,6,2),(17,6,3),(35,8,1),(36,8,2),(37,8,3),(38,8,4),(39,8,5),(40,8,6),(41,9,1),(42,9,2);
/*!40000 ALTER TABLE `categories_categoryoptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorycombo`
--

DROP TABLE IF EXISTS `categorycombo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorycombo` (
  `categorycomboid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `skipTotal` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`categorycomboid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorycombo`
--

LOCK TABLES `categorycombo` WRITE;
/*!40000 ALTER TABLE `categorycombo` DISABLE KEYS */;
INSERT INTO `categorycombo` VALUES (2,'default','QabpRWKuX7N',NULL,'2013-02-16 16:02:38',0),(3,'Age_combo','jOaXd4Qd1cU',NULL,'2013-02-16 20:41:39',0),(4,'Gender_combo','fbfz8R9y7zQ',NULL,'2013-02-16 16:19:10',0),(5,'agegroup_gender_combo','Z3UaZOscqYX',NULL,'2013-02-16 20:41:39',0),(6,'Membership_combo','pjc3zTzNtQl',NULL,'2013-02-16 19:53:17',0),(7,'agegroup_gender_membership_combo','XGLXuhlTuWd',NULL,'2013-02-16 20:53:21',0),(8,'agegroup_membership_combo','dMYMRmiO4Sq',NULL,'2013-02-16 20:55:48',0),(9,'Membership_gender_combo','yQWoeG49ycf',NULL,'2013-02-16 21:16:09',0),(10,'membership_genderwithps_combo','Iz734KIvAzF',NULL,'2013-02-16 21:38:13',0),(12,'Membershiptype_combo','YzbWVGZ8iMM',NULL,'2013-02-17 13:31:14',0),(13,'administration_member_combo','prjWLUUDc1P',NULL,'2013-04-15 01:56:57',0);
/*!40000 ALTER TABLE `categorycombo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorycombos_categories`
--

DROP TABLE IF EXISTS `categorycombos_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorycombos_categories` (
  `categorycomboid` int(11) NOT NULL,
  `categoryid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`categorycomboid`,`sort_order`),
  KEY `fk_categorycombos_categories_categorycomboid` (`categorycomboid`),
  KEY `fk_categorycombo_categoryid` (`categoryid`),
  CONSTRAINT `fk_categorycombos_categories_categorycomboid` FOREIGN KEY (`categorycomboid`) REFERENCES `categorycombo` (`categorycomboid`),
  CONSTRAINT `fk_categorycombo_categoryid` FOREIGN KEY (`categoryid`) REFERENCES `dataelementcategory` (`categoryid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorycombos_categories`
--

LOCK TABLES `categorycombos_categories` WRITE;
/*!40000 ALTER TABLE `categorycombos_categories` DISABLE KEYS */;
INSERT INTO `categorycombos_categories` VALUES (2,2,1),(3,3,1),(5,3,1),(7,3,1),(8,3,1),(4,4,1),(5,4,2),(7,4,2),(9,4,1),(6,5,1),(7,5,3),(8,5,2),(9,5,2),(10,5,2),(13,5,2),(10,6,1),(12,8,1),(13,9,1);
/*!40000 ALTER TABLE `categorycombos_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorycombos_optioncombos`
--

DROP TABLE IF EXISTS `categorycombos_optioncombos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorycombos_optioncombos` (
  `categoryoptioncomboid` int(11) NOT NULL,
  `categorycomboid` int(11) DEFAULT NULL,
  PRIMARY KEY (`categoryoptioncomboid`),
  KEY `fk_categorycombos_optioncombos_categorycomboid` (`categorycomboid`),
  KEY `fk_categorycombo_categoryoptioncomboid` (`categoryoptioncomboid`),
  CONSTRAINT `fk_categorycombos_optioncombos_categorycomboid` FOREIGN KEY (`categorycomboid`) REFERENCES `categorycombo` (`categorycomboid`),
  CONSTRAINT `fk_categorycombo_categoryoptioncomboid` FOREIGN KEY (`categoryoptioncomboid`) REFERENCES `categoryoptioncombo` (`categoryoptioncomboid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorycombos_optioncombos`
--

LOCK TABLES `categorycombos_optioncombos` WRITE;
/*!40000 ALTER TABLE `categorycombos_optioncombos` DISABLE KEYS */;
INSERT INTO `categorycombos_optioncombos` VALUES (2,2),(3,3),(4,3),(5,3),(6,3),(7,3),(8,3),(25,3),(28,3),(9,4),(10,4),(11,5),(12,5),(13,5),(14,5),(15,5),(16,5),(17,5),(18,5),(19,5),(20,5),(21,5),(22,5),(26,5),(27,5),(29,5),(30,5),(23,6),(24,6),(31,7),(32,7),(33,7),(34,7),(35,7),(36,7),(37,7),(38,7),(39,7),(40,7),(41,7),(42,7),(43,7),(44,7),(45,7),(46,7),(47,7),(48,7),(49,7),(50,7),(51,7),(52,7),(53,7),(54,7),(55,7),(56,7),(57,7),(58,7),(59,7),(60,7),(61,7),(62,7),(63,8),(64,8),(65,8),(66,8),(67,8),(68,8),(69,8),(70,8),(71,8),(72,8),(73,8),(74,8),(75,8),(76,8),(77,8),(78,8),(79,9),(80,9),(81,9),(82,9),(83,10),(84,10),(85,10),(86,10),(87,10),(88,10),(96,12),(97,12),(98,12),(99,12),(100,12),(101,12),(102,13),(103,13),(104,13),(105,13);
/*!40000 ALTER TABLE `categorycombos_optioncombos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categoryoptioncombo`
--

DROP TABLE IF EXISTS `categoryoptioncombo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categoryoptioncombo` (
  `categoryoptioncomboid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  PRIMARY KEY (`categoryoptioncomboid`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoryoptioncombo`
--

LOCK TABLES `categoryoptioncombo` WRITE;
/*!40000 ALTER TABLE `categoryoptioncombo` DISABLE KEYS */;
INSERT INTO `categoryoptioncombo` VALUES (2,'gYtTUjdgUvV',NULL,'2013-02-16 16:02:38'),(3,'SE7VzbblNOa',NULL,'2013-02-16 16:18:56'),(4,'p6CXIBi4QD5',NULL,'2013-02-16 16:18:56'),(5,'WqkMKzhKMa3',NULL,'2013-02-16 16:18:56'),(6,'UWGOz2llPXd',NULL,'2013-02-16 16:18:56'),(7,'k7u61rtSMDp',NULL,'2013-02-16 16:18:56'),(8,'LlLQIToRgJF',NULL,'2013-02-16 16:18:56'),(9,'tId1FFPPfPT',NULL,'2013-02-16 16:19:10'),(10,'Q9kt4mVoNfv',NULL,'2013-02-16 16:19:10'),(11,'CJ0RtGgu8Ny',NULL,'2013-02-16 16:19:28'),(12,'ZKHhpo1YJMh',NULL,'2013-02-16 16:19:28'),(13,'FB9YMbtHocZ',NULL,'2013-02-16 16:19:28'),(14,'tzYD0GDnMBS',NULL,'2013-02-16 16:19:28'),(15,'jBjeRWaa3WV',NULL,'2013-02-16 16:19:28'),(16,'cqsZkufPeaF',NULL,'2013-02-16 16:19:28'),(17,'NLNMIyAZFMm',NULL,'2013-02-16 16:19:28'),(18,'By4NW9q8JXU',NULL,'2013-02-16 16:19:28'),(19,'iu2bz8lrJQW',NULL,'2013-02-16 16:19:28'),(20,'ajFhwFSyB6J',NULL,'2013-02-16 16:19:28'),(21,'tj0Do7raY67',NULL,'2013-02-16 16:19:28'),(22,'bRnKBzipOuK',NULL,'2013-02-16 16:19:28'),(23,'TdS54PzZkHI',NULL,'2013-02-16 19:53:17'),(24,'K0RE5TYU9cJ',NULL,'2013-02-16 19:53:17'),(25,'a3g4STsVJ2S',NULL,'2013-02-16 20:41:23'),(26,'O2bVzguydkD',NULL,'2013-02-16 20:41:23'),(27,'NTeWctz6Hdq',NULL,'2013-02-16 20:41:23'),(28,'pqfbjmGpYeI',NULL,'2013-02-16 20:41:39'),(29,'T4Cs3k2kHHz',NULL,'2013-02-16 20:41:39'),(30,'vFWdj6b3YTc',NULL,'2013-02-16 20:41:39'),(31,'Aq8xo8yOTlo',NULL,'2013-02-16 20:53:21'),(32,'EJoJLT5KQ4o',NULL,'2013-02-16 20:53:21'),(33,'JVO8qZY1f10',NULL,'2013-02-16 20:53:21'),(34,'FcNHaskjoaE',NULL,'2013-02-16 20:53:21'),(35,'WchGoyVocIQ',NULL,'2013-02-16 20:53:21'),(36,'FtD4w7Nyhmb',NULL,'2013-02-16 20:53:21'),(37,'i61l1qFUsww',NULL,'2013-02-16 20:53:21'),(38,'JapQo3FrntS',NULL,'2013-02-16 20:53:21'),(39,'lbie6zxeGkT',NULL,'2013-02-16 20:53:21'),(40,'R7JXBbmjcvD',NULL,'2013-02-16 20:53:21'),(41,'IBunzaxgST3',NULL,'2013-02-16 20:53:21'),(42,'MF5dSieziJT',NULL,'2013-02-16 20:53:21'),(43,'TiikwDeyEiK',NULL,'2013-02-16 20:53:21'),(44,'JlTwNwU7ye5',NULL,'2013-02-16 20:53:21'),(45,'ZgiXYbGtvKL',NULL,'2013-02-16 20:53:21'),(46,'MhfBASpybXU',NULL,'2013-02-16 20:53:21'),(47,'Uk9QgXDIQJp',NULL,'2013-02-16 20:53:21'),(48,'HsGuOt0mFcH',NULL,'2013-02-16 20:53:21'),(49,'PAB3YMFeEiR',NULL,'2013-02-16 20:53:21'),(50,'StTceHXOcDk',NULL,'2013-02-16 20:53:21'),(51,'vipZ1oeAu8n',NULL,'2013-02-16 20:53:21'),(52,'CX8DVthUcA2',NULL,'2013-02-16 20:53:21'),(53,'AIQKQpgmAih',NULL,'2013-02-16 20:53:21'),(54,'eQ8wjv3Tgfx',NULL,'2013-02-16 20:53:21'),(55,'Sbjs5nCy1WU',NULL,'2013-02-16 20:53:21'),(56,'C3cfEFUaVD4',NULL,'2013-02-16 20:53:21'),(57,'DSDkiVW3Mdz',NULL,'2013-02-16 20:53:21'),(58,'blpKqHOpz47',NULL,'2013-02-16 20:53:21'),(59,'wUejHsqbFMD',NULL,'2013-02-16 20:53:21'),(60,'fGfaeqE2G7R',NULL,'2013-02-16 20:53:21'),(61,'zMy2Ue6UFJg',NULL,'2013-02-16 20:53:21'),(62,'FqfRZGWst8v',NULL,'2013-02-16 20:53:21'),(63,'I8VjNQMzyps',NULL,'2013-02-16 20:55:48'),(64,'mZ6AokwYjvF',NULL,'2013-02-16 20:55:48'),(65,'zUN2ua3ffER',NULL,'2013-02-16 20:55:48'),(66,'sXjGZ6yvKBn',NULL,'2013-02-16 20:55:48'),(67,'om9zC97rG6n',NULL,'2013-02-16 20:55:48'),(68,'Rwi17wv3sgZ',NULL,'2013-02-16 20:55:48'),(69,'R5XDrBkhlgx',NULL,'2013-02-16 20:55:48'),(70,'SppawzeAlKC',NULL,'2013-02-16 20:55:48'),(71,'skuA1wZPTWD',NULL,'2013-02-16 20:55:48'),(72,'Lw5AowBFg1X',NULL,'2013-02-16 20:55:48'),(73,'EjVDYSiGCXO',NULL,'2013-02-16 20:55:48'),(74,'iBZZkVdxZUs',NULL,'2013-02-16 20:55:48'),(75,'wjoFCzgyKGn',NULL,'2013-02-16 20:55:48'),(76,'IQ4QQ9bmQ5h',NULL,'2013-02-16 20:55:48'),(77,'qAmd5AuInlR',NULL,'2013-02-16 20:55:48'),(78,'mwdhPqJirBd',NULL,'2013-02-16 20:55:48'),(79,'BMmWLbHjWhp',NULL,'2013-02-16 21:06:56'),(80,'VSsrK57yQFB',NULL,'2013-02-16 21:06:56'),(81,'A5SemhzTQS7',NULL,'2013-02-16 21:06:56'),(82,'ZtuGm0I2fsM',NULL,'2013-02-16 21:06:56'),(83,'Cx9pPkQnMXf',NULL,'2013-02-16 21:38:13'),(84,'HbBFzB0w6W8',NULL,'2013-02-16 21:38:13'),(85,'r2jW7qauCcg',NULL,'2013-02-16 21:38:13'),(86,'JhTuu19H0ht',NULL,'2013-02-16 21:38:13'),(87,'hYkfDfrvQ2S',NULL,'2013-02-16 21:38:13'),(88,'BAku2cr3ZTR',NULL,'2013-02-16 21:38:13'),(96,'KMA2YvBQkXp',NULL,'2013-02-17 13:31:14'),(97,'N00RkcegdG9',NULL,'2013-02-17 13:31:14'),(98,'UrQbqiMW8Pl',NULL,'2013-02-17 13:31:14'),(99,'thQIkoAlxrP',NULL,'2013-02-17 13:31:14'),(100,'f3SzlYgQJZC',NULL,'2013-02-17 13:31:14'),(101,'frmGd3KHKpd',NULL,'2013-02-17 13:31:14'),(102,'uFCamoDZajh',NULL,'2013-04-15 01:56:57'),(103,'tgWl43bMv7H',NULL,'2013-04-15 01:56:57'),(104,'F5ijMW71xcb',NULL,'2013-04-15 01:56:57'),(105,'t6HX46Y2Pv5',NULL,'2013-04-15 01:56:57');
/*!40000 ALTER TABLE `categoryoptioncombo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categoryoptioncombos_categoryoptions`
--

DROP TABLE IF EXISTS `categoryoptioncombos_categoryoptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categoryoptioncombos_categoryoptions` (
  `categoryoptionid` int(11) NOT NULL,
  `categoryoptioncomboid` int(11) NOT NULL,
  PRIMARY KEY (`categoryoptioncomboid`,`categoryoptionid`),
  KEY `fk_categoryoptioncombos_categoryoptions_categoryoptioncomboid` (`categoryoptioncomboid`),
  KEY `fk_categoryoptioncombo_categoryoptionid` (`categoryoptionid`),
  CONSTRAINT `fk_categoryoptioncombos_categoryoptions_categoryoptioncomboid` FOREIGN KEY (`categoryoptioncomboid`) REFERENCES `categoryoptioncombo` (`categoryoptioncomboid`),
  CONSTRAINT `fk_categoryoptioncombo_categoryoptionid` FOREIGN KEY (`categoryoptionid`) REFERENCES `dataelementcategoryoption` (`categoryoptionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoryoptioncombos_categoryoptions`
--

LOCK TABLES `categoryoptioncombos_categoryoptions` WRITE;
/*!40000 ALTER TABLE `categoryoptioncombos_categoryoptions` DISABLE KEYS */;
INSERT INTO `categoryoptioncombos_categoryoptions` VALUES (2,2),(6,3),(4,4),(7,5),(5,6),(8,7),(3,8),(9,9),(10,10),(7,11),(10,11),(7,12),(9,12),(6,13),(9,13),(8,14),(10,14),(3,15),(9,15),(3,16),(10,16),(6,17),(10,17),(4,18),(10,18),(4,19),(9,19),(8,20),(9,20),(5,21),(10,21),(5,22),(9,22),(12,23),(11,24),(13,25),(9,26),(13,26),(10,27),(13,27),(14,28),(9,29),(14,29),(10,30),(14,30),(7,31),(9,31),(11,31),(9,32),(12,32),(13,32),(3,33),(10,33),(11,33),(6,34),(10,34),(12,34),(3,35),(9,35),(11,35),(10,36),(12,36),(13,36),(8,37),(9,37),(12,37),(8,38),(9,38),(11,38),(3,39),(9,39),(12,39),(5,40),(10,40),(12,40),(10,41),(11,41),(14,41),(7,42),(9,42),(12,42),(9,43),(11,43),(14,43),(6,44),(9,44),(12,44),(5,45),(9,45),(11,45),(4,46),(9,46),(12,46),(8,47),(10,47),(12,47),(3,48),(10,48),(12,48),(10,49),(11,49),(13,49),(4,50),(10,50),(12,50),(9,51),(12,51),(14,51),(5,52),(9,52),(12,52),(7,53),(10,53),(12,53),(5,54),(10,54),(11,54),(8,55),(10,55),(11,55),(6,56),(10,56),(11,56),(4,57),(9,57),(11,57),(6,58),(9,58),(11,58),(7,59),(10,59),(11,59),(4,60),(10,60),(11,60),(10,61),(12,61),(14,61),(9,62),(11,62),(13,62),(4,63),(12,63),(8,64),(12,64),(11,65),(14,65),(6,66),(12,66),(7,67),(11,67),(3,68),(11,68),(5,69),(11,69),(5,70),(12,70),(11,71),(13,71),(8,72),(11,72),(6,73),(11,73),(3,74),(12,74),(12,75),(14,75),(12,76),(13,76),(7,77),(12,77),(4,78),(11,78),(9,79),(11,79),(10,80),(12,80),(9,81),(12,81),(10,82),(11,82),(11,83),(17,83),(12,84),(15,84),(12,85),(16,85),(11,86),(15,86),(11,87),(16,87),(12,88),(17,88),(39,96),(37,97),(36,98),(35,99),(40,100),(38,101),(11,102),(42,102),(12,103),(41,103),(12,104),(42,104),(11,105),(41,105);
/*!40000 ALTER TABLE `categoryoptioncombos_categoryoptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chart`
--

DROP TABLE IF EXISTS `chart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chart` (
  `chartid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `domainAxisLabel` varchar(255) DEFAULT NULL,
  `rangeAxisLabel` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `series` varchar(255) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `filter` varchar(255) DEFAULT NULL,
  `hideLegend` tinyint(1) DEFAULT NULL,
  `regression` tinyint(1) DEFAULT NULL,
  `hideSubtitle` tinyint(1) DEFAULT NULL,
  `targetLineValue` double DEFAULT NULL,
  `targetLineLabel` varchar(255) DEFAULT NULL,
  `baseLineValue` double DEFAULT NULL,
  `baseLineLabel` varchar(255) DEFAULT NULL,
  `organisationunitgroupsetid` int(11) DEFAULT NULL,
  `reportingMonth` tinyint(1) DEFAULT NULL,
  `reportingQuarter` tinyint(1) DEFAULT NULL,
  `lastSixMonth` tinyint(1) DEFAULT NULL,
  `thisYear` tinyint(1) DEFAULT NULL,
  `last12Months` tinyint(1) DEFAULT NULL,
  `last3Months` tinyint(1) DEFAULT NULL,
  `last4Quarters` tinyint(1) DEFAULT NULL,
  `last2SixMonths` tinyint(1) DEFAULT NULL,
  `lastYear` tinyint(1) DEFAULT NULL,
  `last5Years` tinyint(1) DEFAULT NULL,
  `userOrganisationUnit` tinyint(1) DEFAULT NULL,
  `userOrganisationUnitChildren` tinyint(1) DEFAULT NULL,
  `showData` tinyint(1) DEFAULT NULL,
  `rewindRelativePeriods` tinyint(1) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `targetline` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`chartid`),
  KEY `fk_chart_organisationunitgroupsetid` (`organisationunitgroupsetid`),
  KEY `fk_chart_userid` (`userid`),
  CONSTRAINT `fk_chart_organisationunitgroupsetid` FOREIGN KEY (`organisationunitgroupsetid`) REFERENCES `orgunitgroupset` (`orgunitgroupsetid`),
  CONSTRAINT `fk_chart_userid` FOREIGN KEY (`userid`) REFERENCES `userinfo` (`userinfoid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chart`
--

LOCK TABLES `chart` WRITE;
/*!40000 ALTER TABLE `chart` DISABLE KEYS */;
/*!40000 ALTER TABLE `chart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chart_dataelements`
--

DROP TABLE IF EXISTS `chart_dataelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chart_dataelements` (
  `chartid` int(11) NOT NULL,
  `dataelementid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`chartid`,`sort_order`),
  KEY `fk_chart_dataelements_dataelementid` (`dataelementid`),
  KEY `fk_chart_dataelements_chartid` (`chartid`),
  CONSTRAINT `fk_chart_dataelements_chartid` FOREIGN KEY (`chartid`) REFERENCES `chart` (`chartid`),
  CONSTRAINT `fk_chart_dataelements_dataelementid` FOREIGN KEY (`dataelementid`) REFERENCES `dataelement` (`dataelementid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chart_dataelements`
--

LOCK TABLES `chart_dataelements` WRITE;
/*!40000 ALTER TABLE `chart_dataelements` DISABLE KEYS */;
/*!40000 ALTER TABLE `chart_dataelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chart_datasets`
--

DROP TABLE IF EXISTS `chart_datasets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chart_datasets` (
  `chartid` int(11) NOT NULL,
  `datasetid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`chartid`,`sort_order`),
  KEY `fk_chart_datasets_datasetid` (`datasetid`),
  KEY `fk_chart_datasets_chartid` (`chartid`),
  CONSTRAINT `fk_chart_datasets_chartid` FOREIGN KEY (`chartid`) REFERENCES `chart` (`chartid`),
  CONSTRAINT `fk_chart_datasets_datasetid` FOREIGN KEY (`datasetid`) REFERENCES `dataset` (`datasetid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chart_datasets`
--

LOCK TABLES `chart_datasets` WRITE;
/*!40000 ALTER TABLE `chart_datasets` DISABLE KEYS */;
/*!40000 ALTER TABLE `chart_datasets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chart_indicators`
--

DROP TABLE IF EXISTS `chart_indicators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chart_indicators` (
  `chartid` int(11) NOT NULL,
  `indicatorid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`chartid`,`sort_order`),
  KEY `fk_chart_indicators_chartid` (`chartid`),
  KEY `fk_chart_indicators_indicatorid` (`indicatorid`),
  CONSTRAINT `fk_chart_indicators_chartid` FOREIGN KEY (`chartid`) REFERENCES `chart` (`chartid`),
  CONSTRAINT `fk_chart_indicators_indicatorid` FOREIGN KEY (`indicatorid`) REFERENCES `indicator` (`indicatorid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chart_indicators`
--

LOCK TABLES `chart_indicators` WRITE;
/*!40000 ALTER TABLE `chart_indicators` DISABLE KEYS */;
/*!40000 ALTER TABLE `chart_indicators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chart_organisationunits`
--

DROP TABLE IF EXISTS `chart_organisationunits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chart_organisationunits` (
  `chartid` int(11) NOT NULL,
  `organisationunitid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`chartid`,`sort_order`),
  KEY `fk_chart_organisationunits_organisationunitid` (`organisationunitid`),
  KEY `fk_chart_organisationunits_chartid` (`chartid`),
  CONSTRAINT `fk_chart_organisationunits_chartid` FOREIGN KEY (`chartid`) REFERENCES `chart` (`chartid`),
  CONSTRAINT `fk_chart_organisationunits_organisationunitid` FOREIGN KEY (`organisationunitid`) REFERENCES `organisationunit` (`organisationunitid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chart_organisationunits`
--

LOCK TABLES `chart_organisationunits` WRITE;
/*!40000 ALTER TABLE `chart_organisationunits` DISABLE KEYS */;
/*!40000 ALTER TABLE `chart_organisationunits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chart_periods`
--

DROP TABLE IF EXISTS `chart_periods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chart_periods` (
  `chartid` int(11) NOT NULL,
  `periodid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`chartid`,`sort_order`),
  KEY `fk_chart_periods_chartid` (`chartid`),
  KEY `fk_chart_periods_periodid` (`periodid`),
  CONSTRAINT `fk_chart_periods_chartid` FOREIGN KEY (`chartid`) REFERENCES `chart` (`chartid`),
  CONSTRAINT `fk_chart_periods_periodid` FOREIGN KEY (`periodid`) REFERENCES `period` (`periodid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chart_periods`
--

LOCK TABLES `chart_periods` WRITE;
/*!40000 ALTER TABLE `chart_periods` DISABLE KEYS */;
/*!40000 ALTER TABLE `chart_periods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `completedatasetregistration`
--

DROP TABLE IF EXISTS `completedatasetregistration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `completedatasetregistration` (
  `datasetid` int(11) NOT NULL,
  `periodid` int(11) NOT NULL,
  `sourceid` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `storedby` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`datasetid`,`periodid`,`sourceid`),
  KEY `fk_datasetcompleteregistration_datasetid` (`datasetid`),
  KEY `fk_completedatasetregistration_organisationunitid` (`sourceid`),
  KEY `fk_datasetcompleteregistration_periodid` (`periodid`),
  CONSTRAINT `fk_completedatasetregistration_organisationunitid` FOREIGN KEY (`sourceid`) REFERENCES `organisationunit` (`organisationunitid`),
  CONSTRAINT `fk_datasetcompleteregistration_datasetid` FOREIGN KEY (`datasetid`) REFERENCES `dataset` (`datasetid`),
  CONSTRAINT `fk_datasetcompleteregistration_periodid` FOREIGN KEY (`periodid`) REFERENCES `period` (`periodid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `completedatasetregistration`
--

LOCK TABLES `completedatasetregistration` WRITE;
/*!40000 ALTER TABLE `completedatasetregistration` DISABLE KEYS */;
INSERT INTO `completedatasetregistration` VALUES (2,3,2,'2013-02-16','admin');
/*!40000 ALTER TABLE `completedatasetregistration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept`
--

DROP TABLE IF EXISTS `concept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `concept` (
  `conceptid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  PRIMARY KEY (`conceptid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept`
--

LOCK TABLES `concept` WRITE;
/*!40000 ALTER TABLE `concept` DISABLE KEYS */;
INSERT INTO `concept` VALUES (2,'default','El31xE2Bf1x',NULL,'2013-02-16 16:02:38');
/*!40000 ALTER TABLE `concept` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_in`
--

DROP TABLE IF EXISTS `config_in`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config_in` (
  `configid` int(11) NOT NULL AUTO_INCREMENT,
  `ckey` varchar(160) NOT NULL,
  `cvalue` varchar(160) NOT NULL,
  PRIMARY KEY (`configid`),
  UNIQUE KEY `ckey` (`ckey`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_in`
--

LOCK TABLES `config_in` WRITE;
/*!40000 ALTER TABLE `config_in` DISABLE KEYS */;
INSERT INTO `config_in` VALUES (1,'mysqlpath','/var/lib/mysql'),(2,'backupdatapath','/opt/'),(3,'reportfolder','ra_national');
/*!40000 ALTER TABLE `config_in` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuration`
--

DROP TABLE IF EXISTS `configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuration` (
  `configurationid` int(11) NOT NULL AUTO_INCREMENT,
  `feedbackrecipientsid` int(11) DEFAULT NULL,
  `offlineorgunitlevelid` int(11) DEFAULT NULL,
  `infrastructuraldataelementsid` int(11) DEFAULT NULL,
  `infrastructuralperiodtypeid` int(11) DEFAULT NULL,
  `selfregistrationrole` int(11) DEFAULT NULL,
  `selfRegistrationOrgUnit` int(11) DEFAULT NULL,
  PRIMARY KEY (`configurationid`),
  KEY `fk_configuration_infrastructural_periodtype` (`infrastructuralperiodtypeid`),
  KEY `fk_configuration_infrastructural_dataelements` (`infrastructuraldataelementsid`),
  KEY `fk_configuration_selfregistrationorgunit` (`selfRegistrationOrgUnit`),
  KEY `fk_configuration_offline_orgunit_level` (`offlineorgunitlevelid`),
  KEY `fk_configuration_feedback_recipients` (`feedbackrecipientsid`),
  KEY `fk_configuration_selfregistrationrole` (`selfregistrationrole`),
  CONSTRAINT `fk_configuration_feedback_recipients` FOREIGN KEY (`feedbackrecipientsid`) REFERENCES `usergroup` (`usergroupid`),
  CONSTRAINT `fk_configuration_infrastructural_dataelements` FOREIGN KEY (`infrastructuraldataelementsid`) REFERENCES `dataelementgroup` (`dataelementgroupid`),
  CONSTRAINT `fk_configuration_infrastructural_periodtype` FOREIGN KEY (`infrastructuralperiodtypeid`) REFERENCES `periodtype` (`periodtypeid`),
  CONSTRAINT `fk_configuration_offline_orgunit_level` FOREIGN KEY (`offlineorgunitlevelid`) REFERENCES `orgunitlevel` (`orgunitlevelid`),
  CONSTRAINT `fk_configuration_selfregistrationorgunit` FOREIGN KEY (`selfRegistrationOrgUnit`) REFERENCES `organisationunit` (`organisationunitid`),
  CONSTRAINT `fk_configuration_selfregistrationrole` FOREIGN KEY (`selfregistrationrole`) REFERENCES `userrole` (`userroleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuration`
--

LOCK TABLES `configuration` WRITE;
/*!40000 ALTER TABLE `configuration` DISABLE KEYS */;
/*!40000 ALTER TABLE `configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `constant`
--

DROP TABLE IF EXISTS `constant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `constant` (
  `constantid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `value` double DEFAULT NULL,
  PRIMARY KEY (`constantid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `constant`
--

LOCK TABLES `constant` WRITE;
/*!40000 ALTER TABLE `constant` DISABLE KEYS */;
/*!40000 ALTER TABLE `constant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboardcontent`
--

DROP TABLE IF EXISTS `dashboardcontent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboardcontent` (
  `dashboardcontentid` int(11) NOT NULL,
  PRIMARY KEY (`dashboardcontentid`),
  KEY `fk_dashboardcontent_userinfoid` (`dashboardcontentid`),
  CONSTRAINT `fk_dashboardcontent_userinfoid` FOREIGN KEY (`dashboardcontentid`) REFERENCES `userinfo` (`userinfoid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboardcontent`
--

LOCK TABLES `dashboardcontent` WRITE;
/*!40000 ALTER TABLE `dashboardcontent` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboardcontent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboardcontent_documents`
--

DROP TABLE IF EXISTS `dashboardcontent_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboardcontent_documents` (
  `userid` int(11) NOT NULL,
  `documentid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`userid`,`sort_order`),
  KEY `fk_dashboardcontent_documents_documentid` (`documentid`),
  KEY `fk_dashboardcontent_documents_userid` (`userid`),
  CONSTRAINT `fk_dashboardcontent_documents_documentid` FOREIGN KEY (`documentid`) REFERENCES `document` (`documentid`),
  CONSTRAINT `fk_dashboardcontent_documents_userid` FOREIGN KEY (`userid`) REFERENCES `dashboardcontent` (`dashboardcontentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboardcontent_documents`
--

LOCK TABLES `dashboardcontent_documents` WRITE;
/*!40000 ALTER TABLE `dashboardcontent_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboardcontent_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboardcontent_maps`
--

DROP TABLE IF EXISTS `dashboardcontent_maps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboardcontent_maps` (
  `userid` int(11) NOT NULL,
  `mapid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`userid`,`sort_order`),
  KEY `fk_dashboardcontent_maps_mapid` (`mapid`),
  KEY `fk_dashboardcontent_maps_userid` (`userid`),
  CONSTRAINT `fk_dashboardcontent_maps_mapid` FOREIGN KEY (`mapid`) REFERENCES `map` (`mapid`),
  CONSTRAINT `fk_dashboardcontent_maps_userid` FOREIGN KEY (`userid`) REFERENCES `dashboardcontent` (`dashboardcontentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboardcontent_maps`
--

LOCK TABLES `dashboardcontent_maps` WRITE;
/*!40000 ALTER TABLE `dashboardcontent_maps` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboardcontent_maps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboardcontent_reports`
--

DROP TABLE IF EXISTS `dashboardcontent_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboardcontent_reports` (
  `userid` int(11) NOT NULL,
  `reportid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`userid`,`sort_order`),
  KEY `fk_dashboardcontent_reports_reportid` (`reportid`),
  KEY `fk_dashboardcontent_reports_userid` (`userid`),
  CONSTRAINT `fk_dashboardcontent_reports_reportid` FOREIGN KEY (`reportid`) REFERENCES `report` (`reportid`),
  CONSTRAINT `fk_dashboardcontent_reports_userid` FOREIGN KEY (`userid`) REFERENCES `dashboardcontent` (`dashboardcontentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboardcontent_reports`
--

LOCK TABLES `dashboardcontent_reports` WRITE;
/*!40000 ALTER TABLE `dashboardcontent_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboardcontent_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboardcontent_reporttables`
--

DROP TABLE IF EXISTS `dashboardcontent_reporttables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboardcontent_reporttables` (
  `userid` int(11) NOT NULL,
  `reporttableid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`userid`,`sort_order`),
  KEY `fk_dashboardcontent_reporttableid` (`reporttableid`),
  KEY `fk_dashboardcontent_reporttables_userid` (`userid`),
  CONSTRAINT `fk_dashboardcontent_reporttableid` FOREIGN KEY (`reporttableid`) REFERENCES `reporttable` (`reporttableid`),
  CONSTRAINT `fk_dashboardcontent_reporttables_userid` FOREIGN KEY (`userid`) REFERENCES `dashboardcontent` (`dashboardcontentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboardcontent_reporttables`
--

LOCK TABLES `dashboardcontent_reporttables` WRITE;
/*!40000 ALTER TABLE `dashboardcontent_reporttables` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboardcontent_reporttables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datadictionary`
--

DROP TABLE IF EXISTS `datadictionary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datadictionary` (
  `datadictionaryid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `description` longtext,
  `region` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`datadictionaryid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datadictionary`
--

LOCK TABLES `datadictionary` WRITE;
/*!40000 ALTER TABLE `datadictionary` DISABLE KEYS */;
/*!40000 ALTER TABLE `datadictionary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datadictionarydataelements`
--

DROP TABLE IF EXISTS `datadictionarydataelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datadictionarydataelements` (
  `datadictionaryid` int(11) NOT NULL,
  `dataelementid` int(11) NOT NULL,
  PRIMARY KEY (`datadictionaryid`,`dataelementid`),
  KEY `fk_datadictionarydataelements_dataelementid` (`dataelementid`),
  KEY `fk_datadictionarydataelements_datadictionaryid` (`datadictionaryid`),
  CONSTRAINT `fk_datadictionarydataelements_datadictionaryid` FOREIGN KEY (`datadictionaryid`) REFERENCES `datadictionary` (`datadictionaryid`),
  CONSTRAINT `fk_datadictionarydataelements_dataelementid` FOREIGN KEY (`dataelementid`) REFERENCES `dataelement` (`dataelementid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datadictionarydataelements`
--

LOCK TABLES `datadictionarydataelements` WRITE;
/*!40000 ALTER TABLE `datadictionarydataelements` DISABLE KEYS */;
/*!40000 ALTER TABLE `datadictionarydataelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datadictionaryindicators`
--

DROP TABLE IF EXISTS `datadictionaryindicators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datadictionaryindicators` (
  `datadictionaryid` int(11) NOT NULL,
  `indicatorid` int(11) NOT NULL,
  PRIMARY KEY (`datadictionaryid`,`indicatorid`),
  KEY `fk_datadictionaryindicators_datadictionaryid` (`datadictionaryid`),
  KEY `fk_datadictionaryindicators_indicatorid` (`indicatorid`),
  CONSTRAINT `fk_datadictionaryindicators_datadictionaryid` FOREIGN KEY (`datadictionaryid`) REFERENCES `datadictionary` (`datadictionaryid`),
  CONSTRAINT `fk_datadictionaryindicators_indicatorid` FOREIGN KEY (`indicatorid`) REFERENCES `indicator` (`indicatorid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datadictionaryindicators`
--

LOCK TABLES `datadictionaryindicators` WRITE;
/*!40000 ALTER TABLE `datadictionaryindicators` DISABLE KEYS */;
/*!40000 ALTER TABLE `datadictionaryindicators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dataelement`
--

DROP TABLE IF EXISTS `dataelement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dataelement` (
  `dataelementid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `shortname` varchar(50) NOT NULL,
  `description` longtext,
  `formName` varchar(230) DEFAULT NULL,
  `active` tinyint(1) NOT NULL,
  `valuetype` varchar(16) NOT NULL,
  `numbertype` varchar(16) DEFAULT NULL,
  `textType` varchar(16) DEFAULT NULL,
  `domaintype` varchar(16) DEFAULT NULL,
  `aggregationtype` varchar(16) NOT NULL,
  `categorycomboid` int(11) DEFAULT NULL,
  `sortOrder` int(11) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `zeroIsSignificant` tinyint(1) NOT NULL,
  `optionsetid` int(11) DEFAULT NULL,
  `legendsetid` int(11) DEFAULT NULL,
  PRIMARY KEY (`dataelementid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `shortname` (`shortname`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `dataelement_code_key` (`code`),
  KEY `fk_dataelement_categorycomboid` (`categorycomboid`),
  KEY `fk_dataelement_optionsetid` (`optionsetid`),
  KEY `fk_dataelement_legendset` (`legendsetid`),
  CONSTRAINT `fk_dataelement_categorycomboid` FOREIGN KEY (`categorycomboid`) REFERENCES `categorycombo` (`categorycomboid`),
  CONSTRAINT `fk_dataelement_legendset` FOREIGN KEY (`legendsetid`) REFERENCES `maplegendset` (`maplegendsetid`),
  CONSTRAINT `fk_dataelement_optionsetid` FOREIGN KEY (`optionsetid`) REFERENCES `optionset` (`optionsetid`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dataelement`
--

LOCK TABLES `dataelement` WRITE;
/*!40000 ALTER TABLE `dataelement` DISABLE KEYS */;
INSERT INTO `dataelement` VALUES (2,'Age - Sex Distribution','vu8lzGCDpPw','ASDIS','2013-02-17 13:26:28','Age - Sex Distribution',NULL,NULL,1,'int','int',NULL,'aggregate','sum',5,NULL,'',1,NULL,NULL),(3,'Age Distribution','Cmv3y5PqzVZ','AGEDIS','2013-02-17 13:26:28','Age Distribution',NULL,'',1,'int','int',NULL,'aggregate','sum',3,NULL,'',1,NULL,NULL),(5,'Sex Distribution','eIzxP6iHLta',NULL,'2013-02-17 13:26:29','Sex Distribution',NULL,'',1,'int','int',NULL,'aggregate','sum',4,NULL,'',1,NULL,NULL),(6,'Cervical Cancer Screening','rFqXWJKlcAn','CERVICALCACASCREENING','2013-02-17 13:26:28','Cervical Cancer Screening','Cervical Cancer Screening for Females aged 25 to 55 years old with intact uterus','',1,'int','int',NULL,'aggregate','sum',6,NULL,'',1,NULL,NULL),(7,'Breast Cancer Screening','ve2n45Htxjn','BREASTCASCREENING','2013-02-17 13:26:27','Breast Cancer Screening','Breast Cancer Screening for 25 years old and above','',1,'int','int',NULL,'aggregate','sum',6,NULL,'',1,NULL,NULL),(12,'Female 25 - 55 years old with intact uterus','oq4an4KeDPW','F25-55YRSINTACTUTERUS','2013-02-17 14:39:24','Female 25 - 55 years old intact uterus',NULL,NULL,1,'int','int',NULL,'aggregate','sum',6,NULL,'',1,NULL,NULL),(13,'Diabetes Mellitus Cases with signs and symptoms of polyuria, polydipsia and weight loss','cM8l6bfctZI','DMPOLYWTLOSS','2013-02-17 15:38:10','DM S/Sx',NULL,NULL,1,'int','int',NULL,'aggregate','sum',9,NULL,'',1,NULL,NULL),(14,'Waist Circumference ( >=80 cm for female and <=90 cm for male)','Z3wtgjfTSux','WCGTEQ80F90M','2013-02-17 13:26:29','DM Cases Waist Circ','Diabetes Mellitus Cases with waist circumference of >=80 cm for female and <=90 cm for male',NULL,1,'int','int',NULL,'aggregate','sum',9,NULL,'',1,NULL,NULL),(15,'History of Diagnosis of Diabetes','o007FHsFzXs','HXDM','2013-02-17 13:26:28','History of Diagnosis of Diabetes',NULL,'',1,'int','int',NULL,'aggregate','sum',9,NULL,'',1,NULL,NULL),(16,'History of Diagnosis of Hypertension','iYdKXGuuu1Y','HXHPN','2013-02-17 13:26:27','Hx of Dx of HPN',NULL,'',1,'int','int',NULL,'aggregate','sum',10,NULL,'',1,NULL,NULL),(17,'Intake of Oral Hypoglycemics','YYZe8gpe0i8','INTAKEOHA','2013-02-17 13:26:28','Intake of Oral Hypogly',NULL,'',1,'int','int',NULL,'aggregate','sum',9,NULL,'',1,NULL,NULL),(18,'Adult with BP < 140/90 mmHg','F7MJAei0GxB','BPLT14090','2013-02-17 13:26:29','Adult with BP < 140/90 mm',NULL,'',1,'int','int',NULL,'aggregate','sum',10,NULL,'',1,NULL,NULL),(19,'Adult with BP > 180/120 mmHg','Fr2vDUcO48g','BPGT180120','2013-02-17 13:26:27','Adult with BP > 180/120 ',NULL,'',1,'int','int',NULL,'aggregate','sum',10,NULL,'',1,NULL,NULL),(20,'Adult with BP >/= 140/90 but less than 180/120 mmHg','BFRyn2Ru5xl','BPGT14090','2013-02-17 13:26:27','BP 140/90 to 180/120',NULL,'',1,'int','int',NULL,'aggregate','sum',10,NULL,'',1,NULL,NULL),(21,'Intake of hypertensive medicine','k5smwYPBj7W','INTAKEHPNMEDS','2013-02-17 13:26:28','Intake of hpn medicine',NULL,'',1,'int','int',NULL,'aggregate','sum',10,NULL,'',1,NULL,NULL),(22,'Name of Healthcare Facility','G4NrNlL03Gf','HCFACILITYNAME','2013-02-17 13:26:28','Name of Healthcare Facility',NULL,NULL,1,'string',NULL,'longText','aggregate','sum',2,NULL,'',0,NULL,NULL),(24,'Region','qYckN1KcdmJ','REGION','2013-02-17 13:26:28','Region',NULL,NULL,1,'string',NULL,'text','aggregate','sum',2,NULL,'',0,NULL,NULL),(25,'Province','NCvQ2npBTM8','PROVINCE','2013-02-17 13:26:28','Province',NULL,'',1,'string',NULL,'text','aggregate','sum',2,NULL,'',0,NULL,NULL),(26,'City/Municipality','o62AYtT8xMX','CITY_MUNICIPALITY','2013-02-17 13:26:28','City/Municipality',NULL,'',1,'string',NULL,'text','aggregate','sum',2,NULL,'',0,NULL,NULL),(27,'Families Assigned','MX3aKELqeqU','FAMILIESASSIGNED','2013-02-17 13:26:28','Families Assigned',NULL,'',1,'int','int',NULL,'aggregate','sum',2,NULL,'',1,NULL,NULL),(28,'Membership Type','jDjV4dKciiW','MEMBERSHIPTYPE','2013-02-17 13:33:25','Membership Type',NULL,NULL,1,'int','int',NULL,'aggregate','sum',12,NULL,'',1,NULL,NULL),(29,'Non-PHIC Members','PtxCUXvoN1q','NONPHICMEMBERS','2013-02-17 13:26:28','Non-PHIC Members',NULL,NULL,1,'int','int',NULL,'aggregate','sum',2,NULL,'',1,NULL,NULL),(30,'SP - NHTS','fCKCCcXupUE','SPNHTS','2013-02-17 13:41:48','SP - NHTS',NULL,'',1,'int','int',NULL,'aggregate','sum',2,NULL,'',1,NULL,NULL),(31,'SP - LGU','w5pW5eymZdM','SPLGU','2013-02-17 13:42:28','SP - LGU',NULL,'',1,'int','int',NULL,'aggregate','sum',2,NULL,'',1,NULL,NULL),(32,'SP - NGA','wrplLObrtFO','SPNGA','2013-02-17 13:42:59','SP - NGA',NULL,'',1,'int','int',NULL,'aggregate','sum',2,NULL,'',1,NULL,NULL),(33,'SP - Private','yPY6ylW3olP','SPPRIVATE','2013-02-17 13:43:36','SP - Private',NULL,'',1,'int','int',NULL,'aggregate','sum',2,NULL,'',1,NULL,NULL),(34,'IPP - OFW','IQq96k9Ppq8','IPPOFW','2013-02-17 13:44:01','IPP - OFW',NULL,'',1,'int','int',NULL,'aggregate','sum',2,NULL,'',1,NULL,NULL),(35,'IPP - OG','n9n42Rg0FTF','IPPOG','2013-02-17 13:44:25','IPP - OG',NULL,'',1,'int','int',NULL,'aggregate','sum',2,NULL,'',1,NULL,NULL),(36,'Female 25 years old and above','OxpzYFsKHhf','FEMALE25YRSANDABOVE','2013-02-17 14:32:07','Female 25 years old and above',NULL,'',1,'int','int',NULL,'aggregate','sum',6,NULL,'',1,NULL,NULL),(37,'Body measurements','uANsvN7N9c1','BM','2013-04-15 04:45:06','Body measurements',NULL,NULL,1,'int','int',NULL,'aggregate','sum',13,NULL,'',1,NULL,NULL),(38,'Breastfeeding Program Education','YaICd87mYnY','BFPEDU','2013-04-15 04:44:17','Breastfeeding educ',NULL,NULL,1,'int','int',NULL,'aggregate','sum',13,NULL,'',1,NULL,NULL),(39,'Chest X-Ray','xOAnM12uS8c','CXRAY','2013-04-15 04:48:23','Chest X-Ray',NULL,NULL,1,'int','int',NULL,'aggregate','sum',13,NULL,'',1,NULL,NULL),(40,'Complete Blood Count','i5QnWxFrvy0','CBC','2013-04-15 04:45:35','CBC',NULL,NULL,1,'int','int',NULL,'aggregate','sum',13,NULL,'',0,NULL,NULL),(41,'Consultation','rUla1wQOge8','CONSU','2013-04-15 04:49:04','Consultation',NULL,NULL,1,'int','int',NULL,'aggregate','sum',13,NULL,'',1,NULL,NULL),(42,'Counselling for lifestyle modification','E5UtDfKHfUJ','CFLSMOD','2013-04-15 04:44:33','Counselling for lifestyle',NULL,NULL,1,'int','int',NULL,'aggregate','sum',13,NULL,'',1,NULL,NULL),(43,'Counselling for smoking cessation','QRckDStPBaP','CFSC','2013-04-15 04:44:48','Counselling for smoking',NULL,NULL,1,'int','int',NULL,'aggregate','sum',13,NULL,'',1,NULL,NULL),(44,'Dependents','FFLmxaPR8NM','DEPNDS','2013-04-15 04:49:48','Dependents',NULL,NULL,1,'int','int',NULL,'aggregate','sum',4,NULL,'',1,NULL,NULL),(45,'Digital Rectal Examination','kqmtb3QTUn1','DREX','2013-04-15 04:45:21','Digital Rectal Exam',NULL,NULL,1,'int','int',NULL,'aggregate','sum',13,NULL,'',1,NULL,NULL),(46,'Fasting Blood Sugar','jBDWhnpjCIN','FBSUG','2013-04-15 05:06:19','FBS',NULL,NULL,1,'int','int',NULL,'aggregate','sum',13,NULL,'',1,NULL,NULL),(47,'Fecalysis','qMtyVCYyDtu','FCLY','2013-04-15 04:47:16','Fecalysis',NULL,NULL,1,'int','int',NULL,'aggregate','sum',13,NULL,'',1,NULL,NULL),(48,'Hypertensive BP Measurement','c6eKhfZUtZM',NULL,'2013-04-15 02:07:07','HPN BP',NULL,'',1,'int','int',NULL,'aggregate','sum',13,NULL,'',1,NULL,NULL),(49,'Lipid Profile','XJgbvoKkueQ','LPROF','2013-04-15 04:48:09','Lipid Profile ',NULL,NULL,1,'int','int',NULL,'aggregate','sum',13,NULL,'',1,NULL,NULL),(50,'Members','qSFycli6qm5','MEMBERS','2013-04-15 04:48:39','Members',NULL,NULL,1,'int','int',NULL,'aggregate','sum',4,NULL,'',1,NULL,NULL),(51,'Non-hypertensive BP Measurement','h8gNikRw297',NULL,'2013-04-15 02:09:02','Non-HPN BP',NULL,'',1,'int','int',NULL,'aggregate','sum',13,NULL,'',1,NULL,NULL),(52,'Obligated Accomplishment Hypertensive BP Measurement','a6A97IKNddq','OAHBPM','2013-04-15 04:53:53','Ob Accomplishment HPN',NULL,NULL,1,'int','int',NULL,'aggregate','sum',2,NULL,'',0,NULL,NULL),(53,'Obligated Accomplishment Non-hypertensive BP Measurement','l97GXcmIyRB','OANHBPM','2013-04-15 04:53:31','Ob Accomplishment Non-HPN',NULL,NULL,1,'int','int',NULL,'aggregate','sum',2,NULL,'',0,NULL,NULL),(54,'Obligated Accomplishment Periodic Clinical Breast Examination','Rr5Nnt7f6L1','OAPCBE','2013-04-15 04:52:52','Ob Accomplishment CBE',NULL,NULL,1,'int','int',NULL,'aggregate','sum',2,NULL,'',0,NULL,NULL),(55,'Obligated Accomplishment Visual Inspection with Acetic Acid','P2vXtipGWQr','OAVIWAA','2013-04-15 04:52:24','Ob Accomplishment VIAA',NULL,NULL,1,'int','int',NULL,'aggregate','sum',2,NULL,'',0,NULL,NULL),(56,'Obligated Target Hypertensive BP Measurement','FiUOyyczmjX','OTHBPM','2013-04-15 04:51:00','Obligated Target HPN BP',NULL,NULL,1,'int','int',NULL,'aggregate','sum',2,NULL,'',0,NULL,NULL),(57,'Obligated Target Non-hypertensive BP Measurement','WofRHiIpUPF','OTNHBPM','2013-04-15 04:52:09','Ob Target Non-HPN BP',NULL,NULL,1,'int','int',NULL,'aggregate','sum',2,NULL,'',0,NULL,NULL),(58,'Obligated Target Periodic Clinical Breast Examination','T3QRYUfWIEz','OTPCBE','2013-04-15 04:51:38','Ob Target Periodic CBE',NULL,NULL,1,'int','int',NULL,'aggregate','sum',2,NULL,'',1,NULL,NULL),(59,'Obligated Target Visual Inspection with Acetic Acid','Cjgc8TwLzCf','OTVIWAA','2013-04-15 04:51:53','Obligated Target VIAA',NULL,NULL,1,'int','int',NULL,'aggregate','sum',2,NULL,'',1,NULL,NULL),(60,'Periodic clinical breast examination','j7cIGxFp9jr','PCBEX','2013-04-15 04:50:06','periodic BE',NULL,NULL,1,'int','int',NULL,'aggregate','sum',13,NULL,'',1,NULL,NULL),(61,'Regular BP Measurement','LHcttC1qtTn','RBPM','2013-04-15 05:01:08','Regular BP',NULL,NULL,1,'int','int',NULL,'aggregate','sum',13,NULL,'',1,NULL,NULL),(62,'Sputum Microscopy','bkUWVHERnZI','SPMIC','2013-04-15 04:47:36','Sputum Microscopy',NULL,NULL,1,'int','int',NULL,'aggregate','sum',13,NULL,'',1,NULL,NULL),(63,'Urinalysis','jGbF1XY4W6B','URINALY','2013-04-15 04:49:24','Urinalysis',NULL,NULL,1,'int','int',NULL,'aggregate','sum',13,NULL,'',1,NULL,NULL),(64,'Visual Inspection with Acetic Acid','Eu0DgSxhXL4','VIWAA','2013-04-15 04:50:31','VI with acetic acid',NULL,NULL,1,'int','int',NULL,'aggregate','sum',13,NULL,'',1,NULL,NULL);
/*!40000 ALTER TABLE `dataelement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dataelementaggregationlevels`
--

DROP TABLE IF EXISTS `dataelementaggregationlevels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dataelementaggregationlevels` (
  `dataelementid` int(11) NOT NULL,
  `aggregationlevel` int(11) DEFAULT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`dataelementid`,`sort_order`),
  KEY `fk_dataelementaggregationlevels_dataelementid` (`dataelementid`),
  CONSTRAINT `fk_dataelementaggregationlevels_dataelementid` FOREIGN KEY (`dataelementid`) REFERENCES `dataelement` (`dataelementid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dataelementaggregationlevels`
--

LOCK TABLES `dataelementaggregationlevels` WRITE;
/*!40000 ALTER TABLE `dataelementaggregationlevels` DISABLE KEYS */;
/*!40000 ALTER TABLE `dataelementaggregationlevels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dataelementattributevalues`
--

DROP TABLE IF EXISTS `dataelementattributevalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dataelementattributevalues` (
  `dataelementid` int(11) NOT NULL,
  `attributevalueid` int(11) NOT NULL,
  PRIMARY KEY (`dataelementid`,`attributevalueid`),
  UNIQUE KEY `attributevalueid` (`attributevalueid`),
  KEY `FKDF16E06C8EB6FBA9` (`dataelementid`),
  KEY `FKDF16E06C2B8E4FD1` (`attributevalueid`),
  CONSTRAINT `FKDF16E06C2B8E4FD1` FOREIGN KEY (`attributevalueid`) REFERENCES `attributevalue` (`attributevalueid`),
  CONSTRAINT `FKDF16E06C8EB6FBA9` FOREIGN KEY (`dataelementid`) REFERENCES `dataelement` (`dataelementid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dataelementattributevalues`
--

LOCK TABLES `dataelementattributevalues` WRITE;
/*!40000 ALTER TABLE `dataelementattributevalues` DISABLE KEYS */;
/*!40000 ALTER TABLE `dataelementattributevalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dataelementcategory`
--

DROP TABLE IF EXISTS `dataelementcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dataelementcategory` (
  `categoryid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `conceptid` int(11) DEFAULT NULL,
  PRIMARY KEY (`categoryid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`),
  KEY `fk_dataelementcategory_conceptid` (`conceptid`),
  CONSTRAINT `fk_dataelementcategory_conceptid` FOREIGN KEY (`conceptid`) REFERENCES `concept` (`conceptid`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dataelementcategory`
--

LOCK TABLES `dataelementcategory` WRITE;
/*!40000 ALTER TABLE `dataelementcategory` DISABLE KEYS */;
INSERT INTO `dataelementcategory` VALUES (2,'default','cKFS6FxDLG3',NULL,'2013-04-16 18:28:30',2),(3,'Age Group','rLDFsimAKMs',NULL,'2013-02-16 20:41:41',2),(4,'Gender','iSzS7ClC4Yw',NULL,'2013-02-16 16:17:58',2),(5,'Membership','GzOXndrhgwk',NULL,'2013-02-16 19:52:44',2),(6,'Gender with Pregnancy Status','ryHwty7pNnR',NULL,'2013-02-16 21:37:27',2),(8,'Membership Type','z0NYz7gIwdt',NULL,'2013-02-17 13:30:51',2),(9,'administration status','EjDzsfeYWyH',NULL,'2013-04-15 01:55:44',2);
/*!40000 ALTER TABLE `dataelementcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dataelementcategoryoption`
--

DROP TABLE IF EXISTS `dataelementcategoryoption`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dataelementcategoryoption` (
  `categoryoptionid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `conceptid` int(11) DEFAULT NULL,
  PRIMARY KEY (`categoryoptionid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dataelementcategoryoption`
--

LOCK TABLES `dataelementcategoryoption` WRITE;
/*!40000 ALTER TABLE `dataelementcategoryoption` DISABLE KEYS */;
INSERT INTO `dataelementcategoryoption` VALUES (2,'default','DtAFkwoCzGW',NULL,'2013-02-16 16:02:38',NULL),(3,'0 - 1 years','utVfpcilxAc',NULL,'2013-02-16 16:14:40',NULL),(4,'2 - 5 years','BsE3HcrxB1E',NULL,'2013-02-16 16:14:40',NULL),(5,'6 - 15 years','ePeazOp3eoO',NULL,'2013-02-16 16:14:40',NULL),(6,'16 - 24 years','RyjAVsBZoVw',NULL,'2013-02-16 16:14:40',NULL),(7,'25 - 59 years','EpjQnhv1Q8m',NULL,'2013-02-16 16:14:41',NULL),(8,'60 years and above','fYf86nwQ0Ou',NULL,'2013-02-16 16:14:41',NULL),(9,'Male','xdp08T9Ruff',NULL,'2013-02-16 16:17:58',NULL),(10,'Female','bxDHypnd15V',NULL,'2013-02-16 16:17:58',NULL),(11,'Member','UsO0dRWlPsb',NULL,'2013-02-16 19:52:44',NULL),(12,'Dependent','Rt1E8qcs3o3',NULL,'2013-02-16 19:52:44',NULL),(13,'25 years and above','eS7wDIgVf9Z',NULL,'2013-02-16 20:41:23',NULL),(14,'25 - 55 years','FtsXHoGB1EC',NULL,'2013-02-16 20:41:39',NULL),(15,'Male, uncategorized','ZTMSMBpFyLk',NULL,'2013-02-16 21:37:27',NULL),(16,'Female, Pregnant','aMEqOH4XiSG',NULL,'2013-02-16 21:37:27',NULL),(17,'Female, Non-Pregnant','ZgXGRzWWWP7',NULL,'2013-02-16 21:37:27',NULL),(25,'Non-PHIC Members:','azCL1UtR96O',NULL,'2013-02-16 23:12:36',NULL),(26,'Non-PHIC Members','e3u1PvLkrhM',NULL,'2013-02-16 23:12:40',NULL),(29,'SP - LGU','kPjQ0rYiIqw',NULL,'2013-02-17 13:12:08',NULL),(30,'SP NHTS','WXTJpfmfo7S',NULL,'2013-02-17 13:14:04',NULL),(35,'SP - LGU Member','wbNVFQw7CJk',NULL,'2013-02-17 13:30:51',NULL),(36,'SP - NHTS Member','jon04kPEIEI',NULL,'2013-02-17 13:30:51',NULL),(37,'SP - NGA Member','p3aWGwcr6wP',NULL,'2013-02-17 13:30:51',NULL),(38,'SP - Private Member','xX1OsmkC35p',NULL,'2013-02-17 13:30:51',NULL),(39,'IPP - OG Memver','itT1eOSqAKO',NULL,'2013-02-17 13:30:51',NULL),(40,'IPP - OFW Member','gnprPm0Poqa',NULL,'2013-02-17 13:30:51',NULL),(41,'Given','qV1KCmqsgKw',NULL,'2013-04-15 01:55:44',NULL),(42,'Referred','osc0VfBLhhI',NULL,'2013-04-15 01:55:44',NULL);
/*!40000 ALTER TABLE `dataelementcategoryoption` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dataelementgroup`
--

DROP TABLE IF EXISTS `dataelementgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dataelementgroup` (
  `dataelementgroupid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  PRIMARY KEY (`dataelementgroupid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dataelementgroup`
--

LOCK TABLES `dataelementgroup` WRITE;
/*!40000 ALTER TABLE `dataelementgroup` DISABLE KEYS */;
INSERT INTO `dataelementgroup` VALUES (2,'PCB Form A2','lvGmeiQCUcY',NULL,'2013-02-17 14:30:14');
/*!40000 ALTER TABLE `dataelementgroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dataelementgroupattributevalues`
--

DROP TABLE IF EXISTS `dataelementgroupattributevalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dataelementgroupattributevalues` (
  `dataelementgroupid` int(11) NOT NULL,
  `attributevalueid` int(11) NOT NULL,
  PRIMARY KEY (`dataelementgroupid`,`attributevalueid`),
  UNIQUE KEY `attributevalueid` (`attributevalueid`),
  KEY `FK933F9D712B8E4FD1` (`attributevalueid`),
  KEY `FK933F9D715C59606B` (`dataelementgroupid`),
  CONSTRAINT `FK933F9D712B8E4FD1` FOREIGN KEY (`attributevalueid`) REFERENCES `attributevalue` (`attributevalueid`),
  CONSTRAINT `FK933F9D715C59606B` FOREIGN KEY (`dataelementgroupid`) REFERENCES `dataelementgroup` (`dataelementgroupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dataelementgroupattributevalues`
--

LOCK TABLES `dataelementgroupattributevalues` WRITE;
/*!40000 ALTER TABLE `dataelementgroupattributevalues` DISABLE KEYS */;
/*!40000 ALTER TABLE `dataelementgroupattributevalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dataelementgroupmembers`
--

DROP TABLE IF EXISTS `dataelementgroupmembers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dataelementgroupmembers` (
  `dataelementid` int(11) NOT NULL,
  `dataelementgroupid` int(11) NOT NULL,
  PRIMARY KEY (`dataelementgroupid`,`dataelementid`),
  KEY `fk_dataelementgroup_dataelementid` (`dataelementid`),
  KEY `fk_dataelementgroupmembers_dataelementgroupid` (`dataelementgroupid`),
  CONSTRAINT `fk_dataelementgroupmembers_dataelementgroupid` FOREIGN KEY (`dataelementgroupid`) REFERENCES `dataelementgroup` (`dataelementgroupid`),
  CONSTRAINT `fk_dataelementgroup_dataelementid` FOREIGN KEY (`dataelementid`) REFERENCES `dataelement` (`dataelementid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dataelementgroupmembers`
--

LOCK TABLES `dataelementgroupmembers` WRITE;
/*!40000 ALTER TABLE `dataelementgroupmembers` DISABLE KEYS */;
INSERT INTO `dataelementgroupmembers` VALUES (2,2),(3,2),(5,2),(6,2),(7,2),(12,2),(13,2),(14,2),(15,2),(16,2),(17,2),(18,2),(19,2),(20,2),(21,2),(22,2),(24,2),(25,2),(26,2),(27,2),(29,2);
/*!40000 ALTER TABLE `dataelementgroupmembers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dataelementgroupset`
--

DROP TABLE IF EXISTS `dataelementgroupset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dataelementgroupset` (
  `dataelementgroupsetid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `compulsory` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`dataelementgroupsetid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dataelementgroupset`
--

LOCK TABLES `dataelementgroupset` WRITE;
/*!40000 ALTER TABLE `dataelementgroupset` DISABLE KEYS */;
/*!40000 ALTER TABLE `dataelementgroupset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dataelementgroupsetmembers`
--

DROP TABLE IF EXISTS `dataelementgroupsetmembers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dataelementgroupsetmembers` (
  `dataelementgroupid` int(11) NOT NULL,
  `dataelementgroupsetid` int(11) NOT NULL DEFAULT '0',
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`dataelementgroupsetid`,`sort_order`),
  KEY `fk_dataelementgroupsetmembers_dataelementgroupsetid` (`dataelementgroupsetid`),
  KEY `fk_dataelementgroupset_dataelementgroupid` (`dataelementgroupid`),
  CONSTRAINT `fk_dataelementgroupsetmembers_dataelementgroupsetid` FOREIGN KEY (`dataelementgroupsetid`) REFERENCES `dataelementgroupset` (`dataelementgroupsetid`),
  CONSTRAINT `fk_dataelementgroupset_dataelementgroupid` FOREIGN KEY (`dataelementgroupid`) REFERENCES `dataelementgroup` (`dataelementgroupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dataelementgroupsetmembers`
--

LOCK TABLES `dataelementgroupsetmembers` WRITE;
/*!40000 ALTER TABLE `dataelementgroupsetmembers` DISABLE KEYS */;
/*!40000 ALTER TABLE `dataelementgroupsetmembers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dataelementoperand`
--

DROP TABLE IF EXISTS `dataelementoperand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dataelementoperand` (
  `dataelementoperandid` int(11) NOT NULL AUTO_INCREMENT,
  `dataelementid` int(11) DEFAULT NULL,
  `categoryoptioncomboid` int(11) DEFAULT NULL,
  PRIMARY KEY (`dataelementoperandid`),
  KEY `fk_dataelementoperand_dataelement` (`dataelementid`),
  KEY `fk_dataelementoperand_dataelementcategoryoptioncombo` (`categoryoptioncomboid`),
  CONSTRAINT `fk_dataelementoperand_dataelement` FOREIGN KEY (`dataelementid`) REFERENCES `dataelement` (`dataelementid`),
  CONSTRAINT `fk_dataelementoperand_dataelementcategoryoptioncombo` FOREIGN KEY (`categoryoptioncomboid`) REFERENCES `categoryoptioncombo` (`categoryoptioncomboid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dataelementoperand`
--

LOCK TABLES `dataelementoperand` WRITE;
/*!40000 ALTER TABLE `dataelementoperand` DISABLE KEYS */;
/*!40000 ALTER TABLE `dataelementoperand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dataentryform`
--

DROP TABLE IF EXISTS `dataentryform`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dataentryform` (
  `dataentryformid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(160) NOT NULL,
  `style` varchar(40) DEFAULT NULL,
  `htmlcode` longtext,
  PRIMARY KEY (`dataentryformid`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dataentryform`
--

LOCK TABLES `dataentryform` WRITE;
/*!40000 ALTER TABLE `dataentryform` DISABLE KEYS */;
INSERT INTO `dataentryform` VALUES (1,'PCB Form A2','regular','<p>\r\n	&nbsp;</p>\r\n<table border=\"0\" cellspacing=\"0\" cols=\"12\" frame=\"VOID\" rules=\"NONE\">\r\n	<tbody>\r\n		<tr>\r\n			<td align=\"CENTER\" colspan=\"12\" height=\"21\" valign=\"BOTTOM\" width=\"771\">\r\n				<b><font size=\"3\">ANNEX A2</font></b></td>\r\n		</tr>\r\n		<tr>\r\n			<td align=\"CENTER\" colspan=\"12\" height=\"18\" valign=\"BOTTOM\">\r\n				<b>PHILIPPINE HEALTH INSURANCE CORPORATION</b></td>\r\n		</tr>\r\n		<tr>\r\n			<td align=\"CENTER\" colspan=\"12\" height=\"18\" valign=\"BOTTOM\">\r\n				<b>PCB PROVIDER CLIENTELE PROFILE</b></td>\r\n		</tr>\r\n		<tr>\r\n			<td align=\"CENTER\" colspan=\"12\" height=\"18\" valign=\"BOTTOM\">\r\n				&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td align=\"CENTER\" colspan=\"12\" height=\"18\" valign=\"BOTTOM\">\r\n				____________________________<input id=\"22-2-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" />_______________________________</td>\r\n		</tr>\r\n		<tr>\r\n			<td align=\"CENTER\" colspan=\"12\" height=\"18\" valign=\"BOTTOM\">\r\n				<b>NAME OF HEALTH CARE FACILITY</b></td>\r\n		</tr>\r\n		<tr>\r\n			<td align=\"CENTER\" colspan=\"12\" height=\"18\" valign=\"BOTTOM\">\r\n				&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"12\" height=\"18\" valign=\"BOTTOM\">\r\n				<strong>I.&nbsp;&nbsp; PCB Provider Data</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"12\" height=\"18\" valign=\"BOTTOM\">\r\n				<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width: 500px;\">\r\n					<tbody>\r\n						<tr>\r\n							<td>\r\n								Region</td>\r\n							<td>\r\n								<input id=\"24-2-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								Province</td>\r\n							<td>\r\n								<input id=\"25-2-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								City/Municipality</td>\r\n							<td>\r\n								<input id=\"26-2-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								No. of assigned families</td>\r\n							<td>\r\n								<input id=\"27-2-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								&nbsp;&nbsp;&nbsp; SP - NHTS:</td>\r\n							<td>\r\n								<input id=\"30-2-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								&nbsp;&nbsp;&nbsp; SP - LGU:</td>\r\n							<td>\r\n								<input id=\"31-2-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								&nbsp;&nbsp;&nbsp; SP - NGA:</td>\r\n							<td>\r\n								<input id=\"32-2-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								&nbsp;&nbsp;&nbsp; SP - Private:</td>\r\n							<td>\r\n								<input id=\"33-2-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								&nbsp;&nbsp;&nbsp; IPP - OG</td>\r\n							<td>\r\n								<input id=\"35-2-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								&nbsp;&nbsp;&nbsp; IPP - OFW:</td>\r\n							<td>\r\n								<input id=\"34-2-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								&nbsp;&nbsp;&nbsp; Non-PHIC Members:</td>\r\n							<td>\r\n								<input id=\"29-2-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n					</tbody>\r\n				</table>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td align=\"CENTER\" colspan=\"12\" height=\"18\" valign=\"BOTTOM\">\r\n				&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"12\" height=\"18\" valign=\"BOTTOM\">\r\n				<strong>II.&nbsp;&nbsp; Age - Sex Distribution</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"12\" height=\"18\" valign=\"BOTTOM\">\r\n				<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width: 500px;\">\r\n					<tbody>\r\n						<tr>\r\n							<td>\r\n								Age Group</td>\r\n							<td colspan=\"3\">\r\n								Members and Dependents</td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								&nbsp;</td>\r\n							<td>\r\n								Male</td>\r\n							<td>\r\n								Female</td>\r\n							<td>\r\n								Total</td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								0 - 1 years</td>\r\n							<td>\r\n								<input id=\"2-15-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"2-16-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"indicator1\" indicatorid=\"1\" name=\"indicator\" readonly=\"readonly\" style=\"width:7em;text-align:center;\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								2 - 5 years</td>\r\n							<td>\r\n								<input id=\"2-19-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"2-18-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"indicator2\" indicatorid=\"2\" name=\"indicator\" readonly=\"readonly\" style=\"width:7em;text-align:center;\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								6 - 15 years</td>\r\n							<td>\r\n								<input id=\"2-22-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"2-21-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"indicator3\" indicatorid=\"3\" name=\"indicator\" readonly=\"readonly\" style=\"width:7em;text-align:center;\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								16 - 24 years</td>\r\n							<td>\r\n								<input id=\"2-13-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"2-17-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"indicator4\" indicatorid=\"4\" name=\"indicator\" readonly=\"readonly\" style=\"width:7em;text-align:center;\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								25 - 59 years</td>\r\n							<td>\r\n								<input id=\"2-12-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"2-11-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"indicator5\" indicatorid=\"5\" name=\"indicator\" readonly=\"readonly\" style=\"width:7em;text-align:center;\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								60 years and above</td>\r\n							<td>\r\n								<input id=\"2-20-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"2-14-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"indicator6\" indicatorid=\"6\" name=\"indicator\" readonly=\"readonly\" style=\"width:7em;text-align:center;\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								TOTAL</td>\r\n							<td>\r\n								<input id=\"indicator7\" indicatorid=\"7\" name=\"indicator\" readonly=\"readonly\" style=\"width:7em;text-align:center;\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"indicator8\" indicatorid=\"8\" name=\"indicator\" readonly=\"readonly\" style=\"width:7em;text-align:center;\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input dataelementid=\"2\" id=\"total2\" name=\"total\" readonly=\"readonly\" style=\"width:7em;text-align:center;\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n					</tbody>\r\n				</table>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td align=\"CENTER\" colspan=\"12\" height=\"18\" valign=\"BOTTOM\">\r\n				&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"12\" height=\"18\" valign=\"BOTTOM\">\r\n				<strong>III.&nbsp;&nbsp; Primary Preventive Services</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"12\" height=\"18\" valign=\"BOTTOM\">\r\n				<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width: 500px;\">\r\n					<tbody>\r\n						<tr>\r\n							<td>\r\n								&nbsp;</td>\r\n							<td colspan=\"2\">\r\n								Members and Dependents</td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								&nbsp;</td>\r\n							<td>\r\n								Members</td>\r\n							<td>\r\n								Dependents</td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								Breast Cancer Screening</td>\r\n							<td>\r\n								<input id=\"7-24-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"7-23-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								Female, 25 years old and above</td>\r\n							<td>\r\n								<input id=\"36-24-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"36-23-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								Cervical Cancer Screening</td>\r\n							<td>\r\n								<input id=\"6-24-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"6-23-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								Female, 25 - 55 years old with intact uterus</td>\r\n							<td>\r\n								<input id=\"12-24-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"12-23-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n					</tbody>\r\n				</table>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td align=\"CENTER\" colspan=\"12\" height=\"18\" valign=\"BOTTOM\">\r\n				&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"12\" height=\"18\" valign=\"BOTTOM\">\r\n				<strong>IV.&nbsp;&nbsp; Diabetes Mellitus</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"6\" height=\"18\" valign=\"BOTTOM\">\r\n				<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" height=\"136\" width=\"500\">\r\n					<tbody>\r\n						<tr>\r\n							<td>\r\n								Cases</td>\r\n							<td colspan=\"6\">\r\n								# of Members and Dependents</td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								&nbsp;</td>\r\n							<td colspan=\"2\">\r\n								Members</td>\r\n							<td colspan=\"2\">\r\n								Dependents</td>\r\n							<td colspan=\"2\">\r\n								Total</td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								&nbsp;</td>\r\n							<td>\r\n								M</td>\r\n							<td>\r\n								F</td>\r\n							<td>\r\n								M</td>\r\n							<td>\r\n								F</td>\r\n							<td>\r\n								M</td>\r\n							<td>\r\n								F</td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								with symptoms/signs of polyuria, polydipsia, weight loss</td>\r\n							<td>\r\n								<input id=\"13-79-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"13-82-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"13-81-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"13-80-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"indicator10\" indicatorid=\"10\" name=\"indicator\" readonly=\"readonly\" style=\"width:7em;text-align:center;\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"indicator11\" indicatorid=\"11\" name=\"indicator\" readonly=\"readonly\" style=\"width:7em;text-align:center;\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								<p>\r\n									Waist circumference&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &gt;= 80cm (female)</p>\r\n							</td>\r\n							<td>\r\n								&nbsp;</td>\r\n							<td>\r\n								<input id=\"14-82-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								&nbsp;</td>\r\n							<td>\r\n								<input id=\"14-80-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								&nbsp;</td>\r\n							<td>\r\n								<input id=\"indicator13\" indicatorid=\"13\" name=\"indicator\" readonly=\"readonly\" style=\"width:7em;text-align:center;\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &gt;= 90cm (male)</td>\r\n							<td>\r\n								<input id=\"14-79-val\" style=\"width: 7em; text-align: center; \" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								&nbsp;</td>\r\n							<td>\r\n								<input id=\"14-81-val\" style=\"width: 7em; text-align: center; \" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								&nbsp;</td>\r\n							<td>\r\n								<input id=\"indicator12\" indicatorid=\"12\" name=\"indicator\" readonly=\"readonly\" style=\"width: 7em; text-align: center; \" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								&nbsp;</td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								History of diagnosis of diabetes</td>\r\n							<td>\r\n								<input id=\"15-79-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"15-82-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"15-81-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"15-80-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"indicator14\" indicatorid=\"14\" name=\"indicator\" readonly=\"readonly\" style=\"width:7em;text-align:center;\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"indicator15\" indicatorid=\"15\" name=\"indicator\" readonly=\"readonly\" style=\"width:7em;text-align:center;\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								Intake of oral hypoglycemic agents</td>\r\n							<td>\r\n								<input id=\"17-79-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"17-82-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"17-81-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"17-80-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"indicator16\" indicatorid=\"16\" name=\"indicator\" readonly=\"readonly\" style=\"width:7em;text-align:center;\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"indicator17\" indicatorid=\"17\" name=\"indicator\" readonly=\"readonly\" style=\"width:7em;text-align:center;\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n					</tbody>\r\n				</table>\r\n			</td>\r\n			<td colspan=\"6\" height=\"18\" valign=\"BOTTOM\">\r\n				&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td align=\"CENTER\" colspan=\"12\" height=\"18\" valign=\"BOTTOM\">\r\n				&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"12\" height=\"18\" valign=\"BOTTOM\">\r\n				<strong>V.&nbsp;&nbsp; Hypertension</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"12\" height=\"18\" valign=\"BOTTOM\">\r\n				<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width: 500px;\">\r\n					<tbody>\r\n						<tr>\r\n							<td>\r\n								&nbsp;</td>\r\n							<td colspan=\"3\">\r\n								Members</td>\r\n							<td colspan=\"4\">\r\n								Dependents</td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								&nbsp;</td>\r\n							<td>\r\n								Male</td>\r\n							<td colspan=\"2\">\r\n								Female</td>\r\n							<td>\r\n								Male</td>\r\n							<td colspan=\"2\">\r\n								Female</td>\r\n							<td>\r\n								TOTAL</td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								&nbsp;</td>\r\n							<td>\r\n								&nbsp;</td>\r\n							<td>\r\n								Nonpregnant</td>\r\n							<td>\r\n								Pregnant</td>\r\n							<td>\r\n								&nbsp;</td>\r\n							<td>\r\n								Nonpregnant</td>\r\n							<td>\r\n								Pregnant</td>\r\n							<td>\r\n								&nbsp;</td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								Adult with BP &lt; 140/90 mmHg</td>\r\n							<td>\r\n								<input id=\"18-86-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"18-83-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"18-87-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"18-84-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"18-88-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"18-85-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input dataelementid=\"18\" id=\"total18\" name=\"total\" readonly=\"readonly\" style=\"width:7em;text-align:center;\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								<p>\r\n									Adult with BP &gt;= 140/90<br />\r\n									&nbsp;but less than 180/120 mmHg</p>\r\n							</td>\r\n							<td>\r\n								<input id=\"20-86-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"20-83-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"20-87-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"20-84-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"20-88-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"20-85-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input dataelementid=\"20\" id=\"total20\" name=\"total\" readonly=\"readonly\" style=\"width:7em;text-align:center;\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								Adult with BP &gt; 180/20 mmHg</td>\r\n							<td>\r\n								<input id=\"19-86-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"19-83-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"19-87-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"19-84-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"19-88-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"19-85-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input dataelementid=\"19\" id=\"total19\" name=\"total\" readonly=\"readonly\" style=\"width:7em;text-align:center;\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								History of diagnosis of hypertension</td>\r\n							<td>\r\n								<input id=\"16-86-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"16-83-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"16-87-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"16-84-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"16-88-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"16-85-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input dataelementid=\"16\" id=\"total16\" name=\"total\" readonly=\"readonly\" style=\"width:7em;text-align:center;\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n								Intake of hypertension medicine</td>\r\n							<td>\r\n								<input id=\"21-86-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"21-83-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"21-87-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"21-84-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"21-88-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input id=\"21-85-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\r\n							<td>\r\n								<input dataelementid=\"21\" id=\"total21\" name=\"total\" readonly=\"readonly\" style=\"width:7em;text-align:center;\" title=\"\" value=\"\" /></td>\r\n						</tr>\r\n					</tbody>\r\n				</table>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"12\" height=\"18\" valign=\"BOTTOM\">\r\n				&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"12\" height=\"18\" valign=\"BOTTOM\">\r\n				&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n'),(2,'PCB Form A4 ','regular','<table border=\"0\" cellspacing=\"0\" cols=\"12\" frame=\"VOID\" rules=\"NONE\">\n	<colgroup>\n		<col width=\"64\" />\n		<col width=\"64\" />\n		<col width=\"64\" />\n		<col width=\"64\" />\n		<col width=\"64\" />\n		<col width=\"64\" />\n		<col width=\"64\" />\n		<col width=\"64\" />\n		<col width=\"64\" />\n		<col width=\"64\" />\n		<col width=\"64\" />\n		<col width=\"64\" />\n	</colgroup>\n	<tbody>\n		<tr>\n			<td align=\"CENTER\" colspan=\"12\" height=\"21\" sdnum=\"1033;1033;General\" valign=\"BOTTOM\" width=\"771\">\n				<b><font size=\"3\">ANNEX A4</font></b></td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"12\" height=\"18\" sdnum=\"1033;1033;General\" valign=\"BOTTOM\">\n				<b>PHILIPPINE HEALTH INSURANCE CORPORATION</b></td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"12\" height=\"18\" sdnum=\"1033;1033;General\" valign=\"BOTTOM\">\n				<b>QUARTERLY REPORT FORM</b></td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"12\" height=\"18\" sdnum=\"1033;1033;General\" valign=\"BOTTOM\">\n				___________________________________________________________</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"12\" height=\"18\" sdnum=\"1033;1033;General\" valign=\"BOTTOM\">\n				<b>NAME OF PCB PROVIDER</b></td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"12\" height=\"18\" sdnum=\"1033;1033;General\" valign=\"BOTTOM\">\n				<b>HEALTH FACILITY DATA</b></td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"12\" height=\"18\" sdnum=\"1033;1033;General\" valign=\"BOTTOM\">\n				<b>SUMMARY OF BENEFITS AVAILMENT (Members and Dependents)</b></td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"12\" height=\"18\" sdnum=\"1033;1033;General\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"6\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 3px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">I. Covered Period</font></td>\n			<td align=\"CENTER\" colspan=\"6\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">From</font></td>\n			<td align=\"CENTER\" colspan=\"4\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"6\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">To</font></td>\n			<td align=\"CENTER\" colspan=\"4\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"6\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"6\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"6\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"6\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">II. PCB Participation No.</font></td>\n			<td align=\"CENTER\" colspan=\"6\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"6\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"6\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"6\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"6\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">III. Municipality/City/ Province</font></td>\n			<td align=\"CENTER\" colspan=\"6\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"26-2-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"6\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"25-2-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"6\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"6\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-bottom: 3px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"6\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"12\" height=\"18\" sdnum=\"1033;1033;General\" style=\"border-bottom: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"12\" height=\"18\" sdnum=\"1033;1033;General\" style=\"border-top: 3px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				IV. Obligated Services</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"11\" height=\"18\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" sdnum=\"1033;1033;General\" style=\"border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"11\" height=\"17\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"MIDDLE\">\n				<b><font face=\"Calibri\">OBLIGATED SERVICES</font></b></td>\n			<td align=\"CENTER\" sdnum=\"1033;1033;General\" style=\"border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"MIDDLE\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"11\" height=\"17\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"MIDDLE\">\n				&nbsp;</td>\n			<td align=\"CENTER\" sdnum=\"1033;1033;General\" style=\"border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"MIDDLE\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"34\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<b><font face=\"Calibri\">Primary preventive services</font></b></td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"MIDDLE\">\n				<b>TARGET<br />\n				(for the quarter)</b></td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000\" valign=\"MIDDLE\">\n				<b>Accomplishment (number)</b></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">1. BP measurement</font></td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				<i><font face=\"Calibri\">Hypertensive</font></i></td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"56-2-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"52-2-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				<i><font face=\"Calibri\">Nonhypertensive</font></i></td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"57-2-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"53-2-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">2. Periodic clinical breast examination</font></td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"58-2-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"54-2-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">3. Visual inspection with acetic acid</font></td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"59-2-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"55-2-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"12\" height=\"18\" sdnum=\"1033;1033;General\" style=\"border-bottom: 3px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"12\" height=\"18\" sdnum=\"1033;1033;General\" style=\"border-top: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"8\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 3px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"MIDDLE\">\n				<b><font face=\"Calibri\">V. Members and Dependents Served</font></b></td>\n			<td align=\"CENTER\" colspan=\"4\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"MIDDLE\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">Male:</font></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">Female:</font></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">TOTAL</font></td>\n			<td align=\"CENTER\" colspan=\"4\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">Members:</font></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"50-9-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"50-10-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"4\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">Dependents:</font></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"44-9-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"44-10-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"4\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 3px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<b><font face=\"Calibri\">TOTAL</font></b></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 3px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 3px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 3px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"4\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"12\" height=\"18\" sdnum=\"1033;1033;General\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"17\" sdnum=\"1033;1033;General\" style=\"border-top: 3px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"MIDDLE\">\n				<b><font face=\"Calibri\">VI. BENEFITS/SERVICES PROVIDED</font></b></td>\n			<td align=\"CENTER\" colspan=\"4\" sdnum=\"1033;1033;General\" style=\"border-top: 3px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<b><font face=\"Calibri\">No. of Members/</font></b></td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"5\" height=\"18\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"4\" sdnum=\"1033;1033;General\" style=\"border-bottom: 3px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<b>Dependents</b></td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-bottom: 3px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 3px solid #000000; border-bottom: 3px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<b><font face=\"Calibri\">Given</font></b></td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 3px solid #000000; border-bottom: 3px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<b><font face=\"Calibri\">Referred</font></b></td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 3px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<b><font face=\"Calibri\">Primary Preventive Services</font></b></td>\n			<td align=\"CENTER\" sdnum=\"1033;1033;General\" style=\"border-top: 3px solid #000000; border-bottom: 3px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<b>M</b></td>\n			<td align=\"CENTER\" sdnum=\"1033;1033;General\" style=\"border-top: 3px solid #000000; border-bottom: 3px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<b>D</b></td>\n			<td align=\"CENTER\" sdnum=\"1033;1033;General\" style=\"border-top: 3px solid #000000; border-bottom: 3px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<b>M</b></td>\n			<td align=\"CENTER\" sdnum=\"1033;1033;General\" style=\"border-top: 3px solid #000000; border-bottom: 3px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<b>D</b></td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">1. Consultation</font></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"41-105-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"41-103-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" bgcolor=\"#D9D9D9\" sdnum=\"1033;1033;General\" style=\"border-bottom: 1px solid #000000; border-left: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" bgcolor=\"#D9D9D9\" sdnum=\"1033;1033;General\" style=\"border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">2. Visual inspection with acetic acid </font></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"64-105-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"64-103-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" bgcolor=\"#D9D9D9\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" bgcolor=\"#D9D9D9\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">3. Regular BP measurements</font></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"61-105-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"61-103-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" bgcolor=\"#D9D9D9\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" bgcolor=\"#D9D9D9\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">4. Breastfeeding program education</font></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"38-105-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"38-103-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" bgcolor=\"#D9D9D9\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" bgcolor=\"#D9D9D9\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">5. Periodic clinical breast examinations</font></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"60-105-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"60-103-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" bgcolor=\"#D9D9D9\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" bgcolor=\"#D9D9D9\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">6. Counselling for lifestyle modification</font></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"42-105-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"42-103-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" bgcolor=\"#D9D9D9\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" bgcolor=\"#D9D9D9\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">7. Counselling for smoking cessation</font></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"43-105-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"43-103-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" bgcolor=\"#D9D9D9\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" bgcolor=\"#D9D9D9\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">8. Body measurements</font></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"37-105-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"37-103-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" bgcolor=\"#D9D9D9\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" bgcolor=\"#D9D9D9\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">9. Digital rectal examination</font></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"45-105-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"45-103-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" bgcolor=\"#D9D9D9\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" bgcolor=\"#D9D9D9\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<b><font face=\"Calibri\">Diagnostics Examinations</font></b></td>\n			<td align=\"LEFT\" bgcolor=\"#D9D9D9\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" bgcolor=\"#D9D9D9\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" bgcolor=\"#D9D9D9\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" bgcolor=\"#D9D9D9\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">1. Complete blood count (CBC)</font></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"40-105-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"40-103-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"40-102-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"40-104-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">2. Urinalysis</font></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"63-105-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"63-103-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"63-102-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"63-104-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">3. Fecalysis</font></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"47-105-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"47-103-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"47-102-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"47-104-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">4. Sputum miroscopy</font></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"62-105-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"62-103-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"62-102-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"62-104-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">5. Fasting blood sugar (FBS)</font></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"46-105-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"46-103-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"46-102-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"46-104-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">6. Lipid profile</font></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"49-105-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"49-103-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"49-102-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"49-104-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 3px solid #000000; border-left: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<font face=\"Calibri\">7. Chest x-ray</font></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 3px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"39-105-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 3px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"39-103-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 3px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"39-102-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 3px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<input id=\"39-104-val\" style=\"width:7em;text-align:center\" title=\"\" value=\"\" /></td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"12\" height=\"18\" sdnum=\"1033;1033;General\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"17\" sdnum=\"1033;1033;General\" style=\"border-top: 3px solid #000000; border-left: 3px solid #000000\" valign=\"MIDDLE\">\n				<b><font face=\"Calibri\">VII. Medicines Given (Generic Name)</font></b></td>\n			<td align=\"CENTER\" colspan=\"4\" sdnum=\"1033;1033;General\" style=\"border-top: 3px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"MIDDLE\">\n				<b><font face=\"Calibri\">No. of Members/ Dependents</font></b></td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"MIDDLE\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"5\" height=\"17\" sdnum=\"1033;1033;General\" style=\"border-bottom: 1px solid #000000; border-left: 3px solid #000000\" valign=\"MIDDLE\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"MIDDLE\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"MIDDLE\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"MIDDLE\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				<b><font face=\"Calibri\">I. Asthma</font></b></td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				<b><font face=\"Calibri\">M</font></b></td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				<b><font face=\"Calibri\">D</font></b></td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				<b><font face=\"Calibri\">II. AGE with no or mild dehydration</font></b></td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				<b><font face=\"Calibri\">III. URTI/Pneumonia (minimal &amp; low risk)</font></b></td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				<b><font face=\"Calibri\">IV. UTI</font></b></td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				<b><font face=\"Calibri\">V. Nebulisation services</font></b></td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 3px solid #000000; border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 3px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"2\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 3px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"3\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"12\" height=\"18\" sdnum=\"1033;1033;General\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"LEFT\" colspan=\"5\" height=\"17\" sdnum=\"1033;1033;General\" style=\"border-top: 3px solid #000000; border-left: 3px solid #000000\" valign=\"MIDDLE\">\n				<b><font face=\"Calibri\">VIII. Top 10 Common Illnesses (Morbidity)</font></b></td>\n			<td align=\"CENTER\" sdnum=\"1033;1033;General\" style=\"border-top: 3px solid #000000; border-left: 1px solid #000000; border-right: 3px solid #000000\" valign=\"MIDDLE\">\n				<b><font face=\"Calibri\"># of Cases</font></b></td>\n			<td align=\"CENTER\" colspan=\"6\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"6\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"6\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"6\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"6\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"6\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"6\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"6\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"6\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"6\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n		<tr>\n			<td align=\"CENTER\" colspan=\"5\" height=\"20\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 3px solid #000000; border-left: 3px solid #000000; border-right: 1px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"LEFT\" sdnum=\"1033;1033;General\" style=\"border-top: 1px solid #000000; border-bottom: 3px solid #000000; border-right: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n			<td align=\"CENTER\" colspan=\"6\" sdnum=\"1033;1033;General\" style=\"border-left: 3px solid #000000\" valign=\"BOTTOM\">\n				&nbsp;</td>\n		</tr>\n	</tbody>\n</table>\n<!-- ************************************************************************** -->');
/*!40000 ALTER TABLE `dataentryform` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dataentrystatus`
--

DROP TABLE IF EXISTS `dataentrystatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dataentrystatus` (
  `datasetid` int(11) NOT NULL,
  `organisationunitid` int(11) NOT NULL,
  `periodid` int(11) NOT NULL,
  `includezero` varchar(1) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  `storedby` varchar(50) DEFAULT NULL,
  `lastupdated` date DEFAULT NULL,
  PRIMARY KEY (`datasetid`,`organisationunitid`,`periodid`,`includezero`),
  KEY `fk_dataentrystatus_datasetid` (`datasetid`),
  KEY `fk_dataentrystatus_organisationunitid` (`organisationunitid`),
  KEY `fk_dataentrystatus_periodid` (`periodid`),
  CONSTRAINT `fk_dataentrystatus_datasetid` FOREIGN KEY (`datasetid`) REFERENCES `dataset` (`datasetid`),
  CONSTRAINT `fk_dataentrystatus_organisationunitid` FOREIGN KEY (`organisationunitid`) REFERENCES `organisationunit` (`organisationunitid`),
  CONSTRAINT `fk_dataentrystatus_periodid` FOREIGN KEY (`periodid`) REFERENCES `period` (`periodid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dataentrystatus`
--

LOCK TABLES `dataentrystatus` WRITE;
/*!40000 ALTER TABLE `dataentrystatus` DISABLE KEYS */;
/*!40000 ALTER TABLE `dataentrystatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dataset`
--

DROP TABLE IF EXISTS `dataset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dataset` (
  `datasetid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `shortName` varchar(50) DEFAULT NULL,
  `description` longtext,
  `periodtypeid` int(11) NOT NULL,
  `sortOrder` int(11) DEFAULT NULL,
  `dataEntryForm` int(11) DEFAULT NULL,
  `mobile` tinyint(1) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `expiryDays` int(11) DEFAULT NULL,
  `skipAggregation` tinyint(1) DEFAULT NULL,
  `notificationRecipients` int(11) DEFAULT NULL,
  `notifyCompletingUser` tinyint(1) DEFAULT NULL,
  `allowFuturePeriods` tinyint(1) DEFAULT NULL,
  `fieldCombinationRequired` tinyint(1) DEFAULT NULL,
  `validCompleteOnly` tinyint(1) DEFAULT NULL,
  `skipOffline` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`datasetid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `shortName` (`shortName`),
  KEY `fk_dataset_notificationrecipients` (`notificationRecipients`),
  KEY `fk_dataset_periodtypeid` (`periodtypeid`),
  KEY `fk_dataset_dataentryform` (`dataEntryForm`),
  CONSTRAINT `fk_dataset_dataentryform` FOREIGN KEY (`dataEntryForm`) REFERENCES `dataentryform` (`dataentryformid`),
  CONSTRAINT `fk_dataset_notificationrecipients` FOREIGN KEY (`notificationRecipients`) REFERENCES `usergroup` (`usergroupid`),
  CONSTRAINT `fk_dataset_periodtypeid` FOREIGN KEY (`periodtypeid`) REFERENCES `periodtype` (`periodtypeid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dataset`
--

LOCK TABLES `dataset` WRITE;
/*!40000 ALTER TABLE `dataset` DISABLE KEYS */;
INSERT INTO `dataset` VALUES (2,'PCB A2 Form','gkB9GAnH2wk','A2','2013-04-16 04:04:45','PCB A2 Form',NULL,13,NULL,1,0,90,0,0,NULL,0,0,0,0,0),(3,'PCB Form A4','WV7gKZaioyy','A4','2013-04-17 04:51:55','PCB Form A4',NULL,15,NULL,2,0,35,0,0,NULL,0,0,0,0,0);
/*!40000 ALTER TABLE `dataset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasetindicators`
--

DROP TABLE IF EXISTS `datasetindicators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasetindicators` (
  `datasetid` int(11) NOT NULL,
  `indicatorid` int(11) NOT NULL,
  PRIMARY KEY (`datasetid`,`indicatorid`),
  KEY `fk_datasetindicators_datasetid` (`datasetid`),
  KEY `fk_dataset_indicatorid` (`indicatorid`),
  CONSTRAINT `fk_datasetindicators_datasetid` FOREIGN KEY (`datasetid`) REFERENCES `dataset` (`datasetid`),
  CONSTRAINT `fk_dataset_indicatorid` FOREIGN KEY (`indicatorid`) REFERENCES `indicator` (`indicatorid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasetindicators`
--

LOCK TABLES `datasetindicators` WRITE;
/*!40000 ALTER TABLE `datasetindicators` DISABLE KEYS */;
INSERT INTO `datasetindicators` VALUES (2,1),(2,2),(2,3),(2,4),(2,5),(2,6),(2,7),(2,8),(2,10),(2,11),(2,12),(2,13),(2,14),(2,15),(2,16),(2,17);
/*!40000 ALTER TABLE `datasetindicators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasetmembers`
--

DROP TABLE IF EXISTS `datasetmembers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasetmembers` (
  `dataelementid` int(11) NOT NULL,
  `datasetid` int(11) NOT NULL,
  PRIMARY KEY (`datasetid`,`dataelementid`),
  KEY `fk_datasetmembers_datasetid` (`datasetid`),
  KEY `fk_dataset_dataelementid` (`dataelementid`),
  CONSTRAINT `fk_datasetmembers_datasetid` FOREIGN KEY (`datasetid`) REFERENCES `dataset` (`datasetid`),
  CONSTRAINT `fk_dataset_dataelementid` FOREIGN KEY (`dataelementid`) REFERENCES `dataelement` (`dataelementid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasetmembers`
--

LOCK TABLES `datasetmembers` WRITE;
/*!40000 ALTER TABLE `datasetmembers` DISABLE KEYS */;
INSERT INTO `datasetmembers` VALUES (2,2),(3,2),(5,2),(6,2),(7,2),(12,2),(13,2),(14,2),(15,2),(16,2),(17,2),(18,2),(19,2),(20,2),(21,2),(22,2),(24,2),(25,2),(26,2),(27,2),(29,2),(30,2),(31,2),(32,2),(33,2),(34,2),(35,2),(36,2),(25,3),(26,3),(37,3),(38,3),(39,3),(40,3),(41,3),(42,3),(43,3),(44,3),(45,3),(46,3),(47,3),(48,3),(49,3),(50,3),(51,3),(52,3),(53,3),(54,3),(55,3),(56,3),(57,3),(58,3),(59,3),(60,3),(61,3),(62,3),(63,3),(64,3);
/*!40000 ALTER TABLE `datasetmembers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasetoperands`
--

DROP TABLE IF EXISTS `datasetoperands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasetoperands` (
  `datasetid` int(11) NOT NULL,
  `dataelementoperandid` int(11) NOT NULL,
  PRIMARY KEY (`datasetid`,`dataelementoperandid`),
  KEY `fk_datasetoperands_datasetid` (`datasetid`),
  KEY `fk_dataset_dataelementoperandid` (`dataelementoperandid`),
  CONSTRAINT `fk_datasetoperands_datasetid` FOREIGN KEY (`datasetid`) REFERENCES `dataset` (`datasetid`),
  CONSTRAINT `fk_dataset_dataelementoperandid` FOREIGN KEY (`dataelementoperandid`) REFERENCES `dataelementoperand` (`dataelementoperandid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasetoperands`
--

LOCK TABLES `datasetoperands` WRITE;
/*!40000 ALTER TABLE `datasetoperands` DISABLE KEYS */;
/*!40000 ALTER TABLE `datasetoperands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasetsource`
--

DROP TABLE IF EXISTS `datasetsource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasetsource` (
  `datasetid` int(11) NOT NULL,
  `sourceid` int(11) NOT NULL,
  PRIMARY KEY (`datasetid`,`sourceid`),
  KEY `fk_datasetsource_datasetid` (`datasetid`),
  KEY `fk_dataset_organisationunit` (`sourceid`),
  CONSTRAINT `fk_datasetsource_datasetid` FOREIGN KEY (`datasetid`) REFERENCES `dataset` (`datasetid`),
  CONSTRAINT `fk_dataset_organisationunit` FOREIGN KEY (`sourceid`) REFERENCES `organisationunit` (`organisationunitid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasetsource`
--

LOCK TABLES `datasetsource` WRITE;
/*!40000 ALTER TABLE `datasetsource` DISABLE KEYS */;
INSERT INTO `datasetsource` VALUES (3,2);
/*!40000 ALTER TABLE `datasetsource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datavalue`
--

DROP TABLE IF EXISTS `datavalue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datavalue` (
  `dataelementid` int(11) NOT NULL,
  `periodid` int(11) NOT NULL,
  `sourceid` int(11) NOT NULL,
  `categoryoptioncomboid` int(11) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  `storedby` varchar(100) DEFAULT NULL,
  `lastupdated` date DEFAULT NULL,
  `comment` longtext,
  `followup` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`dataelementid`,`periodid`,`sourceid`,`categoryoptioncomboid`),
  KEY `fk_datavalue_dataelementid` (`dataelementid`),
  KEY `fk_datavalue_categoryoptioncomboid` (`categoryoptioncomboid`),
  KEY `fk_datavalue_organisationunitid` (`sourceid`),
  KEY `fk_datavalue_periodid` (`periodid`),
  KEY `crosstab` (`periodid`,`sourceid`),
  CONSTRAINT `fk_datavalue_categoryoptioncomboid` FOREIGN KEY (`categoryoptioncomboid`) REFERENCES `categoryoptioncombo` (`categoryoptioncomboid`),
  CONSTRAINT `fk_datavalue_dataelementid` FOREIGN KEY (`dataelementid`) REFERENCES `dataelement` (`dataelementid`),
  CONSTRAINT `fk_datavalue_organisationunitid` FOREIGN KEY (`sourceid`) REFERENCES `organisationunit` (`organisationunitid`),
  CONSTRAINT `fk_datavalue_periodid` FOREIGN KEY (`periodid`) REFERENCES `period` (`periodid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datavalue`
--

LOCK TABLES `datavalue` WRITE;
/*!40000 ALTER TABLE `datavalue` DISABLE KEYS */;
INSERT INTO `datavalue` VALUES (2,3,2,11,'158',NULL,NULL,NULL,0),(2,3,2,12,'51',NULL,NULL,NULL,0),(2,3,2,13,'23',NULL,NULL,NULL,0),(2,3,2,14,'13',NULL,NULL,NULL,0),(2,3,2,15,'80',NULL,NULL,NULL,0),(2,3,2,16,'66',NULL,NULL,NULL,0),(2,3,2,17,'79',NULL,NULL,NULL,0),(2,3,2,18,'12',NULL,NULL,NULL,0),(2,3,2,19,'19',NULL,NULL,NULL,0),(2,3,2,20,'2',NULL,NULL,NULL,0),(2,3,2,21,'7',NULL,NULL,NULL,0),(2,3,2,22,'6',NULL,NULL,NULL,0),(2,4,2,11,'0',NULL,NULL,NULL,0),(2,4,2,12,'0',NULL,NULL,NULL,0),(2,4,2,13,'0',NULL,NULL,NULL,0),(2,4,2,14,'0',NULL,NULL,NULL,0),(2,4,2,15,'0',NULL,NULL,NULL,0),(2,4,2,16,'0',NULL,NULL,NULL,0),(2,4,2,17,'1',NULL,NULL,NULL,0),(2,4,2,18,'0',NULL,NULL,NULL,0),(2,4,2,19,'0',NULL,NULL,NULL,0),(2,4,2,20,'0',NULL,NULL,NULL,0),(2,4,2,21,'0',NULL,NULL,NULL,0),(2,4,2,22,'0',NULL,NULL,NULL,0),(2,11,2,11,'1',NULL,NULL,NULL,0),(2,11,2,12,'1',NULL,NULL,NULL,0),(2,11,2,13,'1',NULL,NULL,NULL,0),(2,11,2,14,'1',NULL,NULL,NULL,0),(2,11,2,15,'28',NULL,NULL,NULL,0),(2,11,2,16,'27',NULL,NULL,NULL,0),(2,11,2,17,'1',NULL,NULL,NULL,0),(2,11,2,18,'1',NULL,NULL,NULL,0),(2,11,2,19,'1',NULL,NULL,NULL,0),(2,11,2,20,'1',NULL,NULL,NULL,0),(2,11,2,21,'1',NULL,NULL,NULL,0),(2,11,2,22,'1',NULL,NULL,NULL,0),(2,17,2,11,'0',NULL,NULL,NULL,0),(2,17,2,12,'0',NULL,NULL,NULL,0),(2,17,2,13,'0',NULL,NULL,NULL,0),(2,17,2,14,'0',NULL,NULL,NULL,0),(2,17,2,15,'0',NULL,NULL,NULL,0),(2,17,2,16,'1',NULL,NULL,NULL,0),(2,17,2,17,'0',NULL,NULL,NULL,0),(2,17,2,18,'0',NULL,NULL,NULL,0),(2,17,2,19,'0',NULL,NULL,NULL,0),(2,17,2,20,'0',NULL,NULL,NULL,0),(2,17,2,21,'0',NULL,NULL,NULL,0),(2,17,2,22,'0',NULL,NULL,NULL,0),(2,19,2,11,'0',NULL,NULL,NULL,0),(2,19,2,12,'1',NULL,NULL,NULL,0),(2,19,2,13,'1',NULL,NULL,NULL,0),(2,19,2,14,'0',NULL,NULL,NULL,0),(2,19,2,15,'0',NULL,NULL,NULL,0),(2,19,2,16,'0',NULL,NULL,NULL,0),(2,19,2,17,'0',NULL,NULL,NULL,0),(2,19,2,18,'0',NULL,NULL,NULL,0),(2,19,2,19,'0',NULL,NULL,NULL,0),(2,19,2,20,'0',NULL,NULL,NULL,0),(2,19,2,21,'0',NULL,NULL,NULL,0),(2,19,2,22,'0',NULL,NULL,NULL,0),(6,3,2,23,'2',NULL,NULL,NULL,0),(6,3,2,24,'2',NULL,NULL,NULL,0),(6,4,2,23,'0',NULL,NULL,NULL,0),(6,4,2,24,'0',NULL,NULL,NULL,0),(6,11,2,23,'0',NULL,NULL,NULL,0),(6,11,2,24,'0',NULL,NULL,NULL,0),(6,17,2,23,'0',NULL,NULL,NULL,0),(6,17,2,24,'0',NULL,NULL,NULL,0),(6,19,2,23,'0',NULL,NULL,NULL,0),(6,19,2,24,'1',NULL,NULL,NULL,0),(7,3,2,23,'5',NULL,NULL,NULL,0),(7,3,2,24,'5',NULL,NULL,NULL,0),(7,4,2,23,'0',NULL,NULL,NULL,0),(7,4,2,24,'0',NULL,NULL,NULL,0),(7,11,2,23,'0',NULL,NULL,NULL,0),(7,11,2,24,'0',NULL,NULL,NULL,0),(7,17,2,23,'0',NULL,NULL,NULL,0),(7,17,2,24,'0',NULL,NULL,NULL,0),(7,19,2,23,'0',NULL,NULL,NULL,0),(7,19,2,24,'1',NULL,NULL,NULL,0),(12,3,2,23,'151',NULL,NULL,NULL,0),(12,3,2,24,'151',NULL,NULL,NULL,0),(12,4,2,23,'0',NULL,NULL,NULL,0),(12,4,2,24,'0',NULL,NULL,NULL,0),(12,11,2,23,'0',NULL,NULL,NULL,0),(12,11,2,24,'0',NULL,NULL,NULL,0),(12,17,2,23,'0',NULL,NULL,NULL,0),(12,17,2,24,'0',NULL,NULL,NULL,0),(12,19,2,23,'0',NULL,NULL,NULL,0),(12,19,2,24,'0',NULL,NULL,NULL,0),(13,3,2,79,'2',NULL,NULL,NULL,0),(13,3,2,80,'0',NULL,NULL,NULL,0),(13,3,2,81,'0',NULL,NULL,NULL,0),(13,3,2,82,'0',NULL,NULL,NULL,0),(13,4,2,79,'0',NULL,NULL,NULL,0),(13,4,2,80,'0',NULL,NULL,NULL,0),(13,4,2,81,'0',NULL,NULL,NULL,0),(13,4,2,82,'0',NULL,NULL,NULL,0),(13,11,2,79,'0',NULL,NULL,NULL,0),(13,11,2,80,'0',NULL,NULL,NULL,0),(13,11,2,81,'0',NULL,NULL,NULL,0),(13,11,2,82,'0',NULL,NULL,NULL,0),(13,17,2,79,'0',NULL,NULL,NULL,0),(13,17,2,80,'0',NULL,NULL,NULL,0),(13,17,2,81,'0',NULL,NULL,NULL,0),(13,17,2,82,'0',NULL,NULL,NULL,0),(13,19,2,79,'1',NULL,NULL,NULL,0),(13,19,2,80,'0',NULL,NULL,NULL,0),(13,19,2,81,'0',NULL,NULL,NULL,0),(13,19,2,82,'0',NULL,NULL,NULL,0),(14,3,2,79,'0',NULL,NULL,NULL,0),(14,3,2,80,'0',NULL,NULL,NULL,0),(14,3,2,81,'0',NULL,NULL,NULL,0),(14,3,2,82,'0',NULL,NULL,NULL,0),(14,4,2,79,'0',NULL,NULL,NULL,0),(14,4,2,80,'0',NULL,NULL,NULL,0),(14,4,2,81,'0',NULL,NULL,NULL,0),(14,4,2,82,'0',NULL,NULL,NULL,0),(14,11,2,79,'0',NULL,NULL,NULL,0),(14,11,2,80,'0',NULL,NULL,NULL,0),(14,11,2,81,'0',NULL,NULL,NULL,0),(14,11,2,82,'0',NULL,NULL,NULL,0),(14,17,2,79,'0',NULL,NULL,NULL,0),(14,17,2,80,'0',NULL,NULL,NULL,0),(14,17,2,81,'0',NULL,NULL,NULL,0),(14,17,2,82,'0',NULL,NULL,NULL,0),(14,19,2,79,'1',NULL,NULL,NULL,0),(14,19,2,80,'0',NULL,NULL,NULL,0),(14,19,2,81,'0',NULL,NULL,NULL,0),(14,19,2,82,'0',NULL,NULL,NULL,0),(15,3,2,79,'0',NULL,NULL,NULL,0),(15,3,2,80,'0',NULL,NULL,NULL,0),(15,3,2,81,'0',NULL,NULL,NULL,0),(15,3,2,82,'0',NULL,NULL,NULL,0),(15,4,2,79,'0',NULL,NULL,NULL,0),(15,4,2,80,'0',NULL,NULL,NULL,0),(15,4,2,81,'0',NULL,NULL,NULL,0),(15,4,2,82,'0',NULL,NULL,NULL,0),(15,11,2,79,'0',NULL,NULL,NULL,0),(15,11,2,80,'0',NULL,NULL,NULL,0),(15,11,2,81,'0',NULL,NULL,NULL,0),(15,11,2,82,'0',NULL,NULL,NULL,0),(15,17,2,79,'0',NULL,NULL,NULL,0),(15,17,2,80,'0',NULL,NULL,NULL,0),(15,17,2,81,'0',NULL,NULL,NULL,0),(15,17,2,82,'0',NULL,NULL,NULL,0),(15,19,2,79,'0',NULL,NULL,NULL,0),(15,19,2,80,'0',NULL,NULL,NULL,0),(15,19,2,81,'0',NULL,NULL,NULL,0),(15,19,2,82,'0',NULL,NULL,NULL,0),(16,3,2,83,'0',NULL,NULL,NULL,0),(16,3,2,84,'0',NULL,NULL,NULL,0),(16,3,2,85,'0',NULL,NULL,NULL,0),(16,3,2,86,'0',NULL,NULL,NULL,0),(16,3,2,87,'0',NULL,NULL,NULL,0),(16,3,2,88,'0',NULL,NULL,NULL,0),(16,4,2,83,'0',NULL,NULL,NULL,0),(16,4,2,84,'0',NULL,NULL,NULL,0),(16,4,2,85,'0',NULL,NULL,NULL,0),(16,4,2,86,'0',NULL,NULL,NULL,0),(16,4,2,87,'0',NULL,NULL,NULL,0),(16,4,2,88,'0',NULL,NULL,NULL,0),(16,11,2,83,'0',NULL,NULL,NULL,0),(16,11,2,84,'0',NULL,NULL,NULL,0),(16,11,2,85,'0',NULL,NULL,NULL,0),(16,11,2,86,'0',NULL,NULL,NULL,0),(16,11,2,87,'0',NULL,NULL,NULL,0),(16,11,2,88,'0',NULL,NULL,NULL,0),(16,17,2,83,'0',NULL,NULL,NULL,0),(16,17,2,84,'0',NULL,NULL,NULL,0),(16,17,2,85,'0',NULL,NULL,NULL,0),(16,17,2,86,'0',NULL,NULL,NULL,0),(16,17,2,87,'0',NULL,NULL,NULL,0),(16,17,2,88,'0',NULL,NULL,NULL,0),(16,19,2,83,'0',NULL,NULL,NULL,0),(16,19,2,84,'0',NULL,NULL,NULL,0),(16,19,2,85,'0',NULL,NULL,NULL,0),(16,19,2,86,'2',NULL,NULL,NULL,0),(16,19,2,87,'0',NULL,NULL,NULL,0),(16,19,2,88,'0',NULL,NULL,NULL,0),(17,3,2,79,'0',NULL,NULL,NULL,0),(17,3,2,80,'0',NULL,NULL,NULL,0),(17,3,2,81,'0',NULL,NULL,NULL,0),(17,3,2,82,'0',NULL,NULL,NULL,0),(17,4,2,79,'0',NULL,NULL,NULL,0),(17,4,2,80,'0',NULL,NULL,NULL,0),(17,4,2,81,'0',NULL,NULL,NULL,0),(17,4,2,82,'0',NULL,NULL,NULL,0),(17,11,2,79,'0',NULL,NULL,NULL,0),(17,11,2,80,'0',NULL,NULL,NULL,0),(17,11,2,81,'0',NULL,NULL,NULL,0),(17,11,2,82,'0',NULL,NULL,NULL,0),(17,17,2,79,'0',NULL,NULL,NULL,0),(17,17,2,80,'0',NULL,NULL,NULL,0),(17,17,2,81,'0',NULL,NULL,NULL,0),(17,17,2,82,'0',NULL,NULL,NULL,0),(17,19,2,79,'1',NULL,NULL,NULL,0),(17,19,2,80,'0',NULL,NULL,NULL,0),(17,19,2,81,'0',NULL,NULL,NULL,0),(17,19,2,82,'0',NULL,NULL,NULL,0),(18,3,2,83,'0',NULL,NULL,NULL,0),(18,3,2,84,'0',NULL,NULL,NULL,0),(18,3,2,85,'0',NULL,NULL,NULL,0),(18,3,2,86,'0',NULL,NULL,NULL,0),(18,3,2,87,'0',NULL,NULL,NULL,0),(18,3,2,88,'0',NULL,NULL,NULL,0),(18,4,2,83,'0',NULL,NULL,NULL,0),(18,4,2,84,'0',NULL,NULL,NULL,0),(18,4,2,85,'0',NULL,NULL,NULL,0),(18,4,2,86,'0',NULL,NULL,NULL,0),(18,4,2,87,'0',NULL,NULL,NULL,0),(18,4,2,88,'0',NULL,NULL,NULL,0),(18,11,2,83,'0',NULL,NULL,NULL,0),(18,11,2,84,'0',NULL,NULL,NULL,0),(18,11,2,85,'0',NULL,NULL,NULL,0),(18,11,2,86,'0',NULL,NULL,NULL,0),(18,11,2,87,'0',NULL,NULL,NULL,0),(18,11,2,88,'0',NULL,NULL,NULL,0),(18,17,2,83,'1',NULL,NULL,NULL,0),(18,17,2,84,'0',NULL,NULL,NULL,0),(18,17,2,85,'0',NULL,NULL,NULL,0),(18,17,2,86,'0',NULL,NULL,NULL,0),(18,17,2,87,'0',NULL,NULL,NULL,0),(18,17,2,88,'0',NULL,NULL,NULL,0),(18,19,2,83,'0',NULL,NULL,NULL,0),(18,19,2,84,'0',NULL,NULL,NULL,0),(18,19,2,85,'0',NULL,NULL,NULL,0),(18,19,2,86,'1',NULL,NULL,NULL,0),(18,19,2,87,'0',NULL,NULL,NULL,0),(18,19,2,88,'0',NULL,NULL,NULL,0),(19,3,2,83,'0',NULL,NULL,NULL,0),(19,3,2,84,'0',NULL,NULL,NULL,0),(19,3,2,85,'0',NULL,NULL,NULL,0),(19,3,2,86,'0',NULL,NULL,NULL,0),(19,3,2,87,'0',NULL,NULL,NULL,0),(19,3,2,88,'0',NULL,NULL,NULL,0),(19,4,2,83,'0',NULL,NULL,NULL,0),(19,4,2,84,'0',NULL,NULL,NULL,0),(19,4,2,85,'0',NULL,NULL,NULL,0),(19,4,2,86,'0',NULL,NULL,NULL,0),(19,4,2,87,'0',NULL,NULL,NULL,0),(19,4,2,88,'0',NULL,NULL,NULL,0),(19,11,2,83,'0',NULL,NULL,NULL,0),(19,11,2,84,'0',NULL,NULL,NULL,0),(19,11,2,85,'0',NULL,NULL,NULL,0),(19,11,2,86,'0',NULL,NULL,NULL,0),(19,11,2,87,'0',NULL,NULL,NULL,0),(19,11,2,88,'0',NULL,NULL,NULL,0),(19,17,2,83,'0',NULL,NULL,NULL,0),(19,17,2,84,'0',NULL,NULL,NULL,0),(19,17,2,85,'0',NULL,NULL,NULL,0),(19,17,2,86,'0',NULL,NULL,NULL,0),(19,17,2,87,'0',NULL,NULL,NULL,0),(19,17,2,88,'0',NULL,NULL,NULL,0),(19,19,2,83,'0',NULL,NULL,NULL,0),(19,19,2,84,'0',NULL,NULL,NULL,0),(19,19,2,85,'0',NULL,NULL,NULL,0),(19,19,2,86,'1',NULL,NULL,NULL,0),(19,19,2,87,'0',NULL,NULL,NULL,0),(19,19,2,88,'0',NULL,NULL,NULL,0),(20,3,2,83,'0',NULL,NULL,NULL,0),(20,3,2,84,'0',NULL,NULL,NULL,0),(20,3,2,85,'0',NULL,NULL,NULL,0),(20,3,2,86,'0',NULL,NULL,NULL,0),(20,3,2,87,'0',NULL,NULL,NULL,0),(20,3,2,88,'0',NULL,NULL,NULL,0),(20,4,2,83,'0',NULL,NULL,NULL,0),(20,4,2,84,'0',NULL,NULL,NULL,0),(20,4,2,85,'0',NULL,NULL,NULL,0),(20,4,2,86,'0',NULL,NULL,NULL,0),(20,4,2,87,'0',NULL,NULL,NULL,0),(20,4,2,88,'0',NULL,NULL,NULL,0),(20,11,2,83,'0',NULL,NULL,NULL,0),(20,11,2,84,'0',NULL,NULL,NULL,0),(20,11,2,85,'0',NULL,NULL,NULL,0),(20,11,2,86,'0',NULL,NULL,NULL,0),(20,11,2,87,'0',NULL,NULL,NULL,0),(20,11,2,88,'0',NULL,NULL,NULL,0),(20,17,2,83,'0',NULL,NULL,NULL,0),(20,17,2,84,'0',NULL,NULL,NULL,0),(20,17,2,85,'0',NULL,NULL,NULL,0),(20,17,2,86,'0',NULL,NULL,NULL,0),(20,17,2,87,'0',NULL,NULL,NULL,0),(20,17,2,88,'0',NULL,NULL,NULL,0),(20,19,2,83,'0',NULL,NULL,NULL,0),(20,19,2,84,'0',NULL,NULL,NULL,0),(20,19,2,85,'0',NULL,NULL,NULL,0),(20,19,2,86,'0',NULL,NULL,NULL,0),(20,19,2,87,'0',NULL,NULL,NULL,0),(20,19,2,88,'0',NULL,NULL,NULL,0),(21,3,2,83,'0',NULL,NULL,NULL,0),(21,3,2,84,'0',NULL,NULL,NULL,0),(21,3,2,85,'0',NULL,NULL,NULL,0),(21,3,2,86,'0',NULL,NULL,NULL,0),(21,3,2,87,'0',NULL,NULL,NULL,0),(21,3,2,88,'0',NULL,NULL,NULL,0),(21,4,2,83,'0',NULL,NULL,NULL,0),(21,4,2,84,'0',NULL,NULL,NULL,0),(21,4,2,85,'0',NULL,NULL,NULL,0),(21,4,2,86,'0',NULL,NULL,NULL,0),(21,4,2,87,'0',NULL,NULL,NULL,0),(21,4,2,88,'0',NULL,NULL,NULL,0),(21,11,2,83,'0',NULL,NULL,NULL,0),(21,11,2,84,'0',NULL,NULL,NULL,0),(21,11,2,85,'0',NULL,NULL,NULL,0),(21,11,2,86,'0',NULL,NULL,NULL,0),(21,11,2,87,'0',NULL,NULL,NULL,0),(21,11,2,88,'0',NULL,NULL,NULL,0),(21,17,2,83,'0',NULL,NULL,NULL,0),(21,17,2,84,'0',NULL,NULL,NULL,0),(21,17,2,85,'0',NULL,NULL,NULL,0),(21,17,2,86,'0',NULL,NULL,NULL,0),(21,17,2,87,'0',NULL,NULL,NULL,0),(21,17,2,88,'0',NULL,NULL,NULL,0),(21,19,2,83,'0',NULL,NULL,NULL,0),(21,19,2,84,'0',NULL,NULL,NULL,0),(21,19,2,85,'0',NULL,NULL,NULL,0),(21,19,2,86,'1',NULL,NULL,NULL,0),(21,19,2,87,'0',NULL,NULL,NULL,0),(21,19,2,88,'0',NULL,NULL,NULL,0),(22,3,2,2,'Health Center Sample',NULL,NULL,NULL,0),(22,4,2,2,'PH000000000000000',NULL,NULL,NULL,0),(22,11,2,2,'Health Center Sample',NULL,NULL,NULL,0),(22,17,2,2,'PH000000000000000',NULL,NULL,NULL,0),(22,19,2,2,'PH000000000000000',NULL,NULL,NULL,0),(24,3,2,2,'Region Sample',NULL,NULL,NULL,0),(24,4,2,2,'IV',NULL,NULL,NULL,0),(24,11,2,2,'Region Sample',NULL,NULL,NULL,0),(24,17,2,2,'IV',NULL,NULL,NULL,0),(24,19,2,2,'IV',NULL,NULL,NULL,0),(25,3,2,2,'Province Sample',NULL,NULL,NULL,0),(25,4,2,2,'Laguna',NULL,NULL,NULL,0),(25,11,2,2,'Province Sample',NULL,NULL,NULL,0),(25,17,2,2,'Laguna',NULL,NULL,NULL,0),(25,19,2,2,'Laguna',NULL,NULL,NULL,0),(26,3,2,2,'City or Municipality Sample',NULL,NULL,NULL,0),(26,4,2,2,'Quezon City',NULL,NULL,NULL,0),(26,11,2,2,'City or Municipality Sample',NULL,NULL,NULL,0),(26,17,2,2,'Quezon City',NULL,NULL,NULL,0),(26,19,2,2,'Quezon City',NULL,NULL,NULL,0),(27,3,2,2,'299',NULL,NULL,NULL,0),(27,4,2,2,'1',NULL,NULL,NULL,0),(27,11,2,2,'299',NULL,NULL,NULL,0),(27,17,2,2,'1',NULL,NULL,NULL,0),(27,19,2,2,'1',NULL,NULL,NULL,0),(28,4,2,2,'2',NULL,NULL,NULL,0),(29,3,2,2,'451',NULL,NULL,NULL,0),(29,4,2,2,'0',NULL,NULL,NULL,0),(29,11,2,2,'490',NULL,NULL,NULL,0),(29,17,2,2,'2',NULL,NULL,NULL,0),(29,19,2,2,'0',NULL,NULL,NULL,0),(30,3,2,2,'16',NULL,NULL,NULL,0),(30,4,2,2,'1',NULL,NULL,NULL,0),(30,11,2,2,'16',NULL,NULL,NULL,0),(30,17,2,2,'0',NULL,NULL,NULL,0),(30,19,2,2,'1',NULL,NULL,NULL,0),(31,3,2,2,'18',NULL,NULL,NULL,0),(31,4,2,2,'0',NULL,NULL,NULL,0),(31,11,2,2,'19',NULL,NULL,NULL,0),(31,17,2,2,'1',NULL,NULL,NULL,0),(31,19,2,2,'1',NULL,NULL,NULL,0),(32,3,2,2,'8',NULL,NULL,NULL,0),(32,4,2,2,'0',NULL,NULL,NULL,0),(32,11,2,2,'8',NULL,NULL,NULL,0),(32,17,2,2,'0',NULL,NULL,NULL,0),(32,19,2,2,'0',NULL,NULL,NULL,0),(33,3,2,2,'0',NULL,NULL,NULL,0),(33,4,2,2,'0',NULL,NULL,NULL,0),(33,11,2,2,'0',NULL,NULL,NULL,0),(33,17,2,2,'0',NULL,NULL,NULL,0),(33,19,2,2,'0',NULL,NULL,NULL,0),(34,3,2,2,'1',NULL,NULL,NULL,0),(34,4,2,2,'0',NULL,NULL,NULL,0),(34,11,2,2,'1',NULL,NULL,NULL,0),(34,17,2,2,'0',NULL,NULL,NULL,0),(34,19,2,2,'0',NULL,NULL,NULL,0),(35,3,2,2,'8',NULL,NULL,NULL,0),(35,4,2,2,'0',NULL,NULL,NULL,0),(35,11,2,2,'7',NULL,NULL,NULL,0),(35,17,2,2,'0',NULL,NULL,NULL,0),(35,19,2,2,'0',NULL,NULL,NULL,0),(36,3,2,23,'171',NULL,NULL,NULL,0),(36,3,2,24,'171',NULL,NULL,NULL,0),(36,4,2,23,'0',NULL,NULL,NULL,0),(36,4,2,24,'0',NULL,NULL,NULL,0),(36,11,2,23,'0',NULL,NULL,NULL,0),(36,11,2,24,'0',NULL,NULL,NULL,0),(36,17,2,23,'0',NULL,NULL,NULL,0),(36,17,2,24,'0',NULL,NULL,NULL,0),(36,19,2,23,'0',NULL,NULL,NULL,0),(36,19,2,24,'0',NULL,NULL,NULL,0),(37,17,2,103,'1',NULL,NULL,NULL,0),(37,17,2,105,'0',NULL,NULL,NULL,0),(38,17,2,103,'1',NULL,NULL,NULL,0),(38,17,2,105,'0',NULL,NULL,NULL,0),(39,17,2,102,'0',NULL,NULL,NULL,0),(39,17,2,103,'0',NULL,NULL,NULL,0),(39,17,2,104,'1',NULL,NULL,NULL,0),(39,17,2,105,'0',NULL,NULL,NULL,0),(40,17,2,102,'0',NULL,NULL,NULL,0),(40,17,2,103,'0',NULL,NULL,NULL,0),(40,17,2,104,'1',NULL,NULL,NULL,0),(40,17,2,105,'0',NULL,NULL,NULL,0),(41,17,2,103,'1',NULL,NULL,NULL,0),(41,17,2,105,'0',NULL,NULL,NULL,0),(42,17,2,103,'1',NULL,NULL,NULL,0),(42,17,2,105,'0',NULL,NULL,NULL,0),(43,17,2,103,'1',NULL,NULL,NULL,0),(43,17,2,105,'0',NULL,NULL,NULL,0),(44,17,2,9,'0',NULL,NULL,NULL,0),(44,17,2,10,'1',NULL,NULL,NULL,0),(45,17,2,103,'1',NULL,NULL,NULL,0),(45,17,2,105,'0',NULL,NULL,NULL,0),(46,17,2,102,'0',NULL,NULL,NULL,0),(46,17,2,103,'0',NULL,NULL,NULL,0),(46,17,2,104,'1',NULL,NULL,NULL,0),(46,17,2,105,'0',NULL,NULL,NULL,0),(47,17,2,102,'0',NULL,NULL,NULL,0),(47,17,2,103,'0',NULL,NULL,NULL,0),(47,17,2,104,'1',NULL,NULL,NULL,0),(47,17,2,105,'0',NULL,NULL,NULL,0),(49,17,2,102,'0',NULL,NULL,NULL,0),(49,17,2,103,'0',NULL,NULL,NULL,0),(49,17,2,104,'1',NULL,NULL,NULL,0),(49,17,2,105,'0',NULL,NULL,NULL,0),(50,17,2,9,'0',NULL,NULL,NULL,0),(50,17,2,10,'0',NULL,NULL,NULL,0),(52,17,2,2,'0',NULL,NULL,NULL,0),(53,17,2,2,'1',NULL,NULL,NULL,0),(54,17,2,2,'1',NULL,NULL,NULL,0),(55,17,2,2,'1',NULL,NULL,NULL,0),(56,17,2,2,'0',NULL,NULL,NULL,0),(57,17,2,2,'1',NULL,NULL,NULL,0),(58,17,2,2,'1',NULL,NULL,NULL,0),(59,17,2,2,'1',NULL,NULL,NULL,0),(60,17,2,103,'1',NULL,NULL,NULL,0),(60,17,2,105,'0',NULL,NULL,NULL,0),(61,17,2,103,'0',NULL,NULL,NULL,0),(61,17,2,105,'0',NULL,NULL,NULL,0),(62,17,2,102,'0',NULL,NULL,NULL,0),(62,17,2,103,'0',NULL,NULL,NULL,0),(62,17,2,104,'1',NULL,NULL,NULL,0),(62,17,2,105,'0',NULL,NULL,NULL,0),(63,17,2,102,'0',NULL,NULL,NULL,0),(63,17,2,103,'0',NULL,NULL,NULL,0),(63,17,2,104,'1',NULL,NULL,NULL,0),(63,17,2,105,'0',NULL,NULL,NULL,0),(64,17,2,103,'1',NULL,NULL,NULL,0),(64,17,2,105,'0',NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `datavalue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datavalue_audit`
--

DROP TABLE IF EXISTS `datavalue_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datavalue_audit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dataelementid` int(11) DEFAULT NULL,
  `periodid` int(11) DEFAULT NULL,
  `sourceid` int(11) DEFAULT NULL,
  `categoryoptioncomboid` int(11) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `storedby` varchar(31) DEFAULT NULL,
  `lastupdated` date DEFAULT NULL,
  `comment` longtext,
  PRIMARY KEY (`id`),
  KEY `fk_datavalueaudit_datavalue` (`dataelementid`,`periodid`,`sourceid`,`categoryoptioncomboid`),
  CONSTRAINT `fk_datavalueaudit_datavalue` FOREIGN KEY (`dataelementid`, `periodid`, `sourceid`, `categoryoptioncomboid`) REFERENCES `datavalue` (`dataelementid`, `periodid`, `sourceid`, `categoryoptioncomboid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datavalue_audit`
--

LOCK TABLES `datavalue_audit` WRITE;
/*!40000 ALTER TABLE `datavalue_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `datavalue_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datavaluearchive`
--

DROP TABLE IF EXISTS `datavaluearchive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datavaluearchive` (
  `dataelementid` int(11) NOT NULL,
  `periodid` int(11) NOT NULL,
  `sourceid` int(11) NOT NULL,
  `categoryoptioncomboid` int(11) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  `storedby` varchar(31) DEFAULT NULL,
  `lastupdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `comment` varchar(360) DEFAULT NULL,
  `followup` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`dataelementid`,`periodid`,`sourceid`,`categoryoptioncomboid`),
  KEY `fk_datavaluearchive_categoryoptioncomboid` (`categoryoptioncomboid`),
  KEY `fk_datavaluearchive_periodid` (`periodid`),
  KEY `fk_datavaluearchive_sourceid` (`sourceid`),
  CONSTRAINT `fk_datavaluearchive_categoryoptioncomboid` FOREIGN KEY (`categoryoptioncomboid`) REFERENCES `categoryoptioncombo` (`categoryoptioncomboid`),
  CONSTRAINT `fk_datavaluearchive_dataelementid` FOREIGN KEY (`dataelementid`) REFERENCES `dataelement` (`dataelementid`),
  CONSTRAINT `fk_datavaluearchive_periodid` FOREIGN KEY (`periodid`) REFERENCES `period` (`periodid`),
  CONSTRAINT `fk_datavaluearchive_sourceid` FOREIGN KEY (`sourceid`) REFERENCES `organisationunit` (`organisationunitid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datavaluearchive`
--

LOCK TABLES `datavaluearchive` WRITE;
/*!40000 ALTER TABLE `datavaluearchive` DISABLE KEYS */;
/*!40000 ALTER TABLE `datavaluearchive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detarget`
--

DROP TABLE IF EXISTS `detarget`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detarget` (
  `detargetid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(160) NOT NULL,
  `shortname` varchar(60) DEFAULT NULL,
  `description` longtext,
  `url` varchar(160) DEFAULT NULL,
  PRIMARY KEY (`detargetid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `shortname` (`shortname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detarget`
--

LOCK TABLES `detarget` WRITE;
/*!40000 ALTER TABLE `detarget` DISABLE KEYS */;
/*!40000 ALTER TABLE `detarget` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detargetdatavalue`
--

DROP TABLE IF EXISTS `detargetdatavalue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detargetdatavalue` (
  `detargetid` int(11) NOT NULL,
  `dataelementid` int(11) NOT NULL,
  `categoryoptioncomboid` int(11) NOT NULL,
  `sourceid` int(11) NOT NULL,
  `periodid` int(11) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  `storedby` varchar(50) DEFAULT NULL,
  `lastupdated` date DEFAULT NULL,
  PRIMARY KEY (`detargetid`,`dataelementid`,`categoryoptioncomboid`,`sourceid`,`periodid`),
  KEY `fk_detargetdatavalue_dataelementid` (`dataelementid`),
  KEY `fk_detargetdatavalue_detargetid` (`detargetid`),
  KEY `fk_detargetdatavalue_categoryoptioncomboid` (`categoryoptioncomboid`),
  KEY `fk_detargetdatavalue_organisationunitid` (`sourceid`),
  KEY `fk_detargetdatavalue_periodid` (`periodid`),
  CONSTRAINT `fk_detargetdatavalue_categoryoptioncomboid` FOREIGN KEY (`categoryoptioncomboid`) REFERENCES `categoryoptioncombo` (`categoryoptioncomboid`),
  CONSTRAINT `fk_detargetdatavalue_dataelementid` FOREIGN KEY (`dataelementid`) REFERENCES `dataelement` (`dataelementid`),
  CONSTRAINT `fk_detargetdatavalue_detargetid` FOREIGN KEY (`detargetid`) REFERENCES `detarget` (`detargetid`),
  CONSTRAINT `fk_detargetdatavalue_organisationunitid` FOREIGN KEY (`sourceid`) REFERENCES `organisationunit` (`organisationunitid`),
  CONSTRAINT `fk_detargetdatavalue_periodid` FOREIGN KEY (`periodid`) REFERENCES `period` (`periodid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detargetdatavalue`
--

LOCK TABLES `detargetdatavalue` WRITE;
/*!40000 ALTER TABLE `detargetdatavalue` DISABLE KEYS */;
/*!40000 ALTER TABLE `detargetdatavalue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detargetmember`
--

DROP TABLE IF EXISTS `detargetmember`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detargetmember` (
  `detargetid` int(11) NOT NULL,
  `dataelementid` int(11) NOT NULL,
  `categoryoptioncomboid` int(11) NOT NULL,
  PRIMARY KEY (`detargetid`,`dataelementid`,`categoryoptioncomboid`),
  KEY `fk_detargetmember_dataelementid` (`dataelementid`),
  KEY `fk_detargetmember_detargetid` (`detargetid`),
  KEY `fk_detargetmember_categoryoptioncomboid` (`categoryoptioncomboid`),
  CONSTRAINT `fk_detargetmember_categoryoptioncomboid` FOREIGN KEY (`categoryoptioncomboid`) REFERENCES `categoryoptioncombo` (`categoryoptioncomboid`),
  CONSTRAINT `fk_detargetmember_dataelementid` FOREIGN KEY (`dataelementid`) REFERENCES `dataelement` (`dataelementid`),
  CONSTRAINT `fk_detargetmember_detargetid` FOREIGN KEY (`detargetid`) REFERENCES `detarget` (`detargetid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detargetmember`
--

LOCK TABLES `detargetmember` WRITE;
/*!40000 ALTER TABLE `detargetmember` DISABLE KEYS */;
/*!40000 ALTER TABLE `detargetmember` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detargetsource`
--

DROP TABLE IF EXISTS `detargetsource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detargetsource` (
  `detargetid` int(11) NOT NULL,
  `sourceid` int(11) NOT NULL,
  PRIMARY KEY (`detargetid`,`sourceid`),
  KEY `FK6A71FBEDB3442021` (`detargetid`),
  KEY `fk_detarget_organisationunit` (`sourceid`),
  CONSTRAINT `FK6A71FBEDB3442021` FOREIGN KEY (`detargetid`) REFERENCES `detarget` (`detargetid`),
  CONSTRAINT `fk_detarget_organisationunit` FOREIGN KEY (`sourceid`) REFERENCES `organisationunit` (`organisationunitid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detargetsource`
--

LOCK TABLES `detargetsource` WRITE;
/*!40000 ALTER TABLE `detargetsource` DISABLE KEYS */;
/*!40000 ALTER TABLE `detargetsource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document`
--

DROP TABLE IF EXISTS `document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `document` (
  `documentid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `url` longtext NOT NULL,
  `external` tinyint(1) NOT NULL,
  `contentType` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`documentid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document`
--

LOCK TABLES `document` WRITE;
/*!40000 ALTER TABLE `document` DISABLE KEYS */;
/*!40000 ALTER TABLE `document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee` (
  `pdscode` varchar(255) NOT NULL,
  `name` varchar(160) NOT NULL,
  `dob` date NOT NULL,
  `lprdate` date NOT NULL,
  `sex` varchar(10) NOT NULL,
  `govtserjoindate` date NOT NULL,
  `resadd` varchar(160) NOT NULL,
  `contactno` varchar(25) NOT NULL,
  `emergencycontactno` varchar(25) NOT NULL,
  `istransferred` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`pdscode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expression`
--

DROP TABLE IF EXISTS `expression`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expression` (
  `expressionid` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `expression` longtext,
  `nullIfBlank` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`expressionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expression`
--

LOCK TABLES `expression` WRITE;
/*!40000 ALTER TABLE `expression` DISABLE KEYS */;
/*!40000 ALTER TABLE `expression` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expressiondataelement`
--

DROP TABLE IF EXISTS `expressiondataelement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expressiondataelement` (
  `expressionid` int(11) NOT NULL,
  `dataelementid` int(11) NOT NULL,
  PRIMARY KEY (`expressionid`,`dataelementid`),
  KEY `fk_expression_dataelementid` (`dataelementid`),
  KEY `fk_expressiondataelement_expressionid` (`expressionid`),
  CONSTRAINT `fk_expressiondataelement_expressionid` FOREIGN KEY (`expressionid`) REFERENCES `expression` (`expressionid`),
  CONSTRAINT `fk_expression_dataelementid` FOREIGN KEY (`dataelementid`) REFERENCES `dataelement` (`dataelementid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expressiondataelement`
--

LOCK TABLES `expressiondataelement` WRITE;
/*!40000 ALTER TABLE `expressiondataelement` DISABLE KEYS */;
/*!40000 ALTER TABLE `expressiondataelement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expressionoptioncombo`
--

DROP TABLE IF EXISTS `expressionoptioncombo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expressionoptioncombo` (
  `expressionid` int(11) NOT NULL,
  `categoryoptioncomboid` int(11) NOT NULL,
  PRIMARY KEY (`expressionid`,`categoryoptioncomboid`),
  KEY `fk_expression_categoryoptioncomboid` (`categoryoptioncomboid`),
  KEY `fk_expressionoptioncombo_expressionid` (`expressionid`),
  CONSTRAINT `fk_expressionoptioncombo_expressionid` FOREIGN KEY (`expressionid`) REFERENCES `expression` (`expressionid`),
  CONSTRAINT `fk_expression_categoryoptioncomboid` FOREIGN KEY (`categoryoptioncomboid`) REFERENCES `categoryoptioncombo` (`categoryoptioncomboid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expressionoptioncombo`
--

LOCK TABLES `expressionoptioncombo` WRITE;
/*!40000 ALTER TABLE `expressionoptioncombo` DISABLE KEYS */;
/*!40000 ALTER TABLE `expressionoptioncombo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `importdatavalue`
--

DROP TABLE IF EXISTS `importdatavalue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `importdatavalue` (
  `dataelementid` int(11) NOT NULL,
  `categoryoptioncomboid` int(11) NOT NULL,
  `periodid` int(11) NOT NULL,
  `sourceid` int(11) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  `storedby` varchar(255) DEFAULT NULL,
  `lastupdated` date DEFAULT NULL,
  `comment` longtext,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`dataelementid`,`categoryoptioncomboid`,`periodid`,`sourceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `importdatavalue`
--

LOCK TABLES `importdatavalue` WRITE;
/*!40000 ALTER TABLE `importdatavalue` DISABLE KEYS */;
/*!40000 ALTER TABLE `importdatavalue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `importobject`
--

DROP TABLE IF EXISTS `importobject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `importobject` (
  `importobjectid` int(11) NOT NULL AUTO_INCREMENT,
  `status` tinyblob,
  `classname` varchar(255) DEFAULT NULL,
  `groupmembertype` tinyblob,
  `object` blob,
  `compareobject` blob,
  PRIMARY KEY (`importobjectid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `importobject`
--

LOCK TABLES `importobject` WRITE;
/*!40000 ALTER TABLE `importobject` DISABLE KEYS */;
/*!40000 ALTER TABLE `importobject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incomingsms`
--

DROP TABLE IF EXISTS `incomingsms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `incomingsms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `originator` varchar(255) NOT NULL,
  `encoding` int(11) NOT NULL,
  `sentDate` datetime NOT NULL,
  `receivedDate` datetime NOT NULL,
  `text` varchar(255) DEFAULT NULL,
  `gatewayId` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `statusMessage` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sms_originator_index` (`originator`),
  KEY `sms_status_index` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incomingsms`
--

LOCK TABLES `incomingsms` WRITE;
/*!40000 ALTER TABLE `incomingsms` DISABLE KEYS */;
/*!40000 ALTER TABLE `incomingsms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `indicator`
--

DROP TABLE IF EXISTS `indicator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indicator` (
  `indicatorid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `shortname` varchar(50) NOT NULL,
  `description` longtext,
  `annualized` tinyint(1) NOT NULL,
  `indicatortypeid` int(11) DEFAULT NULL,
  `numerator` longtext,
  `numeratordescription` longtext,
  `denominator` longtext,
  `denominatordescription` longtext,
  `sortOrder` int(11) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `legendsetid` int(11) DEFAULT NULL,
  PRIMARY KEY (`indicatorid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `shortname` (`shortname`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `indicator_code_key` (`code`),
  KEY `fk_indicator_indicatortypeid` (`indicatortypeid`),
  KEY `fk_indicator_legendset` (`legendsetid`),
  CONSTRAINT `fk_indicator_indicatortypeid` FOREIGN KEY (`indicatortypeid`) REFERENCES `indicatortype` (`indicatortypeid`),
  CONSTRAINT `fk_indicator_legendset` FOREIGN KEY (`legendsetid`) REFERENCES `maplegendset` (`maplegendsetid`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicator`
--

LOCK TABLES `indicator` WRITE;
/*!40000 ALTER TABLE `indicator` DISABLE KEYS */;
INSERT INTO `indicator` VALUES (1,'Age 0 - 1 years','sAgPGnIt0mV','AGE_0-1YRS','2013-02-16 17:02:17','Age 0 - 1 years',NULL,0,1,'[2.15]+[2.16]','total number with 0 - 1 years ','1','',NULL,'',NULL),(2,'Age 2 - 5 years','WUsvb7MFDGb','AGE_2-5YRS','2013-02-16 19:39:13','Age 2 - 5 years',NULL,0,1,'[2.19]+[2.18]','total number of people with age 2 - 5 years','1','',NULL,'',NULL),(3,'Age 6 - 15 years','Ee2mpDIcJio','AGE_6-15YRS','2013-02-16 19:40:16','Age 6 - 15 years',NULL,0,1,'[2.22]+[2.21]','total number of people with age 6 - 15 years','1','',NULL,'',NULL),(4,'Age 16 - 24 years','JmWevSJOVAu','AGE_16-24YRS','2013-02-16 19:41:05','Age 16 - 24 years',NULL,0,1,'[2.13]+[2.17]','total number of people with age 16 - 24 years','1','',NULL,'',NULL),(5,'Age 25 - 59 years','mytVMu1yDZ9','AGE_25-59YRS','2013-02-16 19:42:00','Age 25 - 59 years',NULL,0,1,'[2.12]+[2.11]','total number of people with age 25 - 59 years','1','',NULL,'',NULL),(6,'Age 60 years and above','MSUZpMrwnfx','AGE_60-ABOVEYRS','2013-02-16 19:43:02','Age 60 years and above',NULL,0,1,'[2.20]+[2.14]','total number of people with age 60 years and above','1','',NULL,'',NULL),(7,'Male','WrgDyd1NLue','MALE','2013-02-16 19:48:08','Male',NULL,0,1,'[2.15]+[2.19]+[2.22]+[2.13]+[2.12]+[2.20]','total number of males','1','',NULL,'',NULL),(8,'Female','Eg323R9qfOv','FEMALE','2013-02-16 19:48:54','Female',NULL,0,1,'[2.16]+[2.18]+[2.21]+[2.17]+[2.11]+[2.14]','total number of females','1','',NULL,'',NULL),(10,'Diabetes Mellitus Cases with signs and symptoms of polyuria, polydipsia and weight loss, Male','ZWxFTcTRbBN','DMSSXMALE','2013-02-16 21:20:46','DM S/Sx Male',NULL,0,1,'[13.79]+[13.81]','total number of diabetes mellitus cases with signs and symptoms among males','1','',NULL,'',NULL),(11,'Diabetes Mellitus Cases with signs and symptoms of polyuria, polydipsia and weight loss, Female','NLNn2GZ2dHD','DMSSXFEMALE','2013-02-16 21:21:24','DM S/Sx Female',NULL,0,1,'[13.82]+[13.80]','total number of diabetes mellitus cases with signs and symptoms among females','1','',NULL,'',NULL),(12,'Waist Circumference ( >=80 cm for female and <=90 cm for male), Male','dwsa8W0AcAF',NULL,'2013-02-16 21:28:56','DM Cases Waist Circ Male',NULL,0,1,'[14.79]+[14.81]','total number of diabetis mellitus cases with waist circumference >=90cm among males','1','',NULL,'',NULL),(13,'Waist Circumference ( >=80 cm for female and <=90 cm for male), Female','h3hbroZfLUi',NULL,'2013-02-16 21:30:49','DM Cases Waist Circ Female',NULL,0,1,'[14.82]+[14.80]','total number of diabetes mellitus cases with waist circumference >=90cm among females','1','',NULL,'',NULL),(14,'History of Diagnosis of Diabetes, Male','jc5YSIXJ3dL',NULL,'2013-02-16 21:52:14','Hx of Dx of Diabetes Male',NULL,0,1,'[15.79]+[15.81]','total number of cases with history of diagnosis of diabetes mellitus among males','1','',NULL,'',NULL),(15,'History of Diagnosis of Diabetes, Female','u4h1zKxhdOi',NULL,'2013-02-16 21:53:02','Hx of Dx of Diabetes Female',NULL,0,1,'[15.82]+[15.80]','total number of cases with history of diagnosis of diabetes mellitus among females','1','',NULL,'',NULL),(16,'Intake of Oral Hypoglycemics, Male','BteYnhhmP6Q',NULL,'2013-02-16 22:02:56','Intake of Oral Hypogly Male',NULL,0,1,'[17.79]+[17.81]','total number of diabetes mellitus cases with intake of oral hypoglycemics among males','1','',NULL,'',NULL),(17,'Intake of Oral Hypoglycemics, Female','G4CCyHnYVYH',NULL,'2013-02-16 22:02:33','Intake of Oral Hypogly Female',NULL,0,1,'[17.82]+[17.80]','total number of diabetes mellitus cases with intake of oral hypoglycemics among females','1','',NULL,'',NULL);
/*!40000 ALTER TABLE `indicator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `indicatorattributevalues`
--

DROP TABLE IF EXISTS `indicatorattributevalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indicatorattributevalues` (
  `indicatorid` int(11) NOT NULL,
  `attributevalueid` int(11) NOT NULL,
  PRIMARY KEY (`indicatorid`,`attributevalueid`),
  UNIQUE KEY `attributevalueid` (`attributevalueid`),
  KEY `FKF2DA64CF6D27CA40` (`indicatorid`),
  KEY `FKF2DA64CF2B8E4FD1` (`attributevalueid`),
  CONSTRAINT `FKF2DA64CF2B8E4FD1` FOREIGN KEY (`attributevalueid`) REFERENCES `attributevalue` (`attributevalueid`),
  CONSTRAINT `FKF2DA64CF6D27CA40` FOREIGN KEY (`indicatorid`) REFERENCES `indicator` (`indicatorid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicatorattributevalues`
--

LOCK TABLES `indicatorattributevalues` WRITE;
/*!40000 ALTER TABLE `indicatorattributevalues` DISABLE KEYS */;
/*!40000 ALTER TABLE `indicatorattributevalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `indicatorgroup`
--

DROP TABLE IF EXISTS `indicatorgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indicatorgroup` (
  `indicatorgroupid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  PRIMARY KEY (`indicatorgroupid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicatorgroup`
--

LOCK TABLES `indicatorgroup` WRITE;
/*!40000 ALTER TABLE `indicatorgroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `indicatorgroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `indicatorgroupattributevalues`
--

DROP TABLE IF EXISTS `indicatorgroupattributevalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indicatorgroupattributevalues` (
  `indicatorgroupid` int(11) NOT NULL,
  `attributevalueid` int(11) NOT NULL,
  PRIMARY KEY (`indicatorgroupid`,`attributevalueid`),
  UNIQUE KEY `attributevalueid` (`attributevalueid`),
  KEY `FK49FE5EEE2B8E4FD1` (`attributevalueid`),
  KEY `FK49FE5EEE8BE51834` (`indicatorgroupid`),
  CONSTRAINT `FK49FE5EEE2B8E4FD1` FOREIGN KEY (`attributevalueid`) REFERENCES `attributevalue` (`attributevalueid`),
  CONSTRAINT `FK49FE5EEE8BE51834` FOREIGN KEY (`indicatorgroupid`) REFERENCES `indicatorgroup` (`indicatorgroupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicatorgroupattributevalues`
--

LOCK TABLES `indicatorgroupattributevalues` WRITE;
/*!40000 ALTER TABLE `indicatorgroupattributevalues` DISABLE KEYS */;
/*!40000 ALTER TABLE `indicatorgroupattributevalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `indicatorgroupmembers`
--

DROP TABLE IF EXISTS `indicatorgroupmembers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indicatorgroupmembers` (
  `indicatorid` int(11) NOT NULL,
  `indicatorgroupid` int(11) NOT NULL,
  PRIMARY KEY (`indicatorgroupid`,`indicatorid`),
  KEY `fk_indicatorgroup_indicatorid` (`indicatorid`),
  KEY `fk_indicatorgroupmembers_indicatorgroupid` (`indicatorgroupid`),
  CONSTRAINT `fk_indicatorgroupmembers_indicatorgroupid` FOREIGN KEY (`indicatorgroupid`) REFERENCES `indicatorgroup` (`indicatorgroupid`),
  CONSTRAINT `fk_indicatorgroup_indicatorid` FOREIGN KEY (`indicatorid`) REFERENCES `indicator` (`indicatorid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicatorgroupmembers`
--

LOCK TABLES `indicatorgroupmembers` WRITE;
/*!40000 ALTER TABLE `indicatorgroupmembers` DISABLE KEYS */;
/*!40000 ALTER TABLE `indicatorgroupmembers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `indicatorgroupset`
--

DROP TABLE IF EXISTS `indicatorgroupset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indicatorgroupset` (
  `indicatorgroupsetid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `compulsory` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`indicatorgroupsetid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicatorgroupset`
--

LOCK TABLES `indicatorgroupset` WRITE;
/*!40000 ALTER TABLE `indicatorgroupset` DISABLE KEYS */;
/*!40000 ALTER TABLE `indicatorgroupset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `indicatorgroupsetmembers`
--

DROP TABLE IF EXISTS `indicatorgroupsetmembers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indicatorgroupsetmembers` (
  `indicatorgroupid` int(11) NOT NULL,
  `indicatorgroupsetid` int(11) NOT NULL DEFAULT '0',
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`indicatorgroupsetid`,`sort_order`),
  KEY `fk_indicatorgroupsetmembers_indicatorgroupsetid` (`indicatorgroupsetid`),
  KEY `fk_indicatorgroupset_indicatorgroupid` (`indicatorgroupid`),
  CONSTRAINT `fk_indicatorgroupsetmembers_indicatorgroupsetid` FOREIGN KEY (`indicatorgroupsetid`) REFERENCES `indicatorgroupset` (`indicatorgroupsetid`),
  CONSTRAINT `fk_indicatorgroupset_indicatorgroupid` FOREIGN KEY (`indicatorgroupid`) REFERENCES `indicatorgroup` (`indicatorgroupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicatorgroupsetmembers`
--

LOCK TABLES `indicatorgroupsetmembers` WRITE;
/*!40000 ALTER TABLE `indicatorgroupsetmembers` DISABLE KEYS */;
/*!40000 ALTER TABLE `indicatorgroupsetmembers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `indicatortype`
--

DROP TABLE IF EXISTS `indicatortype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indicatortype` (
  `indicatortypeid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `indicatorfactor` int(11) NOT NULL,
  `indicatornumber` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`indicatortypeid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicatortype`
--

LOCK TABLES `indicatortype` WRITE;
/*!40000 ALTER TABLE `indicatortype` DISABLE KEYS */;
INSERT INTO `indicatortype` VALUES (1,'count','fXxKVRgTGP8',NULL,'2013-02-16 17:00:43',1,1);
/*!40000 ALTER TABLE `indicatortype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interpretation`
--

DROP TABLE IF EXISTS `interpretation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `interpretation` (
  `interpretationid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(11) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `chartid` int(11) DEFAULT NULL,
  `mapid` int(11) DEFAULT NULL,
  `reporttableid` int(11) DEFAULT NULL,
  `datasetid` int(11) DEFAULT NULL,
  `periodid` int(11) DEFAULT NULL,
  `organisationunitid` int(11) DEFAULT NULL,
  `interpretationtext` longtext,
  `userid` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`interpretationid`),
  KEY `fk_interpretation_datasetid` (`datasetid`),
  KEY `fk_interpretation_organisationunitid` (`organisationunitid`),
  KEY `fk_interpretation_chartid` (`chartid`),
  KEY `fk_interpretation_reporttableid` (`reporttableid`),
  KEY `fk_interpretation_mapid` (`mapid`),
  KEY `fk_interpretation_periodid` (`periodid`),
  KEY `fk_interpretation_userid` (`userid`),
  KEY `interpretation_lastupdated` (`lastUpdated`),
  CONSTRAINT `fk_interpretation_chartid` FOREIGN KEY (`chartid`) REFERENCES `chart` (`chartid`),
  CONSTRAINT `fk_interpretation_datasetid` FOREIGN KEY (`datasetid`) REFERENCES `dataset` (`datasetid`),
  CONSTRAINT `fk_interpretation_mapid` FOREIGN KEY (`mapid`) REFERENCES `map` (`mapid`),
  CONSTRAINT `fk_interpretation_organisationunitid` FOREIGN KEY (`organisationunitid`) REFERENCES `organisationunit` (`organisationunitid`),
  CONSTRAINT `fk_interpretation_periodid` FOREIGN KEY (`periodid`) REFERENCES `period` (`periodid`),
  CONSTRAINT `fk_interpretation_reporttableid` FOREIGN KEY (`reporttableid`) REFERENCES `reporttable` (`reporttableid`),
  CONSTRAINT `fk_interpretation_userid` FOREIGN KEY (`userid`) REFERENCES `userinfo` (`userinfoid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interpretation`
--

LOCK TABLES `interpretation` WRITE;
/*!40000 ALTER TABLE `interpretation` DISABLE KEYS */;
/*!40000 ALTER TABLE `interpretation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interpretation_comments`
--

DROP TABLE IF EXISTS `interpretation_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `interpretation_comments` (
  `interpretationid` int(11) NOT NULL,
  `interpretationcommentid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`interpretationid`,`sort_order`),
  UNIQUE KEY `interpretationcommentid` (`interpretationcommentid`),
  KEY `fk_interpretation_comments_interpretationid` (`interpretationid`),
  KEY `fk_interpretation_comments_interpretationcommentid` (`interpretationcommentid`),
  CONSTRAINT `fk_interpretation_comments_interpretationcommentid` FOREIGN KEY (`interpretationcommentid`) REFERENCES `interpretationcomment` (`interpretationcommentid`),
  CONSTRAINT `fk_interpretation_comments_interpretationid` FOREIGN KEY (`interpretationid`) REFERENCES `interpretation` (`interpretationid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interpretation_comments`
--

LOCK TABLES `interpretation_comments` WRITE;
/*!40000 ALTER TABLE `interpretation_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `interpretation_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interpretationcomment`
--

DROP TABLE IF EXISTS `interpretationcomment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `interpretationcomment` (
  `interpretationcommentid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(11) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `commenttext` longtext,
  `userid` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`interpretationcommentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interpretationcomment`
--

LOCK TABLES `interpretationcomment` WRITE;
/*!40000 ALTER TABLE `interpretationcomment` DISABLE KEYS */;
/*!40000 ALTER TABLE `interpretationcomment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `linelist_de_map`
--

DROP TABLE IF EXISTS `linelist_de_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `linelist_de_map` (
  `llelementid` int(11) NOT NULL,
  `lloptionid` int(11) NOT NULL,
  `dataelementid` int(11) NOT NULL,
  `deoptioncomboid` int(11) NOT NULL,
  PRIMARY KEY (`llelementid`,`lloptionid`,`dataelementid`,`deoptioncomboid`),
  KEY `fk_linelistdemap_dataelementid` (`dataelementid`),
  KEY `fk_linelistdemap_llelementid` (`llelementid`),
  KEY `fk_linelistdemap_categoryoptioncomboid` (`deoptioncomboid`),
  KEY `fk_linelistdemap_lloptionid` (`lloptionid`),
  CONSTRAINT `fk_linelistdemap_categoryoptioncomboid` FOREIGN KEY (`deoptioncomboid`) REFERENCES `categoryoptioncombo` (`categoryoptioncomboid`),
  CONSTRAINT `fk_linelistdemap_dataelementid` FOREIGN KEY (`dataelementid`) REFERENCES `dataelement` (`dataelementid`),
  CONSTRAINT `fk_linelistdemap_llelementid` FOREIGN KEY (`llelementid`) REFERENCES `linelistelement` (`llelementid`),
  CONSTRAINT `fk_linelistdemap_lloptionid` FOREIGN KEY (`lloptionid`) REFERENCES `linelistoption` (`lloptionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `linelist_de_map`
--

LOCK TABLES `linelist_de_map` WRITE;
/*!40000 ALTER TABLE `linelist_de_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `linelist_de_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `linelistelement`
--

DROP TABLE IF EXISTS `linelistelement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `linelistelement` (
  `llelementid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL,
  `shortname` varchar(25) NOT NULL,
  `description` longtext,
  `datatype` varchar(25) DEFAULT NULL,
  `presentationtype` varchar(25) DEFAULT NULL,
  `sortOrder` int(11) DEFAULT NULL,
  PRIMARY KEY (`llelementid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `shortname` (`shortname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `linelistelement`
--

LOCK TABLES `linelistelement` WRITE;
/*!40000 ALTER TABLE `linelistelement` DISABLE KEYS */;
/*!40000 ALTER TABLE `linelistelement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `linelistelementoptions`
--

DROP TABLE IF EXISTS `linelistelementoptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `linelistelementoptions` (
  `llelementid` int(11) NOT NULL,
  `lloptionid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`llelementid`,`sort_order`),
  KEY `FKAE423334EEEFCD89` (`llelementid`),
  KEY `fk_linelistoption_lloptionid` (`lloptionid`),
  CONSTRAINT `FKAE423334EEEFCD89` FOREIGN KEY (`llelementid`) REFERENCES `linelistelement` (`llelementid`),
  CONSTRAINT `fk_linelistoption_lloptionid` FOREIGN KEY (`lloptionid`) REFERENCES `linelistoption` (`lloptionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `linelistelementoptions`
--

LOCK TABLES `linelistelementoptions` WRITE;
/*!40000 ALTER TABLE `linelistelementoptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `linelistelementoptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `linelistgroup`
--

DROP TABLE IF EXISTS `linelistgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `linelistgroup` (
  `llgroupid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(160) NOT NULL,
  `shortname` varchar(25) DEFAULT NULL,
  `description` longtext,
  `periodtypeid` int(11) NOT NULL,
  `sortOrder` int(11) DEFAULT NULL,
  PRIMARY KEY (`llgroupid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `shortname` (`shortname`),
  KEY `fk_linelistgroup_periodtypeid` (`periodtypeid`),
  CONSTRAINT `fk_linelistgroup_periodtypeid` FOREIGN KEY (`periodtypeid`) REFERENCES `periodtype` (`periodtypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `linelistgroup`
--

LOCK TABLES `linelistgroup` WRITE;
/*!40000 ALTER TABLE `linelistgroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `linelistgroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `linelistgroupelements`
--

DROP TABLE IF EXISTS `linelistgroupelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `linelistgroupelements` (
  `llgroupid` int(11) NOT NULL,
  `llelementid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`llgroupid`,`sort_order`),
  KEY `FKF7393F2475C58D4F` (`llgroupid`),
  KEY `fk_linelistgroup_llelementid` (`llelementid`),
  CONSTRAINT `FKF7393F2475C58D4F` FOREIGN KEY (`llgroupid`) REFERENCES `linelistgroup` (`llgroupid`),
  CONSTRAINT `fk_linelistgroup_llelementid` FOREIGN KEY (`llelementid`) REFERENCES `linelistelement` (`llelementid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `linelistgroupelements`
--

LOCK TABLES `linelistgroupelements` WRITE;
/*!40000 ALTER TABLE `linelistgroupelements` DISABLE KEYS */;
/*!40000 ALTER TABLE `linelistgroupelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `linelistlockedPeriods`
--

DROP TABLE IF EXISTS `linelistlockedPeriods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `linelistlockedPeriods` (
  `llgroupid` int(11) NOT NULL,
  `periodid` int(11) NOT NULL,
  PRIMARY KEY (`llgroupid`,`periodid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `linelistlockedPeriods`
--

LOCK TABLES `linelistlockedPeriods` WRITE;
/*!40000 ALTER TABLE `linelistlockedPeriods` DISABLE KEYS */;
/*!40000 ALTER TABLE `linelistlockedPeriods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `linelistlockedperiods`
--

DROP TABLE IF EXISTS `linelistlockedperiods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `linelistlockedperiods` (
  `llgroupid` int(11) NOT NULL,
  `periodid` int(11) NOT NULL,
  PRIMARY KEY (`llgroupid`,`periodid`),
  KEY `FK73647F1675C58D4F` (`llgroupid`),
  KEY `FK73647F165988B7D0` (`periodid`),
  CONSTRAINT `FK73647F165988B7D0` FOREIGN KEY (`periodid`) REFERENCES `period` (`periodid`),
  CONSTRAINT `FK73647F1675C58D4F` FOREIGN KEY (`llgroupid`) REFERENCES `linelistgroup` (`llgroupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `linelistlockedperiods`
--

LOCK TABLES `linelistlockedperiods` WRITE;
/*!40000 ALTER TABLE `linelistlockedperiods` DISABLE KEYS */;
/*!40000 ALTER TABLE `linelistlockedperiods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `linelistoption`
--

DROP TABLE IF EXISTS `linelistoption`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `linelistoption` (
  `lloptionid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(160) NOT NULL,
  `shortname` varchar(25) NOT NULL,
  `description` longtext,
  `sortOrder` int(11) DEFAULT NULL,
  PRIMARY KEY (`lloptionid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `shortname` (`shortname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `linelistoption`
--

LOCK TABLES `linelistoption` WRITE;
/*!40000 ALTER TABLE `linelistoption` DISABLE KEYS */;
/*!40000 ALTER TABLE `linelistoption` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `linelistsource`
--

DROP TABLE IF EXISTS `linelistsource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `linelistsource` (
  `llgroupid` int(11) NOT NULL,
  `sourceid` int(11) NOT NULL,
  PRIMARY KEY (`llgroupid`,`sourceid`),
  KEY `FK75F5F92D75C58D4F` (`llgroupid`),
  KEY `fk_llgroup_organisationunit` (`sourceid`),
  CONSTRAINT `FK75F5F92D75C58D4F` FOREIGN KEY (`llgroupid`) REFERENCES `linelistgroup` (`llgroupid`),
  CONSTRAINT `fk_llgroup_organisationunit` FOREIGN KEY (`sourceid`) REFERENCES `organisationunit` (`organisationunitid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `linelistsource`
--

LOCK TABLES `linelistsource` WRITE;
/*!40000 ALTER TABLE `linelistsource` DISABLE KEYS */;
/*!40000 ALTER TABLE `linelistsource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `linelistvalidationrule`
--

DROP TABLE IF EXISTS `linelistvalidationrule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `linelistvalidationrule` (
  `llvalidationid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` longtext,
  `operator` varchar(25) DEFAULT NULL,
  `leftside` varchar(25) DEFAULT NULL,
  `rightside` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`llvalidationid`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `linelistvalidationrule`
--

LOCK TABLES `linelistvalidationrule` WRITE;
/*!40000 ALTER TABLE `linelistvalidationrule` DISABLE KEYS */;
/*!40000 ALTER TABLE `linelistvalidationrule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `llaggregation`
--

DROP TABLE IF EXISTS `llaggregation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `llaggregation` (
  `dataelementid` int(11) NOT NULL,
  `optioncomboid` int(11) NOT NULL,
  `expression` longtext,
  `onchange` tinyint(1) NOT NULL,
  PRIMARY KEY (`dataelementid`,`optioncomboid`),
  KEY `fk_caseaggregation_optioncomboid` (`optioncomboid`),
  KEY `fk_caseaggregation_dataelementid` (`dataelementid`),
  CONSTRAINT `fk_caseaggregation_dataelementid` FOREIGN KEY (`dataelementid`) REFERENCES `dataelement` (`dataelementid`),
  CONSTRAINT `fk_caseaggregation_optioncomboid` FOREIGN KEY (`optioncomboid`) REFERENCES `categoryoptioncombo` (`categoryoptioncomboid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `llaggregation`
--

LOCK TABLES `llaggregation` WRITE;
/*!40000 ALTER TABLE `llaggregation` DISABLE KEYS */;
/*!40000 ALTER TABLE `llaggregation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lldataelementmapping`
--

DROP TABLE IF EXISTS `lldataelementmapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lldataelementmapping` (
  `lldataelementmapid` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext,
  `dataElementExpression` varchar(160) NOT NULL,
  `lineListExpression` varchar(160) NOT NULL,
  PRIMARY KEY (`lldataelementmapid`),
  UNIQUE KEY `dataElementExpression` (`dataElementExpression`),
  UNIQUE KEY `lineListExpression` (`lineListExpression`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lldataelementmapping`
--

LOCK TABLES `lldataelementmapping` WRITE;
/*!40000 ALTER TABLE `lldataelementmapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `lldataelementmapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lldatavalue`
--

DROP TABLE IF EXISTS `lldatavalue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lldatavalue` (
  `dataelementid` int(11) NOT NULL,
  `periodid` int(11) NOT NULL,
  `sourceid` int(11) NOT NULL,
  `categoryoptioncomboid` int(11) NOT NULL,
  `recordno` int(11) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  `storedby` varchar(31) DEFAULT NULL,
  `lastupdated` date DEFAULT NULL,
  `comment` longtext,
  PRIMARY KEY (`dataelementid`,`periodid`,`sourceid`,`categoryoptioncomboid`,`recordno`),
  KEY `fk_lldatavalue_dataelementid` (`dataelementid`),
  KEY `fk_lldatavalue_categoryoptioncomboid` (`categoryoptioncomboid`),
  KEY `fk_lldatavalue_organisationunitid` (`sourceid`),
  KEY `fk_lldatavalue_periodid` (`periodid`),
  CONSTRAINT `fk_lldatavalue_categoryoptioncomboid` FOREIGN KEY (`categoryoptioncomboid`) REFERENCES `categoryoptioncombo` (`categoryoptioncomboid`),
  CONSTRAINT `fk_lldatavalue_dataelementid` FOREIGN KEY (`dataelementid`) REFERENCES `dataelement` (`dataelementid`),
  CONSTRAINT `fk_lldatavalue_organisationunitid` FOREIGN KEY (`sourceid`) REFERENCES `organisationunit` (`organisationunitid`),
  CONSTRAINT `fk_lldatavalue_periodid` FOREIGN KEY (`periodid`) REFERENCES `period` (`periodid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lldatavalue`
--

LOCK TABLES `lldatavalue` WRITE;
/*!40000 ALTER TABLE `lldatavalue` DISABLE KEYS */;
/*!40000 ALTER TABLE `lldatavalue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lockexception`
--

DROP TABLE IF EXISTS `lockexception`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lockexception` (
  `lockexceptionid` int(11) NOT NULL AUTO_INCREMENT,
  `organisationunitid` int(11) DEFAULT NULL,
  `periodid` int(11) DEFAULT NULL,
  `datasetid` int(11) DEFAULT NULL,
  PRIMARY KEY (`lockexceptionid`),
  KEY `fk_lockexception_datasetid` (`datasetid`),
  KEY `fk_lockexception_organisationunitid` (`organisationunitid`),
  KEY `fk_lockexception_periodid` (`periodid`),
  CONSTRAINT `fk_lockexception_datasetid` FOREIGN KEY (`datasetid`) REFERENCES `dataset` (`datasetid`),
  CONSTRAINT `fk_lockexception_organisationunitid` FOREIGN KEY (`organisationunitid`) REFERENCES `organisationunit` (`organisationunitid`),
  CONSTRAINT `fk_lockexception_periodid` FOREIGN KEY (`periodid`) REFERENCES `period` (`periodid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lockexception`
--

LOCK TABLES `lockexception` WRITE;
/*!40000 ALTER TABLE `lockexception` DISABLE KEYS */;
/*!40000 ALTER TABLE `lockexception` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loginfailure`
--

DROP TABLE IF EXISTS `loginfailure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loginfailure` (
  `loginfailureid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`loginfailureid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loginfailure`
--

LOCK TABLES `loginfailure` WRITE;
/*!40000 ALTER TABLE `loginfailure` DISABLE KEYS */;
INSERT INTO `loginfailure` VALUES (1,'','2013-02-18 14:52:41'),(2,'','2013-02-18 23:39:35');
/*!40000 ALTER TABLE `loginfailure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `map`
--

DROP TABLE IF EXISTS `map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `map` (
  `mapid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `zoom` int(11) DEFAULT NULL,
  PRIMARY KEY (`mapid`),
  KEY `fk_mapview_userid` (`userid`),
  CONSTRAINT `fk_mapview_userid` FOREIGN KEY (`userid`) REFERENCES `userinfo` (`userinfoid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `map`
--

LOCK TABLES `map` WRITE;
/*!40000 ALTER TABLE `map` DISABLE KEYS */;
/*!40000 ALTER TABLE `map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maplayer`
--

DROP TABLE IF EXISTS `maplayer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maplayer` (
  `maplayerid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `url` longtext,
  `layers` longtext,
  `time` longtext,
  `fillcolor` varchar(255) DEFAULT NULL,
  `fillopacity` double NOT NULL,
  `strokecolor` varchar(255) DEFAULT NULL,
  `strokewidth` int(11) NOT NULL,
  PRIMARY KEY (`maplayerid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maplayer`
--

LOCK TABLES `maplayer` WRITE;
/*!40000 ALTER TABLE `maplayer` DISABLE KEYS */;
/*!40000 ALTER TABLE `maplayer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maplegend`
--

DROP TABLE IF EXISTS `maplegend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maplegend` (
  `maplegendid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `startvalue` double DEFAULT NULL,
  `endvalue` double DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`maplegendid`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maplegend`
--

LOCK TABLES `maplegend` WRITE;
/*!40000 ALTER TABLE `maplegend` DISABLE KEYS */;
/*!40000 ALTER TABLE `maplegend` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maplegendset`
--

DROP TABLE IF EXISTS `maplegendset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maplegendset` (
  `maplegendsetid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `symbolizer` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`maplegendsetid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maplegendset`
--

LOCK TABLES `maplegendset` WRITE;
/*!40000 ALTER TABLE `maplegendset` DISABLE KEYS */;
/*!40000 ALTER TABLE `maplegendset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maplegendsetmaplegend`
--

DROP TABLE IF EXISTS `maplegendsetmaplegend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maplegendsetmaplegend` (
  `legendsetid` int(11) NOT NULL,
  `maplegendid` int(11) NOT NULL,
  PRIMARY KEY (`legendsetid`,`maplegendid`),
  KEY `fk_maplegendsetmaplegend_legendsetid` (`legendsetid`),
  KEY `fk_maplegendset_maplegend` (`maplegendid`),
  CONSTRAINT `fk_maplegendsetmaplegend_legendsetid` FOREIGN KEY (`legendsetid`) REFERENCES `maplegendset` (`maplegendsetid`),
  CONSTRAINT `fk_maplegendset_maplegend` FOREIGN KEY (`maplegendid`) REFERENCES `maplegend` (`maplegendid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maplegendsetmaplegend`
--

LOCK TABLES `maplegendsetmaplegend` WRITE;
/*!40000 ALTER TABLE `maplegendsetmaplegend` DISABLE KEYS */;
/*!40000 ALTER TABLE `maplegendsetmaplegend` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mapmapviews`
--

DROP TABLE IF EXISTS `mapmapviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mapmapviews` (
  `mapid` int(11) NOT NULL,
  `mapviewid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`mapid`,`sort_order`),
  KEY `fk_mapmapview_mapviewid` (`mapviewid`),
  KEY `fk_mapmapview_mapid` (`mapid`),
  CONSTRAINT `fk_mapmapview_mapid` FOREIGN KEY (`mapid`) REFERENCES `map` (`mapid`),
  CONSTRAINT `fk_mapmapview_mapviewid` FOREIGN KEY (`mapviewid`) REFERENCES `mapview` (`mapviewid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mapmapviews`
--

LOCK TABLES `mapmapviews` WRITE;
/*!40000 ALTER TABLE `mapmapviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `mapmapviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mapview`
--

DROP TABLE IF EXISTS `mapview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mapview` (
  `mapviewid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(11) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `layer` varchar(255) DEFAULT NULL,
  `valueType` varchar(255) DEFAULT NULL,
  `indicatorgroupid` int(11) DEFAULT NULL,
  `indicatorid` int(11) DEFAULT NULL,
  `dataelementgroupid` int(11) DEFAULT NULL,
  `dataelementid` int(11) DEFAULT NULL,
  `periodid` int(11) DEFAULT NULL,
  `parentorganisationunitid` int(11) DEFAULT NULL,
  `organisationunitlevelid` int(11) DEFAULT NULL,
  `legendType` varchar(255) DEFAULT NULL,
  `method` int(11) DEFAULT NULL,
  `classes` int(11) DEFAULT NULL,
  `colorLow` varchar(255) DEFAULT NULL,
  `colorHigh` varchar(255) DEFAULT NULL,
  `legendsetid` int(11) DEFAULT NULL,
  `radiusLow` int(11) DEFAULT NULL,
  `radiusHigh` int(11) DEFAULT NULL,
  `opacity` double DEFAULT NULL,
  `orgunitgroupsetid` int(11) DEFAULT NULL,
  `areaRadius` int(11) DEFAULT NULL,
  PRIMARY KEY (`mapviewid`),
  KEY `fk_mapview_dataelementid` (`dataelementid`),
  KEY `fk_mapview_maplegendsetid` (`legendsetid`),
  KEY `fk_mapview_orgunitgroupsetid` (`orgunitgroupsetid`),
  KEY `fk_mapview_organisationunitlevelid` (`organisationunitlevelid`),
  KEY `fk_mapview_parentorganisationunitid` (`parentorganisationunitid`),
  KEY `fk_mapview_indicatorid` (`indicatorid`),
  KEY `fk_mapview_periodid` (`periodid`),
  KEY `fk_mapview_dataelementgroupid` (`dataelementgroupid`),
  KEY `fk_mapview_indicatorgroupid` (`indicatorgroupid`),
  CONSTRAINT `fk_mapview_dataelementgroupid` FOREIGN KEY (`dataelementgroupid`) REFERENCES `dataelementgroup` (`dataelementgroupid`),
  CONSTRAINT `fk_mapview_dataelementid` FOREIGN KEY (`dataelementid`) REFERENCES `dataelement` (`dataelementid`),
  CONSTRAINT `fk_mapview_indicatorgroupid` FOREIGN KEY (`indicatorgroupid`) REFERENCES `indicatorgroup` (`indicatorgroupid`),
  CONSTRAINT `fk_mapview_indicatorid` FOREIGN KEY (`indicatorid`) REFERENCES `indicator` (`indicatorid`),
  CONSTRAINT `fk_mapview_maplegendsetid` FOREIGN KEY (`legendsetid`) REFERENCES `maplegendset` (`maplegendsetid`),
  CONSTRAINT `fk_mapview_organisationunitlevelid` FOREIGN KEY (`organisationunitlevelid`) REFERENCES `orgunitlevel` (`orgunitlevelid`),
  CONSTRAINT `fk_mapview_orgunitgroupsetid` FOREIGN KEY (`orgunitgroupsetid`) REFERENCES `orgunitgroupset` (`orgunitgroupsetid`),
  CONSTRAINT `fk_mapview_parentorganisationunitid` FOREIGN KEY (`parentorganisationunitid`) REFERENCES `organisationunit` (`organisationunitid`),
  CONSTRAINT `fk_mapview_periodid` FOREIGN KEY (`periodid`) REFERENCES `period` (`periodid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mapview`
--

LOCK TABLES `mapview` WRITE;
/*!40000 ALTER TABLE `mapview` DISABLE KEYS */;
/*!40000 ALTER TABLE `mapview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `message` (
  `messageid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(11) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `messagetext` varchar(255) DEFAULT NULL,
  `metadata` varchar(255) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  PRIMARY KEY (`messageid`),
  KEY `fk_message_userid` (`userid`),
  CONSTRAINT `fk_message_userid` FOREIGN KEY (`userid`) REFERENCES `userinfo` (`userinfoid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message`
--

LOCK TABLES `message` WRITE;
/*!40000 ALTER TABLE `message` DISABLE KEYS */;
/*!40000 ALTER TABLE `message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messageconversation`
--

DROP TABLE IF EXISTS `messageconversation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messageconversation` (
  `messageconversationid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(11) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `lastsenderid` int(11) DEFAULT NULL,
  `lastmessage` datetime DEFAULT NULL,
  PRIMARY KEY (`messageconversationid`),
  KEY `fk_messageconversation_userid` (`lastsenderid`),
  KEY `messageconversation_lastmessage` (`lastmessage`),
  CONSTRAINT `fk_messageconversation_userid` FOREIGN KEY (`lastsenderid`) REFERENCES `userinfo` (`userinfoid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messageconversation`
--

LOCK TABLES `messageconversation` WRITE;
/*!40000 ALTER TABLE `messageconversation` DISABLE KEYS */;
/*!40000 ALTER TABLE `messageconversation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messageconversation_messages`
--

DROP TABLE IF EXISTS `messageconversation_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messageconversation_messages` (
  `messageconversationid` int(11) NOT NULL,
  `messageid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`messageconversationid`,`sort_order`),
  UNIQUE KEY `messageid` (`messageid`),
  KEY `fk_messageconversation_messages_messageconversationid` (`messageconversationid`),
  KEY `fk_messageconversation_messages_messageid` (`messageid`),
  CONSTRAINT `fk_messageconversation_messages_messageconversationid` FOREIGN KEY (`messageconversationid`) REFERENCES `messageconversation` (`messageconversationid`),
  CONSTRAINT `fk_messageconversation_messages_messageid` FOREIGN KEY (`messageid`) REFERENCES `message` (`messageid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messageconversation_messages`
--

LOCK TABLES `messageconversation_messages` WRITE;
/*!40000 ALTER TABLE `messageconversation_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messageconversation_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messageconversation_usermessages`
--

DROP TABLE IF EXISTS `messageconversation_usermessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messageconversation_usermessages` (
  `messageconversationid` int(11) NOT NULL,
  `usermessageid` int(11) NOT NULL,
  PRIMARY KEY (`messageconversationid`,`usermessageid`),
  UNIQUE KEY `usermessageid` (`usermessageid`),
  KEY `fk_messageconversation_usermessages_messageconversationid` (`messageconversationid`),
  KEY `fk_messageconversation_usermessages_usermessageid` (`usermessageid`),
  CONSTRAINT `fk_messageconversation_usermessages_messageconversationid` FOREIGN KEY (`messageconversationid`) REFERENCES `messageconversation` (`messageconversationid`),
  CONSTRAINT `fk_messageconversation_usermessages_usermessageid` FOREIGN KEY (`usermessageid`) REFERENCES `usermessage` (`usermessageid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messageconversation_usermessages`
--

LOCK TABLES `messageconversation_usermessages` WRITE;
/*!40000 ALTER TABLE `messageconversation_usermessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messageconversation_usermessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `minmaxdataelement`
--

DROP TABLE IF EXISTS `minmaxdataelement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `minmaxdataelement` (
  `minmaxdataelementid` int(11) NOT NULL AUTO_INCREMENT,
  `sourceid` int(11) DEFAULT NULL,
  `dataelementid` int(11) DEFAULT NULL,
  `categoryoptioncomboid` int(11) DEFAULT NULL,
  `minvalue` int(11) DEFAULT NULL,
  `maxvalue` int(11) DEFAULT NULL,
  `generated` bit(1) DEFAULT NULL,
  PRIMARY KEY (`minmaxdataelementid`),
  KEY `fk_minmaxdataelement_dataelementid` (`dataelementid`),
  KEY `fk_minmaxdataelement_categoryoptioncomboid` (`categoryoptioncomboid`),
  KEY `fk_minmaxdataelement_sourceid` (`sourceid`),
  KEY `index_minmaxdataelement` (`sourceid`,`dataelementid`,`categoryoptioncomboid`),
  KEY `fk_minmaxdataelement_organisationunitid` (`sourceid`),
  CONSTRAINT `fk_minmaxdataelement_categoryoptioncomboid` FOREIGN KEY (`categoryoptioncomboid`) REFERENCES `categoryoptioncombo` (`categoryoptioncomboid`),
  CONSTRAINT `fk_minmaxdataelement_dataelementid` FOREIGN KEY (`dataelementid`) REFERENCES `dataelement` (`dataelementid`),
  CONSTRAINT `fk_minmaxdataelement_organisationunitid` FOREIGN KEY (`sourceid`) REFERENCES `organisationunit` (`organisationunitid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `minmaxdataelement`
--

LOCK TABLES `minmaxdataelement` WRITE;
/*!40000 ALTER TABLE `minmaxdataelement` DISABLE KEYS */;
/*!40000 ALTER TABLE `minmaxdataelement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `optionset`
--

DROP TABLE IF EXISTS `optionset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `optionset` (
  `optionsetid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  PRIMARY KEY (`optionsetid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `optionset`
--

LOCK TABLES `optionset` WRITE;
/*!40000 ALTER TABLE `optionset` DISABLE KEYS */;
/*!40000 ALTER TABLE `optionset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `optionsetmembers`
--

DROP TABLE IF EXISTS `optionsetmembers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `optionsetmembers` (
  `optionsetid` int(11) NOT NULL,
  `optionvalue` longtext,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`optionsetid`,`sort_order`),
  KEY `fk_optionsetmembers_optionsetid` (`optionsetid`),
  CONSTRAINT `fk_optionsetmembers_optionsetid` FOREIGN KEY (`optionsetid`) REFERENCES `optionset` (`optionsetid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `optionsetmembers`
--

LOCK TABLES `optionsetmembers` WRITE;
/*!40000 ALTER TABLE `optionsetmembers` DISABLE KEYS */;
/*!40000 ALTER TABLE `optionsetmembers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organisationunit`
--

DROP TABLE IF EXISTS `organisationunit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organisationunit` (
  `organisationunitid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `parentid` int(11) DEFAULT NULL,
  `shortname` varchar(50) NOT NULL,
  `description` longtext,
  `openingdate` date DEFAULT NULL,
  `closeddate` date DEFAULT NULL,
  `active` tinyint(1) NOT NULL,
  `comment` longtext,
  `geoCode` varchar(255) DEFAULT NULL,
  `featureType` varchar(255) DEFAULT NULL,
  `coordinates` longtext,
  `url` varchar(255) DEFAULT NULL,
  `contactPerson` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phoneNumber` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`organisationunitid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `organisationunit_code_key` (`code`),
  KEY `fk_parentid` (`parentid`),
  KEY `in_parentid` (`parentid`),
  CONSTRAINT `fk_parentid` FOREIGN KEY (`parentid`) REFERENCES `organisationunit` (`organisationunitid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organisationunit`
--

LOCK TABLES `organisationunit` WRITE;
/*!40000 ALTER TABLE `organisationunit` DISABLE KEYS */;
INSERT INTO `organisationunit` VALUES (2,'Philippines','WtjQdnTTDMn','PH000000000000000','2013-02-17 11:41:55',NULL,'Philippines',NULL,'1900-01-01',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `organisationunit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organisationunitattributevalues`
--

DROP TABLE IF EXISTS `organisationunitattributevalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organisationunitattributevalues` (
  `organisationunitid` int(11) NOT NULL,
  `attributevalueid` int(11) NOT NULL,
  PRIMARY KEY (`organisationunitid`,`attributevalueid`),
  UNIQUE KEY `attributevalueid` (`attributevalueid`),
  KEY `FK601DDA0FB4CAAAD` (`organisationunitid`),
  KEY `FK601DDA02B8E4FD1` (`attributevalueid`),
  CONSTRAINT `FK601DDA02B8E4FD1` FOREIGN KEY (`attributevalueid`) REFERENCES `attributevalue` (`attributevalueid`),
  CONSTRAINT `FK601DDA0FB4CAAAD` FOREIGN KEY (`organisationunitid`) REFERENCES `organisationunit` (`organisationunitid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organisationunitattributevalues`
--

LOCK TABLES `organisationunitattributevalues` WRITE;
/*!40000 ALTER TABLE `organisationunitattributevalues` DISABLE KEYS */;
/*!40000 ALTER TABLE `organisationunitattributevalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orgunitgroup`
--

DROP TABLE IF EXISTS `orgunitgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orgunitgroup` (
  `orgunitgroupid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `symbol` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`orgunitgroupid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orgunitgroup`
--

LOCK TABLES `orgunitgroup` WRITE;
/*!40000 ALTER TABLE `orgunitgroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `orgunitgroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orgunitgroupattributevalues`
--

DROP TABLE IF EXISTS `orgunitgroupattributevalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orgunitgroupattributevalues` (
  `orgunitgroupid` int(11) NOT NULL,
  `attributevalueid` int(11) NOT NULL,
  PRIMARY KEY (`orgunitgroupid`,`attributevalueid`),
  UNIQUE KEY `attributevalueid` (`attributevalueid`),
  KEY `FK5B4E70C7B8B57B9D` (`orgunitgroupid`),
  KEY `FK5B4E70C72B8E4FD1` (`attributevalueid`),
  CONSTRAINT `FK5B4E70C72B8E4FD1` FOREIGN KEY (`attributevalueid`) REFERENCES `attributevalue` (`attributevalueid`),
  CONSTRAINT `FK5B4E70C7B8B57B9D` FOREIGN KEY (`orgunitgroupid`) REFERENCES `orgunitgroup` (`orgunitgroupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orgunitgroupattributevalues`
--

LOCK TABLES `orgunitgroupattributevalues` WRITE;
/*!40000 ALTER TABLE `orgunitgroupattributevalues` DISABLE KEYS */;
/*!40000 ALTER TABLE `orgunitgroupattributevalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orgunitgroupmembers`
--

DROP TABLE IF EXISTS `orgunitgroupmembers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orgunitgroupmembers` (
  `organisationunitid` int(11) NOT NULL,
  `orgunitgroupid` int(11) NOT NULL,
  PRIMARY KEY (`orgunitgroupid`,`organisationunitid`),
  KEY `fk_orgunitgroupmembers_orgunitgroupid` (`orgunitgroupid`),
  KEY `fk_orgunitgroup_organisationunitid` (`organisationunitid`),
  CONSTRAINT `fk_orgunitgroupmembers_orgunitgroupid` FOREIGN KEY (`orgunitgroupid`) REFERENCES `orgunitgroup` (`orgunitgroupid`),
  CONSTRAINT `fk_orgunitgroup_organisationunitid` FOREIGN KEY (`organisationunitid`) REFERENCES `organisationunit` (`organisationunitid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orgunitgroupmembers`
--

LOCK TABLES `orgunitgroupmembers` WRITE;
/*!40000 ALTER TABLE `orgunitgroupmembers` DISABLE KEYS */;
/*!40000 ALTER TABLE `orgunitgroupmembers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orgunitgroupset`
--

DROP TABLE IF EXISTS `orgunitgroupset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orgunitgroupset` (
  `orgunitgroupsetid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `compulsory` tinyint(1) NOT NULL,
  PRIMARY KEY (`orgunitgroupsetid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orgunitgroupset`
--

LOCK TABLES `orgunitgroupset` WRITE;
/*!40000 ALTER TABLE `orgunitgroupset` DISABLE KEYS */;
INSERT INTO `orgunitgroupset` VALUES (3,'Type','aRBVqtjWisQ',NULL,'2013-02-16 16:02:39','Type of organisation unit, examples are PHU, chiefdom and district',0),(4,'Ownership','fguBqqXaQSW',NULL,'2013-02-16 16:02:39','Ownership of organisation unit, examples are private and public',0);
/*!40000 ALTER TABLE `orgunitgroupset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orgunitgroupsetmembers`
--

DROP TABLE IF EXISTS `orgunitgroupsetmembers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orgunitgroupsetmembers` (
  `orgunitgroupid` int(11) NOT NULL,
  `orgunitgroupsetid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`orgunitgroupsetid`,`orgunitgroupid`),
  KEY `fk_orgunitgroupset_orgunitgroupid` (`orgunitgroupid`),
  KEY `fk_orgunitgroupsetmembers_orgunitgroupsetid` (`orgunitgroupsetid`),
  CONSTRAINT `fk_orgunitgroupsetmembers_orgunitgroupsetid` FOREIGN KEY (`orgunitgroupsetid`) REFERENCES `orgunitgroupset` (`orgunitgroupsetid`),
  CONSTRAINT `fk_orgunitgroupset_orgunitgroupid` FOREIGN KEY (`orgunitgroupid`) REFERENCES `orgunitgroup` (`orgunitgroupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orgunitgroupsetmembers`
--

LOCK TABLES `orgunitgroupsetmembers` WRITE;
/*!40000 ALTER TABLE `orgunitgroupsetmembers` DISABLE KEYS */;
/*!40000 ALTER TABLE `orgunitgroupsetmembers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orgunitlevel`
--

DROP TABLE IF EXISTS `orgunitlevel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orgunitlevel` (
  `orgunitlevelid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `level` int(11) NOT NULL,
  PRIMARY KEY (`orgunitlevelid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `level` (`level`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orgunitlevel`
--

LOCK TABLES `orgunitlevel` WRITE;
/*!40000 ALTER TABLE `orgunitlevel` DISABLE KEYS */;
/*!40000 ALTER TABLE `orgunitlevel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `outbound_sms`
--

DROP TABLE IF EXISTS `outbound_sms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `outbound_sms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `message` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `sender` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `outbound_sms_status_index` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `outbound_sms`
--

LOCK TABLES `outbound_sms` WRITE;
/*!40000 ALTER TABLE `outbound_sms` DISABLE KEYS */;
/*!40000 ALTER TABLE `outbound_sms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `outbound_sms_recipients`
--

DROP TABLE IF EXISTS `outbound_sms_recipients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `outbound_sms_recipients` (
  `outbound_sms_id` int(11) NOT NULL,
  `elt` longtext,
  KEY `FKCF380D4FE9F35B4A` (`outbound_sms_id`),
  CONSTRAINT `FKCF380D4FE9F35B4A` FOREIGN KEY (`outbound_sms_id`) REFERENCES `outbound_sms` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `outbound_sms_recipients`
--

LOCK TABLES `outbound_sms_recipients` WRITE;
/*!40000 ALTER TABLE `outbound_sms_recipients` DISABLE KEYS */;
/*!40000 ALTER TABLE `outbound_sms_recipients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient` (
  `patientid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) DEFAULT NULL,
  `middlename` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `birthdate` datetime NOT NULL,
  `deathdate` datetime DEFAULT NULL,
  `registrationdate` datetime NOT NULL,
  `isdead` tinyint(1) DEFAULT NULL,
  `gender` varchar(5) NOT NULL,
  `phoneNumber` varchar(25) DEFAULT NULL,
  `underage` tinyint(1) NOT NULL,
  `dobType` char(1) DEFAULT NULL,
  `representativeid` int(11) DEFAULT NULL,
  `organisationunitid` int(11) DEFAULT NULL,
  `healthworkerid` int(11) DEFAULT NULL,
  PRIMARY KEY (`patientid`),
  KEY `fk_user_patientid` (`healthworkerid`),
  KEY `fk_patient_organisationunitid` (`organisationunitid`),
  KEY `fk_representativeid` (`representativeid`),
  CONSTRAINT `fk_patient_organisationunitid` FOREIGN KEY (`organisationunitid`) REFERENCES `organisationunit` (`organisationunitid`),
  CONSTRAINT `fk_representativeid` FOREIGN KEY (`representativeid`) REFERENCES `patient` (`patientid`),
  CONSTRAINT `fk_user_patientid` FOREIGN KEY (`healthworkerid`) REFERENCES `userinfo` (`userinfoid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient`
--

LOCK TABLES `patient` WRITE;
/*!40000 ALTER TABLE `patient` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_attributes`
--

DROP TABLE IF EXISTS `patient_attributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient_attributes` (
  `patientid` int(11) NOT NULL,
  `patientattributeid` int(11) NOT NULL,
  PRIMARY KEY (`patientid`,`patientattributeid`),
  KEY `fk_patient_attributes_patientid` (`patientid`),
  KEY `fk_patient_patientattributeid` (`patientattributeid`),
  CONSTRAINT `fk_patient_attributes_patientid` FOREIGN KEY (`patientid`) REFERENCES `patient` (`patientid`),
  CONSTRAINT `fk_patient_patientattributeid` FOREIGN KEY (`patientattributeid`) REFERENCES `patientattribute` (`patientattributeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_attributes`
--

LOCK TABLES `patient_attributes` WRITE;
/*!40000 ALTER TABLE `patient_attributes` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_attributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_programs`
--

DROP TABLE IF EXISTS `patient_programs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient_programs` (
  `patientid` int(11) NOT NULL,
  `programid` int(11) NOT NULL,
  PRIMARY KEY (`patientid`,`programid`),
  KEY `fk_patient_programs_patientid` (`patientid`),
  KEY `fk_patient_programid` (`programid`),
  CONSTRAINT `fk_patient_programid` FOREIGN KEY (`programid`) REFERENCES `program` (`programid`),
  CONSTRAINT `fk_patient_programs_patientid` FOREIGN KEY (`patientid`) REFERENCES `patient` (`patientid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_programs`
--

LOCK TABLES `patient_programs` WRITE;
/*!40000 ALTER TABLE `patient_programs` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_programs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patientattribute`
--

DROP TABLE IF EXISTS `patientattribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patientattribute` (
  `patientattributeid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `valuetype` varchar(255) NOT NULL,
  `mandatory` tinyint(1) NOT NULL,
  `groupby` tinyint(1) DEFAULT NULL,
  `patientattributegroupid` int(11) DEFAULT NULL,
  `inherit` tinyint(1) DEFAULT NULL,
  `patientmobilesettingid` int(11) DEFAULT NULL,
  `sort_order_patientattributename` int(11) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`patientattributeid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`),
  KEY `fk_attribute_group` (`patientattributegroupid`),
  KEY `FK9D9B5537E05A5BD0` (`patientmobilesettingid`),
  CONSTRAINT `FK9D9B5537E05A5BD0` FOREIGN KEY (`patientmobilesettingid`) REFERENCES `patientmobilesetting` (`patientmobilesettingid`),
  CONSTRAINT `fk_attribute_group` FOREIGN KEY (`patientattributegroupid`) REFERENCES `patientattributegroup` (`patientattributegroupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patientattribute`
--

LOCK TABLES `patientattribute` WRITE;
/*!40000 ALTER TABLE `patientattribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `patientattribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patientattributegroup`
--

DROP TABLE IF EXISTS `patientattributegroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patientattributegroup` (
  `patientattributegroupid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `sortOrder` int(11) DEFAULT NULL,
  PRIMARY KEY (`patientattributegroupid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patientattributegroup`
--

LOCK TABLES `patientattributegroup` WRITE;
/*!40000 ALTER TABLE `patientattributegroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `patientattributegroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patientattributeoption`
--

DROP TABLE IF EXISTS `patientattributeoption`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patientattributeoption` (
  `patientattributeoptionid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(160) NOT NULL,
  `patientattributeid` int(11) DEFAULT NULL,
  PRIMARY KEY (`patientattributeoptionid`),
  KEY `fk_patientattributeoption_patientattributeid` (`patientattributeid`),
  CONSTRAINT `fk_patientattributeoption_patientattributeid` FOREIGN KEY (`patientattributeid`) REFERENCES `patientattribute` (`patientattributeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patientattributeoption`
--

LOCK TABLES `patientattributeoption` WRITE;
/*!40000 ALTER TABLE `patientattributeoption` DISABLE KEYS */;
/*!40000 ALTER TABLE `patientattributeoption` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patientattributevalue`
--

DROP TABLE IF EXISTS `patientattributevalue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patientattributevalue` (
  `patientid` int(11) NOT NULL,
  `patientattributeid` int(11) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  `patientattributeoptionid` int(11) DEFAULT NULL,
  PRIMARY KEY (`patientid`,`patientattributeid`),
  KEY `fk_patientattributevalue_patientid` (`patientid`),
  KEY `fk_patientAttributeValue_patientAttributeOption` (`patientattributeoptionid`),
  KEY `fk_patientattributevalue_patientattributeid` (`patientattributeid`),
  CONSTRAINT `fk_patientattributevalue_patientattributeid` FOREIGN KEY (`patientattributeid`) REFERENCES `patientattribute` (`patientattributeid`),
  CONSTRAINT `fk_patientAttributeValue_patientAttributeOption` FOREIGN KEY (`patientattributeoptionid`) REFERENCES `patientattributeoption` (`patientattributeoptionid`),
  CONSTRAINT `fk_patientattributevalue_patientid` FOREIGN KEY (`patientid`) REFERENCES `patient` (`patientid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patientattributevalue`
--

LOCK TABLES `patientattributevalue` WRITE;
/*!40000 ALTER TABLE `patientattributevalue` DISABLE KEYS */;
/*!40000 ALTER TABLE `patientattributevalue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patientaudit`
--

DROP TABLE IF EXISTS `patientaudit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patientaudit` (
  `patientauditid` int(11) NOT NULL AUTO_INCREMENT,
  `patientid` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `visitor` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`patientauditid`),
  KEY `fk_patientauditid_patientid` (`patientid`),
  CONSTRAINT `fk_patientauditid_patientid` FOREIGN KEY (`patientid`) REFERENCES `patient` (`patientid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patientaudit`
--

LOCK TABLES `patientaudit` WRITE;
/*!40000 ALTER TABLE `patientaudit` DISABLE KEYS */;
/*!40000 ALTER TABLE `patientaudit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patientcomment`
--

DROP TABLE IF EXISTS `patientcomment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patientcomment` (
  `patientcommentid` int(11) NOT NULL AUTO_INCREMENT,
  `commenttext` varchar(255) DEFAULT NULL,
  `createddate` datetime DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `programstageinstanceid` int(11) DEFAULT NULL,
  PRIMARY KEY (`patientcommentid`),
  KEY `FK200983BABACED27D` (`programstageinstanceid`),
  CONSTRAINT `FK200983BABACED27D` FOREIGN KEY (`programstageinstanceid`) REFERENCES `programstageinstance` (`programstageinstanceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patientcomment`
--

LOCK TABLES `patientcomment` WRITE;
/*!40000 ALTER TABLE `patientcomment` DISABLE KEYS */;
/*!40000 ALTER TABLE `patientcomment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patientdatavalue`
--

DROP TABLE IF EXISTS `patientdatavalue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patientdatavalue` (
  `programstageinstanceid` int(11) NOT NULL,
  `dataelementid` int(11) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  `timestamp` date DEFAULT NULL,
  `providedElsewhere` tinyint(1) DEFAULT NULL,
  `storedby` varchar(31) DEFAULT NULL,
  PRIMARY KEY (`programstageinstanceid`,`dataelementid`),
  KEY `fk_patientdatavalue_dataelementid` (`dataelementid`),
  KEY `fk_patientdatavalue_programstageinstanceid` (`programstageinstanceid`),
  KEY `index_patientdatavalue` (`programstageinstanceid`,`dataelementid`,`value`,`timestamp`),
  CONSTRAINT `fk_patientdatavalue_dataelementid` FOREIGN KEY (`dataelementid`) REFERENCES `dataelement` (`dataelementid`),
  CONSTRAINT `fk_patientdatavalue_programstageinstanceid` FOREIGN KEY (`programstageinstanceid`) REFERENCES `programstageinstance` (`programstageinstanceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patientdatavalue`
--

LOCK TABLES `patientdatavalue` WRITE;
/*!40000 ALTER TABLE `patientdatavalue` DISABLE KEYS */;
/*!40000 ALTER TABLE `patientdatavalue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patientidentifier`
--

DROP TABLE IF EXISTS `patientidentifier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patientidentifier` (
  `patientidentifierid` int(11) NOT NULL AUTO_INCREMENT,
  `patientidentifiertypeid` int(11) DEFAULT NULL,
  `patientid` int(11) NOT NULL,
  `identifier` varchar(31) NOT NULL,
  `preferred` tinyint(1) NOT NULL,
  PRIMARY KEY (`patientidentifierid`),
  KEY `fk_patientidentifier_patient` (`patientid`),
  KEY `fk_patientidentifier_patientidentifiertypeid` (`patientidentifiertypeid`),
  CONSTRAINT `fk_patientidentifier_patient` FOREIGN KEY (`patientid`) REFERENCES `patient` (`patientid`),
  CONSTRAINT `fk_patientidentifier_patientidentifiertypeid` FOREIGN KEY (`patientidentifiertypeid`) REFERENCES `patientidentifiertype` (`patientidentifiertypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patientidentifier`
--

LOCK TABLES `patientidentifier` WRITE;
/*!40000 ALTER TABLE `patientidentifier` DISABLE KEYS */;
/*!40000 ALTER TABLE `patientidentifier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patientidentifiertype`
--

DROP TABLE IF EXISTS `patientidentifiertype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patientidentifiertype` (
  `patientidentifiertypeid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `mandatory` tinyint(1) NOT NULL,
  `related` tinyint(1) NOT NULL,
  `noChars` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `personDisplayName` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`patientidentifiertypeid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patientidentifiertype`
--

LOCK TABLES `patientidentifiertype` WRITE;
/*!40000 ALTER TABLE `patientidentifiertype` DISABLE KEYS */;
/*!40000 ALTER TABLE `patientidentifiertype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patientmobilesetting`
--

DROP TABLE IF EXISTS `patientmobilesetting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patientmobilesetting` (
  `patientmobilesettingid` int(11) NOT NULL AUTO_INCREMENT,
  `gender` tinyint(1) NOT NULL,
  `dobtype` tinyint(1) NOT NULL,
  `birthdate` tinyint(1) NOT NULL,
  `registrationdate` tinyint(1) NOT NULL,
  `autoUpdateClient` tinyint(1) DEFAULT NULL,
  `versionToUpdate` double DEFAULT NULL,
  PRIMARY KEY (`patientmobilesettingid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patientmobilesetting`
--

LOCK TABLES `patientmobilesetting` WRITE;
/*!40000 ALTER TABLE `patientmobilesetting` DISABLE KEYS */;
/*!40000 ALTER TABLE `patientmobilesetting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patientreminder`
--

DROP TABLE IF EXISTS `patientreminder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patientreminder` (
  `patientreminderid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `daysAllowedSendMessage` int(11) DEFAULT NULL,
  `templateMessage` varchar(255) DEFAULT NULL,
  `programStageid` int(11) DEFAULT NULL,
  PRIMARY KEY (`patientreminderid`),
  KEY `FKE625D6778704EE73` (`programStageid`),
  CONSTRAINT `FKE625D6778704EE73` FOREIGN KEY (`programStageid`) REFERENCES `programstage` (`programstageid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patientreminder`
--

LOCK TABLES `patientreminder` WRITE;
/*!40000 ALTER TABLE `patientreminder` DISABLE KEYS */;
/*!40000 ALTER TABLE `patientreminder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patienttabularreport`
--

DROP TABLE IF EXISTS `patienttabularreport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patienttabularreport` (
  `patienttabularreportid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `startDate` datetime DEFAULT NULL,
  `endDate` datetime DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `sortedOrgunitAsc` tinyint(1) DEFAULT NULL,
  `facilityLB` varchar(255) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  PRIMARY KEY (`patienttabularreportid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`),
  KEY `fk_patienttabularreport_userid` (`userid`),
  CONSTRAINT `fk_patienttabularreport_userid` FOREIGN KEY (`userid`) REFERENCES `userinfo` (`userinfoid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patienttabularreport`
--

LOCK TABLES `patienttabularreport` WRITE;
/*!40000 ALTER TABLE `patienttabularreport` DISABLE KEYS */;
/*!40000 ALTER TABLE `patienttabularreport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patienttabularreport_attributes`
--

DROP TABLE IF EXISTS `patienttabularreport_attributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patienttabularreport_attributes` (
  `patienttabularreportid` int(11) NOT NULL,
  `patientattributeid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`patienttabularreportid`,`sort_order`),
  KEY `FK26182CCAD6A4FF22` (`patienttabularreportid`),
  KEY `patienttabularreport_attributeid` (`patientattributeid`),
  CONSTRAINT `FK26182CCAD6A4FF22` FOREIGN KEY (`patienttabularreportid`) REFERENCES `patienttabularreport` (`patienttabularreportid`),
  CONSTRAINT `patienttabularreport_attributeid` FOREIGN KEY (`patientattributeid`) REFERENCES `patientattribute` (`patientattributeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patienttabularreport_attributes`
--

LOCK TABLES `patienttabularreport_attributes` WRITE;
/*!40000 ALTER TABLE `patienttabularreport_attributes` DISABLE KEYS */;
/*!40000 ALTER TABLE `patienttabularreport_attributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patienttabularreport_fixedattribute`
--

DROP TABLE IF EXISTS `patienttabularreport_fixedattribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patienttabularreport_fixedattribute` (
  `patienttabularreportid` int(11) NOT NULL,
  `fixedAttribute` longtext,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`patienttabularreportid`,`sort_order`),
  KEY `patienttabularreport_fixedAttribute` (`patienttabularreportid`),
  CONSTRAINT `patienttabularreport_fixedAttribute` FOREIGN KEY (`patienttabularreportid`) REFERENCES `patienttabularreport` (`patienttabularreportid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patienttabularreport_fixedattribute`
--

LOCK TABLES `patienttabularreport_fixedattribute` WRITE;
/*!40000 ALTER TABLE `patienttabularreport_fixedattribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `patienttabularreport_fixedattribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patienttabularreport_identifiers`
--

DROP TABLE IF EXISTS `patienttabularreport_identifiers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patienttabularreport_identifiers` (
  `patienttabularreportid` int(11) NOT NULL,
  `patientidentifiertypeid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`patienttabularreportid`,`sort_order`),
  KEY `FKF2D3D7D6A4FF22` (`patienttabularreportid`),
  KEY `patienttabularreport_indentifierid` (`patientidentifiertypeid`),
  CONSTRAINT `FKF2D3D7D6A4FF22` FOREIGN KEY (`patienttabularreportid`) REFERENCES `patienttabularreport` (`patienttabularreportid`),
  CONSTRAINT `patienttabularreport_indentifierid` FOREIGN KEY (`patientidentifiertypeid`) REFERENCES `patientidentifiertype` (`patientidentifiertypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patienttabularreport_identifiers`
--

LOCK TABLES `patienttabularreport_identifiers` WRITE;
/*!40000 ALTER TABLE `patienttabularreport_identifiers` DISABLE KEYS */;
/*!40000 ALTER TABLE `patienttabularreport_identifiers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patienttabularreport_organisationUnits`
--

DROP TABLE IF EXISTS `patienttabularreport_organisationUnits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patienttabularreport_organisationUnits` (
  `patienttabularreportid` int(11) NOT NULL,
  `organisationunitid` int(11) NOT NULL,
  PRIMARY KEY (`patienttabularreportid`,`organisationunitid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patienttabularreport_organisationUnits`
--

LOCK TABLES `patienttabularreport_organisationUnits` WRITE;
/*!40000 ALTER TABLE `patienttabularreport_organisationUnits` DISABLE KEYS */;
/*!40000 ALTER TABLE `patienttabularreport_organisationUnits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patienttabularreport_organisationunits`
--

DROP TABLE IF EXISTS `patienttabularreport_organisationunits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patienttabularreport_organisationunits` (
  `patienttabularreportid` int(11) NOT NULL,
  `organisationunitid` int(11) NOT NULL,
  PRIMARY KEY (`patienttabularreportid`,`organisationunitid`),
  KEY `fk_patienttabularreport_organisationUnitid` (`patienttabularreportid`),
  KEY `fk_patienttabularreportid_organisationunit` (`organisationunitid`),
  CONSTRAINT `fk_patienttabularreportid_organisationunit` FOREIGN KEY (`organisationunitid`) REFERENCES `organisationunit` (`organisationunitid`),
  CONSTRAINT `fk_patienttabularreport_organisationUnitid` FOREIGN KEY (`patienttabularreportid`) REFERENCES `patienttabularreport` (`patienttabularreportid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patienttabularreport_organisationunits`
--

LOCK TABLES `patienttabularreport_organisationunits` WRITE;
/*!40000 ALTER TABLE `patienttabularreport_organisationunits` DISABLE KEYS */;
/*!40000 ALTER TABLE `patienttabularreport_organisationunits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `period`
--

DROP TABLE IF EXISTS `period`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `period` (
  `periodid` int(11) NOT NULL AUTO_INCREMENT,
  `periodtypeid` int(11) DEFAULT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  PRIMARY KEY (`periodid`),
  UNIQUE KEY `periodtypeid` (`periodtypeid`,`startdate`,`enddate`),
  KEY `fk_period_periodtypeid` (`periodtypeid`),
  CONSTRAINT `fk_period_periodtypeid` FOREIGN KEY (`periodtypeid`) REFERENCES `periodtype` (`periodtypeid`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `period`
--

LOCK TABLES `period` WRITE;
/*!40000 ALTER TABLE `period` DISABLE KEYS */;
INSERT INTO `period` VALUES (18,11,'2013-04-12','2013-04-12'),(7,13,'2011-07-01','2011-07-31'),(5,13,'2012-02-01','2012-02-29'),(13,13,'2012-03-01','2012-03-31'),(4,13,'2012-04-01','2012-04-30'),(12,13,'2012-05-01','2012-05-31'),(15,13,'2012-06-01','2012-06-30'),(10,13,'2012-07-01','2012-07-31'),(14,13,'2012-08-01','2012-08-31'),(16,13,'2012-09-01','2012-09-30'),(9,13,'2012-10-01','2012-10-31'),(8,13,'2012-11-01','2012-11-30'),(6,13,'2012-12-01','2012-12-31'),(3,13,'2013-01-01','2013-01-31'),(11,13,'2013-02-01','2013-02-28'),(19,13,'2013-03-01','2013-03-31'),(17,13,'2013-04-01','2013-04-30'),(20,15,'2013-01-01','2013-03-31'),(21,15,'2013-04-01','2013-06-30');
/*!40000 ALTER TABLE `period` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `periodtype`
--

DROP TABLE IF EXISTS `periodtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `periodtype` (
  `periodtypeid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`periodtypeid`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `periodtype`
--

LOCK TABLES `periodtype` WRITE;
/*!40000 ALTER TABLE `periodtype` DISABLE KEYS */;
INSERT INTO `periodtype` VALUES (11,'Daily'),(12,'Weekly'),(13,'Monthly'),(14,'BiMonthly'),(15,'Quarterly'),(16,'SixMonthly'),(17,'Yearly'),(18,'FinancialApril'),(19,'FinancialJuly'),(20,'FinancialOct');
/*!40000 ALTER TABLE `periodtype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program`
--

DROP TABLE IF EXISTS `program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `program` (
  `programid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `description` longtext,
  `version` int(11) DEFAULT NULL,
  `dateOfEnrollmentDescription` longtext NOT NULL,
  `dateOfIncidentDescription` longtext NOT NULL,
  `type` int(11) DEFAULT NULL,
  `displayProvidedOtherFacility` tinyint(1) DEFAULT NULL,
  `displayIncidentDate` tinyint(1) DEFAULT NULL,
  `generatedByEnrollmentDate` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`programid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program`
--

LOCK TABLES `program` WRITE;
/*!40000 ALTER TABLE `program` DISABLE KEYS */;
/*!40000 ALTER TABLE `program` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program_criteria`
--

DROP TABLE IF EXISTS `program_criteria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `program_criteria` (
  `programid` int(11) NOT NULL,
  `validationcriteriaid` int(11) NOT NULL,
  PRIMARY KEY (`programid`,`validationcriteriaid`),
  KEY `fk_program_criteria_validationcriteriaid` (`validationcriteriaid`),
  KEY `fk_program_criteria_programid` (`programid`),
  CONSTRAINT `fk_program_criteria_programid` FOREIGN KEY (`programid`) REFERENCES `program` (`programid`),
  CONSTRAINT `fk_program_criteria_validationcriteriaid` FOREIGN KEY (`validationcriteriaid`) REFERENCES `validationcriteria` (`validationcriteriaid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program_criteria`
--

LOCK TABLES `program_criteria` WRITE;
/*!40000 ALTER TABLE `program_criteria` DISABLE KEYS */;
/*!40000 ALTER TABLE `program_criteria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program_organisationunits`
--

DROP TABLE IF EXISTS `program_organisationunits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `program_organisationunits` (
  `programid` int(11) NOT NULL,
  `organisationunitid` int(11) NOT NULL,
  PRIMARY KEY (`programid`,`organisationunitid`),
  KEY `fk_program_organisationunits_organisationunitid` (`organisationunitid`),
  KEY `fk_program_organisationunits_programid` (`programid`),
  CONSTRAINT `fk_program_organisationunits_organisationunitid` FOREIGN KEY (`organisationunitid`) REFERENCES `organisationunit` (`organisationunitid`),
  CONSTRAINT `fk_program_organisationunits_programid` FOREIGN KEY (`programid`) REFERENCES `program` (`programid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program_organisationunits`
--

LOCK TABLES `program_organisationunits` WRITE;
/*!40000 ALTER TABLE `program_organisationunits` DISABLE KEYS */;
/*!40000 ALTER TABLE `program_organisationunits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program_patientAttributes`
--

DROP TABLE IF EXISTS `program_patientAttributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `program_patientAttributes` (
  `programid` int(11) NOT NULL,
  `patientattributeid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`programid`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program_patientAttributes`
--

LOCK TABLES `program_patientAttributes` WRITE;
/*!40000 ALTER TABLE `program_patientAttributes` DISABLE KEYS */;
/*!40000 ALTER TABLE `program_patientAttributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program_patientIdentifierTypes`
--

DROP TABLE IF EXISTS `program_patientIdentifierTypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `program_patientIdentifierTypes` (
  `programid` int(11) NOT NULL,
  `patientidentifiertypeid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`programid`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program_patientIdentifierTypes`
--

LOCK TABLES `program_patientIdentifierTypes` WRITE;
/*!40000 ALTER TABLE `program_patientIdentifierTypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `program_patientIdentifierTypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program_patientattributes`
--

DROP TABLE IF EXISTS `program_patientattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `program_patientattributes` (
  `programid` int(11) NOT NULL,
  `patientattributeid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`programid`,`sort_order`),
  KEY `fk_program_patientAttributes_programid` (`programid`),
  KEY `fk_program_patientAttributes_patientattributeid` (`patientattributeid`),
  CONSTRAINT `fk_program_patientAttributes_patientattributeid` FOREIGN KEY (`patientattributeid`) REFERENCES `patientattribute` (`patientattributeid`),
  CONSTRAINT `fk_program_patientAttributes_programid` FOREIGN KEY (`programid`) REFERENCES `program` (`programid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program_patientattributes`
--

LOCK TABLES `program_patientattributes` WRITE;
/*!40000 ALTER TABLE `program_patientattributes` DISABLE KEYS */;
/*!40000 ALTER TABLE `program_patientattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program_patientidentifiertypes`
--

DROP TABLE IF EXISTS `program_patientidentifiertypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `program_patientidentifiertypes` (
  `programid` int(11) NOT NULL,
  `patientidentifiertypeid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`programid`,`sort_order`),
  KEY `fk_program_patientIdentifierTypes_programid` (`programid`),
  KEY `fk_program_patientIdentifierTypes_patientidentifiertypeid` (`patientidentifiertypeid`),
  CONSTRAINT `fk_program_patientIdentifierTypes_patientidentifiertypeid` FOREIGN KEY (`patientidentifiertypeid`) REFERENCES `patientidentifiertype` (`patientidentifiertypeid`),
  CONSTRAINT `fk_program_patientIdentifierTypes_programid` FOREIGN KEY (`programid`) REFERENCES `program` (`programid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program_patientidentifiertypes`
--

LOCK TABLES `program_patientidentifiertypes` WRITE;
/*!40000 ALTER TABLE `program_patientidentifiertypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `program_patientidentifiertypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programexpression`
--

DROP TABLE IF EXISTS `programexpression`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `programexpression` (
  `programexpressionid` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `expression` longtext,
  PRIMARY KEY (`programexpressionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programexpression`
--

LOCK TABLES `programexpression` WRITE;
/*!40000 ALTER TABLE `programexpression` DISABLE KEYS */;
/*!40000 ALTER TABLE `programexpression` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programinstance`
--

DROP TABLE IF EXISTS `programinstance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `programinstance` (
  `programinstanceid` int(11) NOT NULL AUTO_INCREMENT,
  `dateofincident` datetime NOT NULL,
  `enrollmentdate` datetime NOT NULL,
  `enddate` datetime DEFAULT NULL,
  `completed` tinyint(1) NOT NULL,
  `patientid` int(11) DEFAULT NULL,
  `programid` int(11) NOT NULL,
  PRIMARY KEY (`programinstanceid`),
  KEY `fk_programinstance_patientid` (`patientid`),
  KEY `fk_programinstance_programid` (`programid`),
  KEY `index_programinstance` (`programinstanceid`),
  CONSTRAINT `fk_programinstance_patientid` FOREIGN KEY (`patientid`) REFERENCES `patient` (`patientid`),
  CONSTRAINT `fk_programinstance_programid` FOREIGN KEY (`programid`) REFERENCES `program` (`programid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programinstance`
--

LOCK TABLES `programinstance` WRITE;
/*!40000 ALTER TABLE `programinstance` DISABLE KEYS */;
/*!40000 ALTER TABLE `programinstance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programstage`
--

DROP TABLE IF EXISTS `programstage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `programstage` (
  `programstageid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `mindaysfromstart` int(11) NOT NULL,
  `programid` int(11) DEFAULT NULL,
  `irregular` tinyint(1) DEFAULT NULL,
  `dataEntryForm` int(11) DEFAULT NULL,
  `standardInterval` int(11) DEFAULT NULL,
  `reportDateDescription` varchar(255) DEFAULT NULL,
  `autoGenerateEvent` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`programstageid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`),
  KEY `fk_programstage_program` (`programid`),
  KEY `fk_programstage_dataentryform` (`dataEntryForm`),
  CONSTRAINT `fk_programstage_dataentryform` FOREIGN KEY (`dataEntryForm`) REFERENCES `dataentryform` (`dataentryformid`),
  CONSTRAINT `fk_programstage_program` FOREIGN KEY (`programid`) REFERENCES `program` (`programid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programstage`
--

LOCK TABLES `programstage` WRITE;
/*!40000 ALTER TABLE `programstage` DISABLE KEYS */;
/*!40000 ALTER TABLE `programstage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programstage_dataelements`
--

DROP TABLE IF EXISTS `programstage_dataelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `programstage_dataelements` (
  `programstageid` int(11) NOT NULL,
  `dataelementid` int(11) NOT NULL,
  `compulsory` tinyint(1) NOT NULL,
  `allowprovidedelsewhere` tinyint(1) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `displayInReports` tinyint(1) DEFAULT NULL,
  `patienttabularreportid` int(11) DEFAULT NULL,
  `tabular_sort_order` int(11) DEFAULT NULL,
  `programstagesectionid` int(11) DEFAULT NULL,
  `section_sort_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`programstageid`,`dataelementid`),
  KEY `FKAF0E5FC6D6A4FF22` (`patienttabularreportid`),
  KEY `fk_programstagedataelement_dataelementid` (`dataelementid`),
  KEY `fk_programstagedataelement_programstageid` (`programstageid`),
  KEY `FKAF0E5FC69A86E92D` (`programstagesectionid`),
  CONSTRAINT `FKAF0E5FC69A86E92D` FOREIGN KEY (`programstagesectionid`) REFERENCES `programstagesection` (`programstagesectionid`),
  CONSTRAINT `FKAF0E5FC6D6A4FF22` FOREIGN KEY (`patienttabularreportid`) REFERENCES `patienttabularreport` (`patienttabularreportid`),
  CONSTRAINT `fk_programstagedataelement_dataelementid` FOREIGN KEY (`dataelementid`) REFERENCES `dataelement` (`dataelementid`),
  CONSTRAINT `fk_programstagedataelement_programstageid` FOREIGN KEY (`programstageid`) REFERENCES `programstage` (`programstageid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programstage_dataelements`
--

LOCK TABLES `programstage_dataelements` WRITE;
/*!40000 ALTER TABLE `programstage_dataelements` DISABLE KEYS */;
/*!40000 ALTER TABLE `programstage_dataelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programstageinstance`
--

DROP TABLE IF EXISTS `programstageinstance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `programstageinstance` (
  `programstageinstanceid` int(11) NOT NULL AUTO_INCREMENT,
  `programinstanceid` int(11) NOT NULL,
  `programstageid` int(11) NOT NULL,
  `duedate` datetime DEFAULT NULL,
  `executiondate` datetime DEFAULT NULL,
  `completed` tinyint(1) NOT NULL,
  `organisationunitid` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`programstageinstanceid`),
  KEY `fk_programstageinstance_organisationunitid` (`organisationunitid`),
  KEY `fk_programstageinstance_programinstanceid` (`programinstanceid`),
  KEY `fk_programstageinstance_programstageid` (`programstageid`),
  KEY `programstageinstance_executiondate` (`executiondate`),
  CONSTRAINT `fk_programstageinstance_organisationunitid` FOREIGN KEY (`organisationunitid`) REFERENCES `organisationunit` (`organisationunitid`),
  CONSTRAINT `fk_programstageinstance_programinstanceid` FOREIGN KEY (`programinstanceid`) REFERENCES `programinstance` (`programinstanceid`),
  CONSTRAINT `fk_programstageinstance_programstageid` FOREIGN KEY (`programstageid`) REFERENCES `programstage` (`programstageid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programstageinstance`
--

LOCK TABLES `programstageinstance` WRITE;
/*!40000 ALTER TABLE `programstageinstance` DISABLE KEYS */;
/*!40000 ALTER TABLE `programstageinstance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programstageinstance_outboundsms`
--

DROP TABLE IF EXISTS `programstageinstance_outboundsms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `programstageinstance_outboundsms` (
  `programstageinstanceid` int(11) NOT NULL,
  `outboundsmsid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`programstageinstanceid`,`sort_order`),
  KEY `FKD7263DB9BACED27D` (`programstageinstanceid`),
  KEY `FKD7263DB9E486B09E` (`outboundsmsid`),
  CONSTRAINT `FKD7263DB9BACED27D` FOREIGN KEY (`programstageinstanceid`) REFERENCES `programstageinstance` (`programstageinstanceid`),
  CONSTRAINT `FKD7263DB9E486B09E` FOREIGN KEY (`outboundsmsid`) REFERENCES `outbound_sms` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programstageinstance_outboundsms`
--

LOCK TABLES `programstageinstance_outboundsms` WRITE;
/*!40000 ALTER TABLE `programstageinstance_outboundsms` DISABLE KEYS */;
/*!40000 ALTER TABLE `programstageinstance_outboundsms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programstagesection`
--

DROP TABLE IF EXISTS `programstagesection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `programstagesection` (
  `programstagesectionid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `sortorder` int(11) NOT NULL,
  `programStageid` int(11) DEFAULT NULL,
  PRIMARY KEY (`programstagesectionid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`),
  KEY `FKFA727AAB8704EE73` (`programStageid`),
  CONSTRAINT `FKFA727AAB8704EE73` FOREIGN KEY (`programStageid`) REFERENCES `programstage` (`programstageid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programstagesection`
--

LOCK TABLES `programstagesection` WRITE;
/*!40000 ALTER TABLE `programstagesection` DISABLE KEYS */;
/*!40000 ALTER TABLE `programstagesection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programvalidation`
--

DROP TABLE IF EXISTS `programvalidation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `programvalidation` (
  `programvalidationid` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext,
  `leftprogramexpressionid` int(11) DEFAULT NULL,
  `operator` varchar(255) DEFAULT NULL,
  `rightprogramexpressionid` int(11) DEFAULT NULL,
  `programid` int(11) NOT NULL,
  PRIMARY KEY (`programvalidationid`),
  KEY `fk_programvalidation_leftprogramexpressionid` (`leftprogramexpressionid`),
  KEY `fk_programvalidation_rightprogramexpressionid` (`rightprogramexpressionid`),
  KEY `fk_programvalidation_programid` (`programid`),
  CONSTRAINT `fk_programvalidation_leftprogramexpressionid` FOREIGN KEY (`leftprogramexpressionid`) REFERENCES `programexpression` (`programexpressionid`),
  CONSTRAINT `fk_programvalidation_programid` FOREIGN KEY (`programid`) REFERENCES `program` (`programid`),
  CONSTRAINT `fk_programvalidation_rightprogramexpressionid` FOREIGN KEY (`rightprogramexpressionid`) REFERENCES `programexpression` (`programexpressionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programvalidation`
--

LOCK TABLES `programvalidation` WRITE;
/*!40000 ALTER TABLE `programvalidation` DISABLE KEYS */;
/*!40000 ALTER TABLE `programvalidation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relationship`
--

DROP TABLE IF EXISTS `relationship`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relationship` (
  `relationshipid` int(11) NOT NULL AUTO_INCREMENT,
  `patientaid` int(11) NOT NULL,
  `relationshiptypeid` int(11) NOT NULL,
  `patientbid` int(11) NOT NULL,
  PRIMARY KEY (`relationshipid`),
  KEY `fk_relationship_relationshiptypeid` (`relationshiptypeid`),
  KEY `fk_relationship_patientida` (`patientaid`),
  KEY `fk_relationship_patientidb` (`patientbid`),
  CONSTRAINT `fk_relationship_patientida` FOREIGN KEY (`patientaid`) REFERENCES `patient` (`patientid`),
  CONSTRAINT `fk_relationship_patientidb` FOREIGN KEY (`patientbid`) REFERENCES `patient` (`patientid`),
  CONSTRAINT `fk_relationship_relationshiptypeid` FOREIGN KEY (`relationshiptypeid`) REFERENCES `relationshiptype` (`relationshiptypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relationship`
--

LOCK TABLES `relationship` WRITE;
/*!40000 ALTER TABLE `relationship` DISABLE KEYS */;
/*!40000 ALTER TABLE `relationship` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relationshiptype`
--

DROP TABLE IF EXISTS `relationshiptype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relationshiptype` (
  `relationshiptypeid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `a_is_to_b` varchar(255) NOT NULL,
  `b_is_to_a` varchar(255) NOT NULL,
  PRIMARY KEY (`relationshiptypeid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relationshiptype`
--

LOCK TABLES `relationshiptype` WRITE;
/*!40000 ALTER TABLE `relationshiptype` DISABLE KEYS */;
/*!40000 ALTER TABLE `relationshiptype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relativeperiods`
--

DROP TABLE IF EXISTS `relativeperiods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relativeperiods` (
  `relativeperiodsid` int(11) NOT NULL AUTO_INCREMENT,
  `reportingMonth` tinyint(1) DEFAULT NULL,
  `reportingBimonth` tinyint(1) DEFAULT NULL,
  `reportingQuarter` tinyint(1) DEFAULT NULL,
  `lastSixMonth` tinyint(1) DEFAULT NULL,
  `monthsThisYear` tinyint(1) DEFAULT NULL,
  `quartersThisYear` tinyint(1) DEFAULT NULL,
  `thisYear` tinyint(1) DEFAULT NULL,
  `monthsLastYear` tinyint(1) DEFAULT NULL,
  `quartersLastYear` tinyint(1) DEFAULT NULL,
  `lastYear` tinyint(1) DEFAULT NULL,
  `last5Years` tinyint(1) DEFAULT NULL,
  `last12Months` tinyint(1) DEFAULT NULL,
  `last3Months` tinyint(1) DEFAULT NULL,
  `last6BiMonths` tinyint(1) DEFAULT NULL,
  `last4Quarters` tinyint(1) DEFAULT NULL,
  `last2SixMonths` tinyint(1) DEFAULT NULL,
  `thisFinancialYear` tinyint(1) DEFAULT NULL,
  `lastFinancialYear` tinyint(1) DEFAULT NULL,
  `last5FinancialYears` tinyint(1) DEFAULT NULL,
  `last52Weeks` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`relativeperiodsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relativeperiods`
--

LOCK TABLES `relativeperiods` WRITE;
/*!40000 ALTER TABLE `relativeperiods` DISABLE KEYS */;
/*!40000 ALTER TABLE `relativeperiods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report`
--

DROP TABLE IF EXISTS `report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report` (
  `reportid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `designContent` longtext,
  `reporttableid` int(11) DEFAULT NULL,
  `usingOrgUnitGroupSets` tinyint(1) DEFAULT NULL,
  `relativeperiodsid` int(11) DEFAULT NULL,
  `paramReportingMonth` tinyint(1) DEFAULT NULL,
  `paramOrganisationUnit` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`reportid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `relativeperiodsid` (`relativeperiodsid`),
  KEY `fk_report_relativeperiodsid` (`relativeperiodsid`),
  KEY `fk_report_reporttableid` (`reporttableid`),
  CONSTRAINT `fk_report_relativeperiodsid` FOREIGN KEY (`relativeperiodsid`) REFERENCES `relativeperiods` (`relativeperiodsid`),
  CONSTRAINT `fk_report_reporttableid` FOREIGN KEY (`reporttableid`) REFERENCES `reporttable` (`reporttableid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report`
--

LOCK TABLES `report` WRITE;
/*!40000 ALTER TABLE `report` DISABLE KEYS */;
/*!40000 ALTER TABLE `report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reportin`
--

DROP TABLE IF EXISTS `reportin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reportin` (
  `reportid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(160) NOT NULL,
  `model` varchar(100) NOT NULL,
  `periodtypeid` int(11) NOT NULL,
  `excelname` varchar(100) NOT NULL,
  `xmlname` varchar(100) NOT NULL,
  `reporttype` varchar(100) NOT NULL,
  `orgunitgroupid` int(11) DEFAULT NULL,
  `datasetids` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`reportid`),
  UNIQUE KEY `name` (`name`),
  KEY `fk_reports_orgunitgroupid` (`orgunitgroupid`),
  KEY `fk_reports_periodtypeid` (`periodtypeid`),
  CONSTRAINT `fk_reports_orgunitgroupid` FOREIGN KEY (`orgunitgroupid`) REFERENCES `orgunitgroup` (`orgunitgroupid`),
  CONSTRAINT `fk_reports_periodtypeid` FOREIGN KEY (`periodtypeid`) REFERENCES `periodtype` (`periodtypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reportin`
--

LOCK TABLES `reportin` WRITE;
/*!40000 ALTER TABLE `reportin` DISABLE KEYS */;
/*!40000 ALTER TABLE `reportin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reportsource`
--

DROP TABLE IF EXISTS `reportsource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reportsource` (
  `reportid` int(11) NOT NULL,
  `sourceid` int(11) NOT NULL,
  PRIMARY KEY (`reportid`,`sourceid`),
  KEY `FK5A4D064F93758F56` (`reportid`),
  KEY `fk_reportin_organisationunit` (`sourceid`),
  CONSTRAINT `FK5A4D064F93758F56` FOREIGN KEY (`reportid`) REFERENCES `reportin` (`reportid`),
  CONSTRAINT `fk_reportin_organisationunit` FOREIGN KEY (`sourceid`) REFERENCES `organisationunit` (`organisationunitid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reportsource`
--

LOCK TABLES `reportsource` WRITE;
/*!40000 ALTER TABLE `reportsource` DISABLE KEYS */;
/*!40000 ALTER TABLE `reportsource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reporttable`
--

DROP TABLE IF EXISTS `reporttable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reporttable` (
  `reporttableid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `regression` tinyint(1) DEFAULT NULL,
  `cumulative` tinyint(1) DEFAULT NULL,
  `categorycomboid` int(11) DEFAULT NULL,
  `doIndicators` tinyint(1) DEFAULT NULL,
  `doPeriods` tinyint(1) DEFAULT NULL,
  `doUnits` tinyint(1) DEFAULT NULL,
  `reportingMonth` tinyint(1) DEFAULT NULL,
  `reportingBimonth` tinyint(1) DEFAULT NULL,
  `reportingQuarter` tinyint(1) DEFAULT NULL,
  `lastSixMonth` tinyint(1) DEFAULT NULL,
  `monthsThisYear` tinyint(1) DEFAULT NULL,
  `quartersThisYear` tinyint(1) DEFAULT NULL,
  `thisYear` tinyint(1) DEFAULT NULL,
  `monthsLastYear` tinyint(1) DEFAULT NULL,
  `quartersLastYear` tinyint(1) DEFAULT NULL,
  `lastYear` tinyint(1) DEFAULT NULL,
  `last5Years` tinyint(1) DEFAULT NULL,
  `last12Months` tinyint(1) DEFAULT NULL,
  `last3Months` tinyint(1) DEFAULT NULL,
  `last4Quarters` tinyint(1) DEFAULT NULL,
  `last2SixMonths` tinyint(1) DEFAULT NULL,
  `thisFinancialYear` tinyint(1) DEFAULT NULL,
  `lastFinancialYear` tinyint(1) DEFAULT NULL,
  `last5FinancialYears` tinyint(1) DEFAULT NULL,
  `paramReportingMonth` tinyint(1) DEFAULT NULL,
  `paramGrandParentOrganisationUnit` tinyint(1) DEFAULT NULL,
  `paramParentOrganisationUnit` tinyint(1) DEFAULT NULL,
  `paramOrganisationUnit` tinyint(1) DEFAULT NULL,
  `sortOrder` int(11) DEFAULT NULL,
  `topLimit` int(11) DEFAULT NULL,
  PRIMARY KEY (`reporttableid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`),
  KEY `fk_reporttable_categorycombo` (`categorycomboid`),
  CONSTRAINT `fk_reporttable_categorycombo` FOREIGN KEY (`categorycomboid`) REFERENCES `categorycombo` (`categorycomboid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reporttable`
--

LOCK TABLES `reporttable` WRITE;
/*!40000 ALTER TABLE `reporttable` DISABLE KEYS */;
/*!40000 ALTER TABLE `reporttable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reporttable_dataelements`
--

DROP TABLE IF EXISTS `reporttable_dataelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reporttable_dataelements` (
  `reporttableid` int(11) NOT NULL,
  `dataelementid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`reporttableid`,`sort_order`),
  KEY `fk_reporttable_dataelements_dataelementid` (`dataelementid`),
  KEY `fk_reporttable_dataelements_reporttableid` (`reporttableid`),
  CONSTRAINT `fk_reporttable_dataelements_dataelementid` FOREIGN KEY (`dataelementid`) REFERENCES `dataelement` (`dataelementid`),
  CONSTRAINT `fk_reporttable_dataelements_reporttableid` FOREIGN KEY (`reporttableid`) REFERENCES `reporttable` (`reporttableid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reporttable_dataelements`
--

LOCK TABLES `reporttable_dataelements` WRITE;
/*!40000 ALTER TABLE `reporttable_dataelements` DISABLE KEYS */;
/*!40000 ALTER TABLE `reporttable_dataelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reporttable_datasets`
--

DROP TABLE IF EXISTS `reporttable_datasets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reporttable_datasets` (
  `reporttableid` int(11) NOT NULL,
  `datasetid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`reporttableid`,`sort_order`),
  KEY `fk_reporttable_datasets_datasetid` (`datasetid`),
  KEY `fk_reporttable_datasets_reporttableid` (`reporttableid`),
  CONSTRAINT `fk_reporttable_datasets_datasetid` FOREIGN KEY (`datasetid`) REFERENCES `dataset` (`datasetid`),
  CONSTRAINT `fk_reporttable_datasets_reporttableid` FOREIGN KEY (`reporttableid`) REFERENCES `reporttable` (`reporttableid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reporttable_datasets`
--

LOCK TABLES `reporttable_datasets` WRITE;
/*!40000 ALTER TABLE `reporttable_datasets` DISABLE KEYS */;
/*!40000 ALTER TABLE `reporttable_datasets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reporttable_indicators`
--

DROP TABLE IF EXISTS `reporttable_indicators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reporttable_indicators` (
  `reporttableid` int(11) NOT NULL,
  `indicatorid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`reporttableid`,`sort_order`),
  KEY `fk_reporttable_indicators_reporttableid` (`reporttableid`),
  KEY `fk_reporttable_indicators_indicatorid` (`indicatorid`),
  CONSTRAINT `fk_reporttable_indicators_indicatorid` FOREIGN KEY (`indicatorid`) REFERENCES `indicator` (`indicatorid`),
  CONSTRAINT `fk_reporttable_indicators_reporttableid` FOREIGN KEY (`reporttableid`) REFERENCES `reporttable` (`reporttableid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reporttable_indicators`
--

LOCK TABLES `reporttable_indicators` WRITE;
/*!40000 ALTER TABLE `reporttable_indicators` DISABLE KEYS */;
/*!40000 ALTER TABLE `reporttable_indicators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reporttable_organisationunits`
--

DROP TABLE IF EXISTS `reporttable_organisationunits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reporttable_organisationunits` (
  `reporttableid` int(11) NOT NULL,
  `organisationunitid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`reporttableid`,`sort_order`),
  KEY `fk_reporttable_organisationunits_organisationunitid` (`organisationunitid`),
  KEY `fk_reporttable_organisationunits_reporttableid` (`reporttableid`),
  CONSTRAINT `fk_reporttable_organisationunits_organisationunitid` FOREIGN KEY (`organisationunitid`) REFERENCES `organisationunit` (`organisationunitid`),
  CONSTRAINT `fk_reporttable_organisationunits_reporttableid` FOREIGN KEY (`reporttableid`) REFERENCES `reporttable` (`reporttableid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reporttable_organisationunits`
--

LOCK TABLES `reporttable_organisationunits` WRITE;
/*!40000 ALTER TABLE `reporttable_organisationunits` DISABLE KEYS */;
/*!40000 ALTER TABLE `reporttable_organisationunits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reporttable_orgunitgroups`
--

DROP TABLE IF EXISTS `reporttable_orgunitgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reporttable_orgunitgroups` (
  `reporttableid` int(11) NOT NULL,
  `orgunitgroupid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`reporttableid`,`sort_order`),
  KEY `fk_reporttable_orgunitgroups_orgunitgroupid` (`orgunitgroupid`),
  KEY `fk_reporttable_orgunitunitgroups_reporttableid` (`reporttableid`),
  CONSTRAINT `fk_reporttable_orgunitgroups_orgunitgroupid` FOREIGN KEY (`orgunitgroupid`) REFERENCES `orgunitgroup` (`orgunitgroupid`),
  CONSTRAINT `fk_reporttable_orgunitunitgroups_reporttableid` FOREIGN KEY (`reporttableid`) REFERENCES `reporttable` (`reporttableid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reporttable_orgunitgroups`
--

LOCK TABLES `reporttable_orgunitgroups` WRITE;
/*!40000 ALTER TABLE `reporttable_orgunitgroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `reporttable_orgunitgroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reporttable_periods`
--

DROP TABLE IF EXISTS `reporttable_periods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reporttable_periods` (
  `reporttableid` int(11) NOT NULL,
  `periodid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`reporttableid`,`sort_order`),
  KEY `fk_reporttable_periods_reporttableid` (`reporttableid`),
  KEY `fk_reporttable_periods_periodid` (`periodid`),
  CONSTRAINT `fk_reporttable_periods_periodid` FOREIGN KEY (`periodid`) REFERENCES `period` (`periodid`),
  CONSTRAINT `fk_reporttable_periods_reporttableid` FOREIGN KEY (`reporttableid`) REFERENCES `reporttable` (`reporttableid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reporttable_periods`
--

LOCK TABLES `reporttable_periods` WRITE;
/*!40000 ALTER TABLE `reporttable_periods` DISABLE KEYS */;
/*!40000 ALTER TABLE `reporttable_periods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `section`
--

DROP TABLE IF EXISTS `section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `section` (
  `sectionid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `datasetid` int(11) NOT NULL,
  `sortorder` int(11) NOT NULL,
  PRIMARY KEY (`sectionid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `name_2` (`name`,`datasetid`),
  UNIQUE KEY `code` (`code`),
  KEY `fk_section_datasetid` (`datasetid`),
  CONSTRAINT `fk_section_datasetid` FOREIGN KEY (`datasetid`) REFERENCES `dataset` (`datasetid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `section`
--

LOCK TABLES `section` WRITE;
/*!40000 ALTER TABLE `section` DISABLE KEYS */;
/*!40000 ALTER TABLE `section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sectiondataelements`
--

DROP TABLE IF EXISTS `sectiondataelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sectiondataelements` (
  `sectionid` int(11) NOT NULL,
  `dataelementid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`sectionid`,`sort_order`),
  KEY `fk_section_dataelementid` (`dataelementid`),
  KEY `fk_sectiondataelements_sectionid` (`sectionid`),
  CONSTRAINT `fk_sectiondataelements_sectionid` FOREIGN KEY (`sectionid`) REFERENCES `section` (`sectionid`),
  CONSTRAINT `fk_section_dataelementid` FOREIGN KEY (`dataelementid`) REFERENCES `dataelement` (`dataelementid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sectiondataelements`
--

LOCK TABLES `sectiondataelements` WRITE;
/*!40000 ALTER TABLE `sectiondataelements` DISABLE KEYS */;
/*!40000 ALTER TABLE `sectiondataelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sectiongreyedfields`
--

DROP TABLE IF EXISTS `sectiongreyedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sectiongreyedfields` (
  `sectionid` int(11) NOT NULL,
  `dataelementoperandid` int(11) NOT NULL,
  PRIMARY KEY (`sectionid`,`dataelementoperandid`),
  KEY `fk_sectiongreyedfields_sectionid` (`sectionid`),
  KEY `fk_section_dataelementoperandid` (`dataelementoperandid`),
  CONSTRAINT `fk_sectiongreyedfields_sectionid` FOREIGN KEY (`sectionid`) REFERENCES `section` (`sectionid`),
  CONSTRAINT `fk_section_dataelementoperandid` FOREIGN KEY (`dataelementoperandid`) REFERENCES `dataelementoperand` (`dataelementoperandid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sectiongreyedfields`
--

LOCK TABLES `sectiongreyedfields` WRITE;
/*!40000 ALTER TABLE `sectiongreyedfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `sectiongreyedfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smscodes`
--

DROP TABLE IF EXISTS `smscodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smscodes` (
  `smscodeid` int(11) NOT NULL,
  `code` longtext,
  `dataelementid` int(11) DEFAULT NULL,
  `optionId` int(11) DEFAULT NULL,
  PRIMARY KEY (`smscodeid`),
  KEY `fk_dataelement_dataelementid` (`dataelementid`),
  CONSTRAINT `fk_dataelement_dataelementid` FOREIGN KEY (`dataelementid`) REFERENCES `dataelement` (`dataelementid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smscodes`
--

LOCK TABLES `smscodes` WRITE;
/*!40000 ALTER TABLE `smscodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `smscodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smscommandcodes`
--

DROP TABLE IF EXISTS `smscommandcodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smscommandcodes` (
  `id` int(11) NOT NULL,
  `codeid` int(11) NOT NULL,
  PRIMARY KEY (`id`,`codeid`),
  UNIQUE KEY `codeid` (`codeid`),
  KEY `FK22AB8794F99215AC` (`codeid`),
  CONSTRAINT `FK22AB8794F99215AC` FOREIGN KEY (`codeid`) REFERENCES `smscodes` (`smscodeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smscommandcodes`
--

LOCK TABLES `smscommandcodes` WRITE;
/*!40000 ALTER TABLE `smscommandcodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `smscommandcodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sqlview`
--

DROP TABLE IF EXISTS `sqlview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sqlview` (
  `viewid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `description` longtext,
  `sqlQuery` longtext NOT NULL,
  PRIMARY KEY (`viewid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sqlview`
--

LOCK TABLES `sqlview` WRITE;
/*!40000 ALTER TABLE `sqlview` DISABLE KEYS */;
/*!40000 ALTER TABLE `sqlview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `survey`
--

DROP TABLE IF EXISTS `survey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `survey` (
  `surveyid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(160) NOT NULL,
  `shortname` varchar(60) DEFAULT NULL,
  `description` longtext,
  `url` varchar(160) DEFAULT NULL,
  PRIMARY KEY (`surveyid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `shortname` (`shortname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey`
--

LOCK TABLES `survey` WRITE;
/*!40000 ALTER TABLE `survey` DISABLE KEYS */;
/*!40000 ALTER TABLE `survey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `surveydatavalue`
--

DROP TABLE IF EXISTS `surveydatavalue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `surveydatavalue` (
  `surveyid` int(11) NOT NULL,
  `indicatorid` int(11) NOT NULL,
  `sourceid` int(11) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  `storedby` varchar(50) DEFAULT NULL,
  `lastupdated` date DEFAULT NULL,
  PRIMARY KEY (`surveyid`,`indicatorid`,`sourceid`),
  KEY `fk_surveydatavalue_surveyid` (`surveyid`),
  KEY `fk_surveydatavalue_organisationunitid` (`sourceid`),
  KEY `fk_surveydatavalue_indicatorid` (`indicatorid`),
  CONSTRAINT `fk_surveydatavalue_indicatorid` FOREIGN KEY (`indicatorid`) REFERENCES `indicator` (`indicatorid`),
  CONSTRAINT `fk_surveydatavalue_organisationunitid` FOREIGN KEY (`sourceid`) REFERENCES `organisationunit` (`organisationunitid`),
  CONSTRAINT `fk_surveydatavalue_surveyid` FOREIGN KEY (`surveyid`) REFERENCES `survey` (`surveyid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `surveydatavalue`
--

LOCK TABLES `surveydatavalue` WRITE;
/*!40000 ALTER TABLE `surveydatavalue` DISABLE KEYS */;
/*!40000 ALTER TABLE `surveydatavalue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `surveymembers`
--

DROP TABLE IF EXISTS `surveymembers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `surveymembers` (
  `surveyid` int(11) NOT NULL,
  `indicatorid` int(11) NOT NULL,
  PRIMARY KEY (`surveyid`,`indicatorid`),
  KEY `FK61BB087F4F6D9909` (`surveyid`),
  KEY `fk_survey_indicatorid` (`indicatorid`),
  CONSTRAINT `FK61BB087F4F6D9909` FOREIGN KEY (`surveyid`) REFERENCES `survey` (`surveyid`),
  CONSTRAINT `fk_survey_indicatorid` FOREIGN KEY (`indicatorid`) REFERENCES `indicator` (`indicatorid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `surveymembers`
--

LOCK TABLES `surveymembers` WRITE;
/*!40000 ALTER TABLE `surveymembers` DISABLE KEYS */;
/*!40000 ALTER TABLE `surveymembers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `surveysource`
--

DROP TABLE IF EXISTS `surveysource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `surveysource` (
  `surveyid` int(11) NOT NULL,
  `sourceid` int(11) NOT NULL,
  PRIMARY KEY (`surveyid`,`sourceid`),
  KEY `FK68CBA3F54F6D9909` (`surveyid`),
  KEY `fk_survey_organisationunit` (`sourceid`),
  CONSTRAINT `FK68CBA3F54F6D9909` FOREIGN KEY (`surveyid`) REFERENCES `survey` (`surveyid`),
  CONSTRAINT `fk_survey_organisationunit` FOREIGN KEY (`sourceid`) REFERENCES `organisationunit` (`organisationunitid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `surveysource`
--

LOCK TABLES `surveysource` WRITE;
/*!40000 ALTER TABLE `surveysource` DISABLE KEYS */;
/*!40000 ALTER TABLE `surveysource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemsetting`
--

DROP TABLE IF EXISTS `systemsetting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `systemsetting` (
  `systemsettingid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `value` blob,
  PRIMARY KEY (`systemsettingid`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemsetting`
--

LOCK TABLES `systemsetting` WRITE;
/*!40000 ALTER TABLE `systemsetting` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemsetting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `targetmapping`
--

DROP TABLE IF EXISTS `targetmapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `targetmapping` (
  `dataelementid` int(11) NOT NULL,
  `dataelementoptioncombo` int(11) NOT NULL,
  `targetid` int(11) NOT NULL,
  `targetoptioncombo` int(11) NOT NULL,
  PRIMARY KEY (`dataelementid`,`dataelementoptioncombo`,`targetid`,`targetoptioncombo`),
  KEY `fk_targetmapping_dataelementid` (`dataelementid`),
  KEY `fk_targetmapping_targetid` (`targetid`),
  KEY `fk_targetmapping_categoryoptioncomboid` (`dataelementoptioncombo`),
  KEY `fk_targetmapping_targetoptioncomboid` (`targetoptioncombo`),
  CONSTRAINT `fk_targetmapping_categoryoptioncomboid` FOREIGN KEY (`dataelementoptioncombo`) REFERENCES `categoryoptioncombo` (`categoryoptioncomboid`),
  CONSTRAINT `fk_targetmapping_dataelementid` FOREIGN KEY (`dataelementid`) REFERENCES `dataelement` (`dataelementid`),
  CONSTRAINT `fk_targetmapping_targetid` FOREIGN KEY (`targetid`) REFERENCES `dataelement` (`dataelementid`),
  CONSTRAINT `fk_targetmapping_targetoptioncomboid` FOREIGN KEY (`targetoptioncombo`) REFERENCES `categoryoptioncombo` (`categoryoptioncomboid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `targetmapping`
--

LOCK TABLES `targetmapping` WRITE;
/*!40000 ALTER TABLE `targetmapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `targetmapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `translation`
--

DROP TABLE IF EXISTS `translation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `translation` (
  `objectclass` varchar(127) NOT NULL,
  `objectid` int(11) NOT NULL,
  `locale` varchar(15) NOT NULL,
  `objectproperty` varchar(63) NOT NULL,
  `value` longtext NOT NULL,
  PRIMARY KEY (`objectclass`,`objectid`,`locale`,`objectproperty`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `translation`
--

LOCK TABLES `translation` WRITE;
/*!40000 ALTER TABLE `translation` DISABLE KEYS */;
/*!40000 ALTER TABLE `translation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userattributevalues`
--

DROP TABLE IF EXISTS `userattributevalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userattributevalues` (
  `userinfoid` int(11) NOT NULL,
  `attributevalueid` int(11) NOT NULL,
  PRIMARY KEY (`userinfoid`,`attributevalueid`),
  UNIQUE KEY `attributevalueid` (`attributevalueid`),
  KEY `FK90728793A7840788` (`userinfoid`),
  KEY `FK907287932B8E4FD1` (`attributevalueid`),
  CONSTRAINT `FK907287932B8E4FD1` FOREIGN KEY (`attributevalueid`) REFERENCES `attributevalue` (`attributevalueid`),
  CONSTRAINT `FK90728793A7840788` FOREIGN KEY (`userinfoid`) REFERENCES `userinfo` (`userinfoid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userattributevalues`
--

LOCK TABLES `userattributevalues` WRITE;
/*!40000 ALTER TABLE `userattributevalues` DISABLE KEYS */;
/*!40000 ALTER TABLE `userattributevalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroup`
--

DROP TABLE IF EXISTS `usergroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroup` (
  `usergroupid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  PRIMARY KEY (`usergroupid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroup`
--

LOCK TABLES `usergroup` WRITE;
/*!40000 ALTER TABLE `usergroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroupattributevalues`
--

DROP TABLE IF EXISTS `usergroupattributevalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroupattributevalues` (
  `usergroupid` int(11) NOT NULL,
  `attributevalueid` int(11) NOT NULL,
  PRIMARY KEY (`usergroupid`,`attributevalueid`),
  UNIQUE KEY `attributevalueid` (`attributevalueid`),
  KEY `FKBEA156AA2B8E4FD1` (`attributevalueid`),
  KEY `FKBEA156AA52543EDA` (`usergroupid`),
  CONSTRAINT `FKBEA156AA2B8E4FD1` FOREIGN KEY (`attributevalueid`) REFERENCES `attributevalue` (`attributevalueid`),
  CONSTRAINT `FKBEA156AA52543EDA` FOREIGN KEY (`usergroupid`) REFERENCES `usergroup` (`usergroupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroupattributevalues`
--

LOCK TABLES `usergroupattributevalues` WRITE;
/*!40000 ALTER TABLE `usergroupattributevalues` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroupattributevalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroupmembers`
--

DROP TABLE IF EXISTS `usergroupmembers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroupmembers` (
  `userid` int(11) NOT NULL,
  `usergroupid` int(11) NOT NULL,
  PRIMARY KEY (`usergroupid`,`userid`),
  KEY `fk_usergroup_userid` (`userid`),
  KEY `fk_usergroupmembers_usergroupid` (`usergroupid`),
  CONSTRAINT `fk_usergroupmembers_usergroupid` FOREIGN KEY (`usergroupid`) REFERENCES `usergroup` (`usergroupid`),
  CONSTRAINT `fk_usergroup_userid` FOREIGN KEY (`userid`) REFERENCES `userinfo` (`userinfoid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroupmembers`
--

LOCK TABLES `usergroupmembers` WRITE;
/*!40000 ALTER TABLE `usergroupmembers` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroupmembers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userinfo`
--

DROP TABLE IF EXISTS `userinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userinfo` (
  `userinfoid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `surname` varchar(160) NOT NULL,
  `firstName` varchar(160) NOT NULL,
  `email` varchar(160) DEFAULT NULL,
  `phoneNumber` varchar(80) DEFAULT NULL,
  `jobTitle` varchar(160) DEFAULT NULL,
  `introduction` longtext,
  `gender` varchar(50) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `nationality` varchar(160) DEFAULT NULL,
  `employer` varchar(160) DEFAULT NULL,
  `education` longtext,
  `interests` longtext,
  `languages` longtext,
  `lastCheckedInterpretations` datetime DEFAULT NULL,
  PRIMARY KEY (`userinfoid`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userinfo`
--

LOCK TABLES `userinfo` WRITE;
/*!40000 ALTER TABLE `userinfo` DISABLE KEYS */;
INSERT INTO `userinfo` VALUES (2,'ze8Yb1cfAmv',NULL,'2013-02-16 16:03:07','admin','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `userinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usermembership`
--

DROP TABLE IF EXISTS `usermembership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usermembership` (
  `organisationunitid` int(11) NOT NULL,
  `userinfoid` int(11) NOT NULL,
  PRIMARY KEY (`userinfoid`,`organisationunitid`),
  KEY `fk_userinfo_organisationunitid` (`organisationunitid`),
  KEY `fk_usermembership_userinfoid` (`userinfoid`),
  CONSTRAINT `fk_userinfo_organisationunitid` FOREIGN KEY (`organisationunitid`) REFERENCES `organisationunit` (`organisationunitid`),
  CONSTRAINT `fk_usermembership_userinfoid` FOREIGN KEY (`userinfoid`) REFERENCES `userinfo` (`userinfoid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usermembership`
--

LOCK TABLES `usermembership` WRITE;
/*!40000 ALTER TABLE `usermembership` DISABLE KEYS */;
INSERT INTO `usermembership` VALUES (2,2);
/*!40000 ALTER TABLE `usermembership` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usermessage`
--

DROP TABLE IF EXISTS `usermessage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usermessage` (
  `usermessageid` int(11) NOT NULL AUTO_INCREMENT,
  `usermessagekey` varchar(255) DEFAULT NULL,
  `userid` int(11) NOT NULL,
  `isread` tinyint(1) NOT NULL,
  `isfollowup` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`usermessageid`),
  KEY `fk_usermessage_user` (`userid`),
  CONSTRAINT `fk_usermessage_user` FOREIGN KEY (`userid`) REFERENCES `userinfo` (`userinfoid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usermessage`
--

LOCK TABLES `usermessage` WRITE;
/*!40000 ALTER TABLE `usermessage` DISABLE KEYS */;
/*!40000 ALTER TABLE `usermessage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userrole`
--

DROP TABLE IF EXISTS `userrole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userrole` (
  `userroleid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`userroleid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userrole`
--

LOCK TABLES `userrole` WRITE;
/*!40000 ALTER TABLE `userrole` DISABLE KEYS */;
INSERT INTO `userrole` VALUES (2,'Superuser','xBWr8qrHaOY',NULL,'2013-02-16 16:03:07',NULL);
/*!40000 ALTER TABLE `userrole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userroleauthorities`
--

DROP TABLE IF EXISTS `userroleauthorities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userroleauthorities` (
  `userroleid` int(11) NOT NULL,
  `authority` varchar(255) DEFAULT NULL,
  KEY `fk_userroleauthorities_userroleid` (`userroleid`),
  CONSTRAINT `fk_userroleauthorities_userroleid` FOREIGN KEY (`userroleid`) REFERENCES `userrole` (`userroleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userroleauthorities`
--

LOCK TABLES `userroleauthorities` WRITE;
/*!40000 ALTER TABLE `userroleauthorities` DISABLE KEYS */;
INSERT INTO `userroleauthorities` VALUES (2,'ALL');
/*!40000 ALTER TABLE `userroleauthorities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userroledataset`
--

DROP TABLE IF EXISTS `userroledataset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userroledataset` (
  `userroleid` int(11) NOT NULL,
  `datasetid` int(11) NOT NULL,
  PRIMARY KEY (`userroleid`,`datasetid`),
  KEY `fk_userroledataset_datasetid` (`datasetid`),
  KEY `fk_userroledataset_userroleid` (`userroleid`),
  CONSTRAINT `fk_userroledataset_datasetid` FOREIGN KEY (`datasetid`) REFERENCES `dataset` (`datasetid`),
  CONSTRAINT `fk_userroledataset_userroleid` FOREIGN KEY (`userroleid`) REFERENCES `userrole` (`userroleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userroledataset`
--

LOCK TABLES `userroledataset` WRITE;
/*!40000 ALTER TABLE `userroledataset` DISABLE KEYS */;
/*!40000 ALTER TABLE `userroledataset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userrolemembers`
--

DROP TABLE IF EXISTS `userrolemembers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userrolemembers` (
  `userroleid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`userid`,`userroleid`),
  KEY `fk_userrolemembers_userroleid` (`userroleid`),
  KEY `fk_userrolemembers_userid` (`userid`),
  CONSTRAINT `fk_userrolemembers_userid` FOREIGN KEY (`userid`) REFERENCES `users` (`userid`),
  CONSTRAINT `fk_userrolemembers_userroleid` FOREIGN KEY (`userroleid`) REFERENCES `userrole` (`userroleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userrolemembers`
--

LOCK TABLES `userrolemembers` WRITE;
/*!40000 ALTER TABLE `userrolemembers` DISABLE KEYS */;
INSERT INTO `userrolemembers` VALUES (2,2);
/*!40000 ALTER TABLE `userrolemembers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `userid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `lastLogin` datetime DEFAULT NULL,
  `restoreToken` varchar(255) DEFAULT NULL,
  `restoreCode` varchar(255) DEFAULT NULL,
  `restoreExpiry` datetime DEFAULT NULL,
  `selfRegistered` tinyint(1) DEFAULT NULL,
  `disabled` tinyint(1) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`),
  KEY `fk_user_userinfoid` (`userid`),
  CONSTRAINT `fk_user_userinfoid` FOREIGN KEY (`userid`) REFERENCES `userinfo` (`userinfoid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (2,'admin','48e8f1207baef1ef7fe478a57d19f2e5','2013-04-17 04:52:32',NULL,NULL,NULL,0,0,'2013-02-16 16:03:07');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usersetting`
--

DROP TABLE IF EXISTS `usersetting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usersetting` (
  `userinfoid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `value` blob,
  PRIMARY KEY (`userinfoid`,`name`),
  KEY `fk_usersetting_userinfoid` (`userinfoid`),
  CONSTRAINT `fk_usersetting_userinfoid` FOREIGN KEY (`userinfoid`) REFERENCES `userinfo` (`userinfoid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usersetting`
--

LOCK TABLES `usersetting` WRITE;
/*!40000 ALTER TABLE `usersetting` DISABLE KEYS */;
/*!40000 ALTER TABLE `usersetting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `validationcriteria`
--

DROP TABLE IF EXISTS `validationcriteria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `validationcriteria` (
  `validationcriteriaid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `property` varchar(255) DEFAULT NULL,
  `operator` int(11) NOT NULL,
  `value` blob,
  PRIMARY KEY (`validationcriteriaid`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `validationcriteria`
--

LOCK TABLES `validationcriteria` WRITE;
/*!40000 ALTER TABLE `validationcriteria` DISABLE KEYS */;
/*!40000 ALTER TABLE `validationcriteria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `validationrule`
--

DROP TABLE IF EXISTS `validationrule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `validationrule` (
  `validationruleid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `description` longtext,
  `type` varchar(255) DEFAULT NULL,
  `operator` varchar(255) NOT NULL,
  `leftexpressionid` int(11) DEFAULT NULL,
  `rightexpressionid` int(11) DEFAULT NULL,
  `periodtypeid` int(11) DEFAULT NULL,
  PRIMARY KEY (`validationruleid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`),
  KEY `fk_validationrule_leftexpressionid` (`leftexpressionid`),
  KEY `fk_validationrule_rightexpressionid` (`rightexpressionid`),
  KEY `fk_validationrule_periodtypeid` (`periodtypeid`),
  CONSTRAINT `fk_validationrule_leftexpressionid` FOREIGN KEY (`leftexpressionid`) REFERENCES `expression` (`expressionid`),
  CONSTRAINT `fk_validationrule_periodtypeid` FOREIGN KEY (`periodtypeid`) REFERENCES `periodtype` (`periodtypeid`),
  CONSTRAINT `fk_validationrule_rightexpressionid` FOREIGN KEY (`rightexpressionid`) REFERENCES `expression` (`expressionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `validationrule`
--

LOCK TABLES `validationrule` WRITE;
/*!40000 ALTER TABLE `validationrule` DISABLE KEYS */;
/*!40000 ALTER TABLE `validationrule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `validationrulegroup`
--

DROP TABLE IF EXISTS `validationrulegroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `validationrulegroup` (
  `validationgroupid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(230) NOT NULL,
  `uid` varchar(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT NULL,
  `description` longtext,
  PRIMARY KEY (`validationgroupid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `validationrulegroup`
--

LOCK TABLES `validationrulegroup` WRITE;
/*!40000 ALTER TABLE `validationrulegroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `validationrulegroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `validationrulegroupmembers`
--

DROP TABLE IF EXISTS `validationrulegroupmembers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `validationrulegroupmembers` (
  `validationruleid` int(11) NOT NULL,
  `validationgroupid` int(11) NOT NULL,
  PRIMARY KEY (`validationgroupid`,`validationruleid`),
  KEY `fk_validationrulegroup_validationruleid` (`validationruleid`),
  KEY `fk_validationrulegroupmembers_validationrulegroupid` (`validationgroupid`),
  CONSTRAINT `fk_validationrulegroupmembers_validationrulegroupid` FOREIGN KEY (`validationgroupid`) REFERENCES `validationrulegroup` (`validationgroupid`),
  CONSTRAINT `fk_validationrulegroup_validationruleid` FOREIGN KEY (`validationruleid`) REFERENCES `validationrule` (`validationruleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `validationrulegroupmembers`
--

LOCK TABLES `validationrulegroupmembers` WRITE;
/*!40000 ALTER TABLE `validationrulegroupmembers` DISABLE KEYS */;
/*!40000 ALTER TABLE `validationrulegroupmembers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `version`
--

DROP TABLE IF EXISTS `version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `version` (
  `versionid` int(11) NOT NULL AUTO_INCREMENT,
  `versionkey` varchar(230) DEFAULT NULL,
  `versionvalue` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`versionid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `version`
--

LOCK TABLES `version` WRITE;
/*!40000 ALTER TABLE `version` DISABLE KEYS */;
INSERT INTO `version` VALUES (2,'organisationUnit','681c6d75-0869-44f6-9519-377c2ffbb0cb');
/*!40000 ALTER TABLE `version` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-04-17  5:20:14
